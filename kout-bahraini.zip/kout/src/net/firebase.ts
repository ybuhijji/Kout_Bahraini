import { FirebaseApp, initializeApp } from 'firebase/app';
import { Auth, connectAuthEmulator, getAuth, indexedDBLocalPersistence, initializeAuth } from 'firebase/auth';
import { Firestore, connectFirestoreEmulator, getFirestore } from 'firebase/firestore';
import { Functions, connectFunctionsEmulator, getFunctions, httpsCallable } from 'firebase/functions';
import { Capacitor } from '@capacitor/core';
import { FUNCTIONS_REGION, USE_EMULATORS, firebaseConfig } from './firebase-config';

export const onlineConfigured = !!firebaseConfig.apiKey;

let app: FirebaseApp | null = null;
let _auth: Auth | null = null;
let _db: Firestore | null = null;
let _fn: Functions | null = null;

function init() {
  if (app || !onlineConfigured) return;
  app = initializeApp(firebaseConfig);
  _auth = Capacitor.isNativePlatform()
    ? initializeAuth(app, { persistence: indexedDBLocalPersistence })
    : getAuth(app);
  _db = getFirestore(app);
  _fn = getFunctions(app, FUNCTIONS_REGION);
  if (USE_EMULATORS) {
    connectAuthEmulator(_auth, 'http://localhost:9099', { disableWarnings: true });
    connectFirestoreEmulator(_db, 'localhost', 8080);
    connectFunctionsEmulator(_fn, 'localhost', 5001);
  }
}

export function auth(): Auth { init(); if (!_auth) throw new Error('offline'); return _auth; }
export function db(): Firestore { init(); if (!_db) throw new Error('offline'); return _db; }

/** Calls a Cloud Function and unwraps its data, translating errors to Arabic messages. */
export async function call<T = any>(name: string, data: any = {}): Promise<T> {
  init();
  if (!_fn) throw new Error('الأونلاين مو مفعّل بعد');
  try {
    const res = await httpsCallable(_fn, name)(data);
    return res.data as T;
  } catch (e: any) {
    throw new Error(e?.details?.ar ?? e?.message ?? 'صار خطأ، حاول مرة ثانية');
  }
}

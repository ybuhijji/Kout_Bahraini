// Majlis (مجلس) = clan. Plural: ميالس / مجالس.
import {
  addDoc, collection, doc, getDoc, getDocs, limit, onSnapshot, orderBy, query, serverTimestamp,
  where, Unsubscribe,
} from 'firebase/firestore';
import { call, db } from './firebase';

export interface Majlis {
  id: string;
  name: string;
  tag: string;
  description: string;
  ownerUid: string;
  memberCount: number;
  trophies: number;
  open: boolean;
  emblem: string;
}
export interface MajlisMember { uid: string; name: string; role: 'owner' | 'elder' | 'member'; wins: number; avatar: string }
export interface ChatMsg { id: string; uid: string; name: string; text: string; at: any }

export const createMajlis = (d: { name: string; tag: string; description: string; open: boolean; emblem: string }) =>
  call<{ majlisId: string }>('createMajlis', d);
export const joinMajlis = (majlisId: string) => call('joinMajlis', { majlisId });
export const leaveMajlis = () => call('leaveMajlis', {});
export const kickMember = (uid: string) => call('kickMember', { uid });
export const promoteMember = (uid: string) => call('promoteMember', { uid });

export async function topMajalis(): Promise<Majlis[]> {
  const q = query(collection(db(), 'majalis'), orderBy('trophies', 'desc'), limit(30));
  return (await getDocs(q)).docs.map(d => ({ id: d.id, ...d.data() } as Majlis));
}

export async function findMajlisByTag(tag: string): Promise<Majlis[]> {
  const q = query(collection(db(), 'majalis'), where('tag', '==', tag.trim().toUpperCase()), limit(5));
  return (await getDocs(q)).docs.map(d => ({ id: d.id, ...d.data() } as Majlis));
}

export async function getMajlis(id: string): Promise<Majlis | null> {
  const s = await getDoc(doc(db(), 'majalis', id));
  return s.exists() ? ({ id: s.id, ...s.data() } as Majlis) : null;
}

export function watchMembers(id: string, cb: (m: MajlisMember[]) => void): Unsubscribe {
  return onSnapshot(query(collection(db(), 'majalis', id, 'members'), orderBy('wins', 'desc')),
    s => cb(s.docs.map(d => ({ uid: d.id, ...d.data() } as MajlisMember))));
}

export function watchChat(id: string, cb: (m: ChatMsg[]) => void): Unsubscribe {
  return onSnapshot(query(collection(db(), 'majalis', id, 'chat'), orderBy('at', 'desc'), limit(50)),
    s => cb(s.docs.map(d => ({ id: d.id, ...d.data() } as ChatMsg)).reverse()));
}

export async function sendChat(id: string, uid: string, name: string, text: string) {
  const t = text.trim().slice(0, 300);
  if (!t) return;
  await addDoc(collection(db(), 'majalis', id, 'chat'), { uid, name, text: t, at: serverTimestamp() });
}

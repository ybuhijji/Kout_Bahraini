// Online rooms and the online game controller. The server (Cloud Functions) is authoritative:
// it deals, validates every move, runs bots for empty seats and auto-plays timed-out turns.
// Each player only ever receives their own view (other hands hidden).
import {
  collection, doc, limit, onSnapshot, orderBy, query, where, Unsubscribe, Timestamp,
} from 'firebase/firestore';
import { Action, GameEvent } from '../../shared/engine';
import { call, db } from './firebase';
import { GameController, SeatInfo, ViewState } from '../game/controller';

export interface RoomSeat extends SeatInfo { uid?: string }
export interface Room {
  id: string;
  code: string;
  variant: 4 | 6;
  hostUid: string;
  status: 'waiting' | 'playing' | 'done';
  isPublic: boolean;
  majlisId?: string | null;
  seats: (RoomSeat | null)[];
  uids: string[];
  theme?: string;
  createdAt?: Timestamp;
}

export const quickMatch = (variant: 4 | 6) => call<{ roomId: string }>('quickMatch', { variant });
export const createRoom = (variant: 4 | 6, majlisId?: string | null) => call<{ roomId: string; code: string }>('createRoom', { variant, majlisId: majlisId ?? null });
export const joinRoom = (code: string) => call<{ roomId: string }>('joinRoom', { code: code.trim().toUpperCase() });
export const joinRoomById = (roomId: string) => call<{ roomId: string }>('joinRoom', { roomId });
export const leaveRoom = (roomId: string) => call('leaveRoom', { roomId });
export const startRoom = (roomId: string) => call('startRoom', { roomId });
export const switchSeat = (roomId: string, seat: number) => call('switchSeat', { roomId, seat });

export function watchRoom(roomId: string, cb: (r: Room | null) => void): Unsubscribe {
  return onSnapshot(doc(db(), 'rooms', roomId), s => cb(s.exists() ? ({ id: s.id, ...s.data() } as Room) : null));
}

export function watchMajlisRooms(majlisId: string, cb: (rooms: Room[]) => void): Unsubscribe {
  const q = query(collection(db(), 'rooms'), where('majlisId', '==', majlisId), where('status', '==', 'waiting'), limit(20));
  return onSnapshot(q, s => cb(s.docs.map(d => ({ id: d.id, ...d.data() } as Room))));
}

interface ViewDoc {
  seq: number;
  view: ViewState;
  events: GameEvent[];
  seats: SeatInfo[];
  mySeat: number;
  deadline: Timestamp | null;
}

export class OnlineController implements GameController {
  readonly online = true;
  mySeat = 0;
  seats: SeatInfo[] = [];
  private v: ViewState | null = null;
  private seq = -1;
  private dl: number | null = null;
  private subs = new Set<(e: GameEvent[]) => void>();
  private reacts = new Set<(seat: number, slot: string) => void>();
  private unsubs: Unsubscribe[] = [];
  private joinedAt = Date.now();
  private timeoutTimer: number | undefined;

  private constructor(readonly roomId: string, private uid: string) {}

  /** Resolves once the first view has arrived. */
  static open(roomId: string, uid: string): Promise<OnlineController> {
    const c = new OnlineController(roomId, uid);
    return new Promise((resolve, reject) => {
      let first = true;
      const u = onSnapshot(doc(db(), 'games', roomId, 'views', uid), snap => {
        if (!snap.exists()) return;
        const d = snap.data() as ViewDoc;
        c.seats = d.seats; c.mySeat = d.mySeat;
        c.dl = d.deadline ? d.deadline.toMillis() : null;
        c.scheduleTimeoutClaim();
        if (d.seq <= c.seq) return;
        c.seq = d.seq;
        c.v = d.view;
        if (first) { first = false; resolve(c); return; }
        c.subs.forEach(s => s(d.events ?? []));
      }, reject);
      const r = onSnapshot(
        query(collection(db(), 'games', roomId, 'reactions'), orderBy('at', 'desc'), limit(1)),
        snap => snap.docChanges().forEach(ch => {
          const d = ch.doc.data() as { seat: number; slot: string; at: Timestamp };
          if (ch.type === 'added' && d.at && d.at.toMillis() > c.joinedAt) c.reacts.forEach(fn => fn(d.seat, d.slot));
        }));
      c.unsubs.push(u, r);
    });
  }

  view() { return this.v!; }
  deadline() { return this.dl; }

  async act(a: Action) {
    await call('gameAction', { roomId: this.roomId, action: a });
  }

  react(slot: string) {
    call('sendReaction', { roomId: this.roomId, slot }).catch(() => {});
  }

  subscribe(cb: (e: GameEvent[]) => void) { this.subs.add(cb); return () => this.subs.delete(cb); }
  onReaction(cb: (seat: number, slot: string) => void) { this.reacts.add(cb); return () => this.reacts.delete(cb); }

  /** If the player on turn goes quiet, any client can ask the server to auto-play for them. */
  private scheduleTimeoutClaim() {
    clearTimeout(this.timeoutTimer);
    if (!this.dl) return;
    const wait = Math.max(0, this.dl - Date.now()) + 1500 + Math.random() * 1500;
    const seqAt = this.seq;
    this.timeoutTimer = window.setTimeout(() => {
      if (this.seq === seqAt) call('claimTimeout', { roomId: this.roomId }).catch(() => {});
    }, wait);
  }

  leave() {
    clearTimeout(this.timeoutTimer);
    this.unsubs.forEach(u => u());
    this.subs.clear();
    const phase = this.v?.phase;
    if (phase && phase !== 'matchOver') leaveRoom(this.roomId).catch(() => {});
  }
}

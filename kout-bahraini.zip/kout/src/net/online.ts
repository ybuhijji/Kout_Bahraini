// Online rooms and the online game controller. The server (Cloud Functions) is authoritative:
// it deals, validates every move, plays for bots and empty seats, and handles timed-out turns.
// Each player only ever receives their own view (other hands hidden).
import {
  collection, doc, limit, onSnapshot, orderBy, query, where, Unsubscribe, Timestamp,
} from 'firebase/firestore';
import { Action, GameEvent, StoredState, apply, unpackState } from '../../shared/engine';
import { call, db } from './firebase';
import { GameController, SeatInfo, ViewState } from '../game/controller';

export interface RoomSeat extends SeatInfo { uid?: string }
export interface Room {
  id: string;
  code: string;
  variant: 4 | 6;
  hostUid: string;
  status: 'waiting' | 'playing' | 'done';
  isPublic: boolean;
  majlisId?: string | null;
  seats: (RoomSeat | null)[];
  uids: string[];
  theme?: string;
  createdAt?: Timestamp;
}

export const quickMatch = (variant: 4 | 6) => call<{ roomId: string }>('quickMatch', { variant });
export const createRoom = (variant: 4 | 6, majlisId?: string | null) => call<{ roomId: string; code: string }>('createRoom', { variant, majlisId: majlisId ?? null });
export const joinRoom = (code: string) => call<{ roomId: string }>('joinRoom', { code: code.trim().toUpperCase() });
export const joinRoomById = (roomId: string) => call<{ roomId: string }>('joinRoom', { roomId });
export const leaveRoom = (roomId: string) => call('leaveRoom', { roomId });
export const startRoom = (roomId: string) => call('startRoom', { roomId });
export const switchSeat = (roomId: string, seat: number) => call('switchSeat', { roomId, seat });

export function watchRoom(roomId: string, cb: (r: Room | null) => void): Unsubscribe {
  return onSnapshot(doc(db(), 'rooms', roomId), s => cb(s.exists() ? ({ id: s.id, ...s.data() } as Room) : null));
}

export function watchMajlisRooms(majlisId: string, cb: (rooms: Room[]) => void): Unsubscribe {
  const q = query(collection(db(), 'rooms'), where('majlisId', '==', majlisId), where('status', '==', 'waiting'), limit(20));
  return onSnapshot(q, s => cb(s.docs.map(d => ({ id: d.id, ...d.data() } as Room))));
}

interface ViewDoc {
  seq: number;
  view: StoredState<ViewState>;
  events: GameEvent[];
  seats: SeatInfo[];
  mySeat: number;
  deadline: Timestamp | null;
  deadlineKind: 'human' | 'bot' | 'hand' | null;
}

function actorOf(v: ViewState): number | null {
  if (v.phase === 'bidding') return v.bidTurn;
  if (v.phase === 'trump') return v.bidder;
  if (v.phase === 'playing') return v.turn;
  return null;
}

/**
 * The server holds the real game. This phone:
 *  - shows its own view as soon as it arrives,
 *  - shows its own card move immediately (before the server confirms), so taps feel instant,
 *  - asks the server to take the next step (a bot move, the next hand, or a timed-out turn)
 *    as soon as that step is due. Every phone at the table does this, so play never stalls.
 */
export class OnlineController implements GameController {
  readonly online = true;
  mySeat = 0;
  seats: SeatInfo[] = [];
  private server: ViewState | null = null;   // last view confirmed by the server
  private shown: ViewState | null = null;    // what the table shows (may include my pending move)
  private seq = -1;
  private dl: number | null = null;
  private dlKind: ViewDoc['deadlineKind'] = null;
  private busy = false;
  private subs = new Set<(e: GameEvent[]) => void>();
  private reacts = new Set<(seat: number, slot: string) => void>();
  private unsubs: Unsubscribe[] = [];
  private joinedAt = Date.now();
  private tickTimer: number | undefined;
  private closed = false;

  private constructor(readonly roomId: string) {}

  /** Resolves once the first view has arrived. */
  static open(roomId: string, uid: string): Promise<OnlineController> {
    const c = new OnlineController(roomId);
    return new Promise((resolve, reject) => {
      let first = true;
      const u = onSnapshot(doc(db(), 'games', roomId, 'views', uid), snap => {
        if (!snap.exists()) return;
        const d = snap.data() as ViewDoc;
        if (d.seq < c.seq) return;
        const fresh = d.seq > c.seq;
        c.seats = d.seats;
        c.mySeat = d.mySeat;
        c.dl = d.deadline ? d.deadline.toMillis() : null;
        c.dlKind = d.deadlineKind ?? null;
        c.seq = d.seq;
        c.server = unpackState(d.view, d.seats.length);
        c.shown = c.server;
        c.busy = false;
        c.scheduleTick();
        if (first) { first = false; resolve(c); return; }
        c.emit(fresh ? d.events ?? [] : []);
      }, reject);
      const r = onSnapshot(
        query(collection(db(), 'games', roomId, 'reactions'), orderBy('at', 'desc'), limit(1)),
        snap => snap.docChanges().forEach(ch => {
          const d = ch.doc.data() as { seat: number; slot: string; at: Timestamp };
          if (ch.type === 'added' && d.at && d.at.toMillis() > c.joinedAt) c.reacts.forEach(fn => fn(d.seat, d.slot));
        }));
      c.unsubs.push(u, r);
    });
  }

  view() { return this.shown!; }
  deadline() { return this.dlKind === 'human' ? this.dl : null; }
  pending() { return this.busy; }

  private emit(ev: GameEvent[]) { this.subs.forEach(s => s(ev)); }

  async act(a: Action) {
    if (this.busy) return;               // ignore double taps while a move is on its way
    this.busy = true;
    const seqAt = this.seq;
    // Show my card (or trump choice) at once; the server's copy replaces it when it arrives.
    let local: GameEvent[] = [];
    if (a.type === 'play' || a.type === 'trump') {
      try {
        const copy = structuredClone(this.server!) as ViewState;
        local = apply(copy, a, () => 0.5);
        copy.handCounts = copy.hands.map((h, i) => (i === this.mySeat ? h.length : this.server!.handCounts[i] - (a.type === 'play' && (a as any).seat === i ? 1 : 0)));
        this.shown = copy;
      } catch { /* leave it to the server */ }
    }
    this.emit(local);
    try {
      await call('gameAction', { roomId: this.roomId, action: a });
    } catch (e) {
      if (this.seq === seqAt) {         // nothing newer arrived: undo the local move
        this.busy = false;
        this.shown = this.server;
        this.emit([]);
      }
      throw e;
    }
  }

  react(slot: string) {
    call('sendReaction', { roomId: this.roomId, slot }).catch(() => {});
  }

  subscribe(cb: (e: GameEvent[]) => void) { this.subs.add(cb); return () => this.subs.delete(cb); }
  onReaction(cb: (seat: number, slot: string) => void) { this.reacts.add(cb); return () => this.reacts.delete(cb); }

  /** Ask the server for the next step once it is due; retry if this phone's clock runs early. */
  private scheduleTick(attempt = 0) {
    clearTimeout(this.tickTimer);
    if (this.closed || this.dl === null || !this.server) return;
    const mine = actorOf(this.server) === this.mySeat;
    // Bots and the pause between hands: tick right on time. A human's timer: the player whose
    // turn it is ticks first; the others follow shortly after in case that phone went quiet.
    const extra = this.dlKind === 'human' ? (mine ? 300 : 900 + Math.random() * 900) : Math.random() * 150;
    const wait = Math.max(0, this.dl - Date.now()) + extra + attempt * 600;
    const seqAt = this.seq;
    this.tickTimer = window.setTimeout(async () => {
      if (this.seq !== seqAt || this.closed) return;
      try { await call('tickGame', { roomId: this.roomId }); } catch { /* retried below */ }
      if (this.seq === seqAt && attempt < 8) this.scheduleTick(attempt + 1);
    }, wait);
  }

  leave() {
    this.closed = true;
    clearTimeout(this.tickTimer);
    this.unsubs.forEach(u => u());
    this.subs.clear();
    const phase = this.server?.phase;
    if (phase && phase !== 'matchOver') leaveRoom(this.roomId).catch(() => {});
  }
}

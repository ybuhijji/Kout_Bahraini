// Store: items are bought with coins (server checks price and balance).
// Coins are bought with real money through Google Play Billing; the server verifies
// every purchase token with the Google Play Developer API before crediting coins.
import { Capacitor } from '@capacitor/core';
import { COIN_PACKS } from '../../shared/catalog';
import { call } from './firebase';
import { profileStore } from './profile';

export const buyItem = (itemId: string) => call<{ coins: number }>('buyItem', { itemId });
export const equipItem = (itemId: string | null, slot: 'accessory' | 'theme' | 'cardback') => call('equipItem', { itemId, slot });

type PriceMap = Record<string, string>;
let ready: Promise<PriceMap> | null = null;
let onCredited: ((coins: number) => void) | null = null;

export function billingAvailable() {
  return Capacitor.getPlatform() === 'android' && !!(window as any).CdvPurchase;
}

/** Registers coin products with Play Billing and returns localized prices (e.g. "BHD 0.990"). */
export function initBilling(credited: (coins: number) => void): Promise<PriceMap> {
  onCredited = credited;
  if (ready) return ready;
  ready = new Promise(resolve => {
    if (!billingAvailable()) { resolve({}); return; }
    const { store, ProductType, Platform } = (window as any).CdvPurchase;
    // Tie each purchase to the player's account (Play's obfuscatedAccountId), checked server side.
    store.applicationUsername = () => profileStore.get()?.uid;
    store.register(COIN_PACKS.map(p => ({ id: p.productId, type: ProductType.CONSUMABLE, platform: Platform.GOOGLE_PLAY })));
    store.when()
      .approved(async (tx: any) => {
        try {
          const receipt = tx.parentReceipt?.nativeData ?? {};
          const res = await call<{ coins: number }>('verifyPurchase', {
            productId: tx.products?.[0]?.id,
            purchaseToken: tx.purchaseId ?? receipt.purchaseToken,
          });
          await tx.finish(); // consumes the purchase so it can be bought again
          onCredited?.(res.coins);
        } catch (e) {
          console.error('verify failed', e); // not finished: Play will redeliver and we retry
        }
      });
    store.initialize([Platform.GOOGLE_PLAY]).then(() => {
      const prices: PriceMap = {};
      for (const p of COIN_PACKS) {
        const prod = store.get(p.productId, Platform.GOOGLE_PLAY);
        if (prod?.pricing?.price) prices[p.productId] = prod.pricing.price;
      }
      resolve(prices);
    });
  });
  return ready;
}

export async function buyCoins(productId: string) {
  const { store, Platform } = (window as any).CdvPurchase;
  const offer = store.get(productId, Platform.GOOGLE_PLAY)?.getOffer();
  if (!offer) throw new Error('المنتج مو متوفر حالياً');
  const err = await offer.order();
  if (err && err.code !== (window as any).CdvPurchase.ErrorCode.PAYMENT_CANCELLED) throw new Error(err.message);
}

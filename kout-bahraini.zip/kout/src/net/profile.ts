import { doc, onSnapshot } from 'firebase/firestore';
import { User, onAuthStateChanged } from 'firebase/auth';
import { auth, call, db, onlineConfigured } from './firebase';

export interface Profile {
  uid: string;
  name: string;
  avatar: string;
  coins: number;
  owned: string[];
  equipped: { accessory?: string; theme?: string; cardback?: string };
  majlisId?: string | null;
  majlisTag?: string | null;
  stats: { played: number; won: number; kouts: number };
}

type L = (p: Profile | null, u: User | null) => void;

let profile: Profile | null = null;
let user: User | null = null;
let unsubDoc: (() => void) | null = null;
const listeners = new Set<L>();
let started = false;

function notify() { listeners.forEach(l => l(profile, user)); }

/** A signed-in user may play online once their email is verified (social logins are pre-verified). */
export function isVerified(u: User | null) {
  if (!u) return false;
  const passwordOnly = u.providerData.every(p => p.providerId === 'password');
  return !passwordOnly || u.emailVerified;
}

/** Dev only: `npm run dev` then open /?demo to preview online screens with a fake profile. */
export const demoMode = import.meta.env.DEV && new URLSearchParams(location.search).has('demo');

export const profileStore = {
  get: () => profile,
  user: () => user,
  start() {
    if (demoMode && !started) {
      started = true;
      user = { uid: 'demo', providerData: [{ providerId: 'google.com' }], emailVerified: true } as unknown as User;
      profile = { uid: 'demo', name: 'يوسف', avatar: '🦅', coins: 2350, owned: ['misbah_kahraman', 'karak', 'theme_muharraq'],
        equipped: { accessory: 'misbah_kahraman' }, majlisId: null, majlisTag: null, stats: { played: 42, won: 27, kouts: 3 } };
      setTimeout(notify);
      return;
    }
    if (started || !onlineConfigured) return;
    started = true;
    onAuthStateChanged(auth(), async u => {
      user = u;
      unsubDoc?.(); unsubDoc = null; profile = null;
      if (u && isVerified(u)) {
        try { await call('ensureProfile', { name: u.displayName, photo: u.photoURL }); } catch (e) { console.warn(e); }
        unsubDoc = onSnapshot(doc(db(), 'users', u.uid), snap => {
          profile = snap.exists() ? ({ uid: u.uid, ...snap.data() } as Profile) : null;
          notify();
        });
      }
      notify();
    });
  },
  on(l: L) { listeners.add(l); l(profile, user); return () => listeners.delete(l); },
  refresh() { /* snapshot listener keeps it fresh */ },
};

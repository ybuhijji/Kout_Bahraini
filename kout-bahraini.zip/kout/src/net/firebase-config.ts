// Paste the web app config from Firebase Console > Project settings > Your apps.
// While apiKey is empty the game runs in offline mode (bots only) and online menus show a notice.
export const firebaseConfig = {
  apiKey: '',
  authDomain: '',
  projectId: '',
  storageBucket: '',
  messagingSenderId: '',
  appId: '',
};

// Must match the region in functions/src/index.ts.
export const FUNCTIONS_REGION = 'europe-west1';

// Set true to talk to the local Firebase emulators (npm run emulators).
export const USE_EMULATORS = false;

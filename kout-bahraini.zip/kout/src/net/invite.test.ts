import { describe, expect, it } from 'vitest';
import { parseInvite } from './invite';

describe('invite links', () => {
  it('reads app links and web links for rooms and majalis', () => {
    expect(parseInvite('koutbh://join/ab7kq')).toEqual({ kind: 'join', code: 'AB7KQ' });
    expect(parseInvite('https://kout-bahraini-affe9.firebaseapp.com/j/AB7KQ')).toEqual({ kind: 'join', code: 'AB7KQ' });
    expect(parseInvite('koutbh://majlis/xYz123')).toEqual({ kind: 'majlis', id: 'xYz123' });
    expect(parseInvite('https://x.firebaseapp.com/m/xYz123?noapp=1')).toEqual({ kind: 'majlis', id: 'xYz123' });
    expect(parseInvite('koutbh://something/else')).toBeNull();
  });
});

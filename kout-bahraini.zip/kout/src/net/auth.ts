// Sign-in: Google, Facebook, X (Twitter), or email + password with mandatory email verification.
// On Android the native SDKs handle the provider login (via @capacitor-firebase/authentication),
// then the credential is passed to the Firebase JS SDK so the rest of the app has one auth state.
import {
  FacebookAuthProvider, GoogleAuthProvider, TwitterAuthProvider, AuthProvider, OAuthCredential,
  createUserWithEmailAndPassword, sendEmailVerification, sendPasswordResetEmail,
  signInWithCredential, signInWithEmailAndPassword, signInWithPopup, signOut, updateProfile, reload,
} from 'firebase/auth';
import { Capacitor } from '@capacitor/core';
import { FirebaseAuthentication } from '@capacitor-firebase/authentication';
import { auth } from './firebase';

export type SocialProvider = 'google' | 'facebook' | 'x';

const native = () => Capacitor.isNativePlatform();

export async function signInSocial(p: SocialProvider) {
  if (native()) {
    let cred: OAuthCredential;
    if (p === 'google') {
      const r = await FirebaseAuthentication.signInWithGoogle();
      cred = GoogleAuthProvider.credential(r.credential?.idToken, r.credential?.accessToken);
    } else if (p === 'facebook') {
      const r = await FirebaseAuthentication.signInWithFacebook();
      cred = FacebookAuthProvider.credential(r.credential!.accessToken!);
    } else {
      const r = await FirebaseAuthentication.signInWithTwitter();
      cred = TwitterAuthProvider.credential(r.credential!.accessToken!, r.credential!.secret!);
    }
    return signInWithCredential(auth(), cred);
  }
  const provider: AuthProvider = p === 'google' ? new GoogleAuthProvider()
    : p === 'facebook' ? new FacebookAuthProvider() : new TwitterAuthProvider();
  return signInWithPopup(auth(), provider);
}

export async function registerEmail(name: string, email: string, password: string) {
  const r = await createUserWithEmailAndPassword(auth(), email, password);
  await updateProfile(r.user, { displayName: name });
  auth().languageCode = 'ar';
  await sendEmailVerification(r.user);
  return r.user;
}

export async function signInEmail(email: string, password: string) {
  return (await signInWithEmailAndPassword(auth(), email, password)).user;
}

export async function resendVerification() {
  const u = auth().currentUser;
  if (u) { auth().languageCode = 'ar'; await sendEmailVerification(u); }
}

/** Re-checks the verification flag after the user taps the link in their inbox. */
export async function checkVerified(): Promise<boolean> {
  const u = auth().currentUser;
  if (!u) return false;
  await reload(u);
  if (u.emailVerified) await u.getIdToken(true); // refresh token so the server sees email_verified
  return u.emailVerified;
}

export async function resetPassword(email: string) {
  auth().languageCode = 'ar';
  await sendPasswordResetEmail(auth(), email);
}

export async function logout() {
  if (native()) { try { await FirebaseAuthentication.signOut(); } catch { /* ignore */ } }
  await signOut(auth());
}

export function authErrorAr(e: any): string {
  const code: string = e?.code ?? '';
  const map: Record<string, string> = {
    'auth/invalid-email': 'الإيميل مو صحيح',
    'auth/email-already-in-use': 'الإيميل مسجل من قبل',
    'auth/weak-password': 'كلمة السر ضعيفة (6 أحرف على الأقل)',
    'auth/invalid-credential': 'الإيميل أو كلمة السر غلط',
    'auth/wrong-password': 'كلمة السر غلط',
    'auth/user-not-found': 'ما في حساب بهالإيميل',
    'auth/too-many-requests': 'محاولات كثيرة، انتظر شوي',
    'auth/popup-closed-by-user': 'تم إلغاء الدخول',
    'auth/account-exists-with-different-credential': 'هالإيميل مربوط بطريقة دخول ثانية',
    'auth/network-request-failed': 'تأكد من الإنترنت',
  };
  return map[code] ?? e?.message ?? 'صار خطأ';
}

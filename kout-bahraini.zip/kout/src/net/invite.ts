// Invite links that can be shared on WhatsApp or any app.
//   https://<project>.firebaseapp.com/j/<ROOM CODE>   → opens the app and joins that room
//   https://<project>.firebaseapp.com/m/<MAJLIS ID>   → opens the app and joins that Majlis
// The web page (hosting/join.html) hands the link to the app through koutbh://join/... or
// koutbh://majlis/..., and offers the download when the app is not installed.
import { Share } from '@capacitor/share';
import { firebaseConfig } from './firebase-config';
import { toast } from '../dom';

const base = () => `https://${firebaseConfig.authDomain || `${firebaseConfig.projectId}.firebaseapp.com`}`;

export const roomLink = (code: string) => `${base()}/j/${encodeURIComponent(code)}`;
export const majlisLink = (id: string) => `${base()}/m/${encodeURIComponent(id)}`;

export type InviteTarget = { kind: 'join'; code: string } | { kind: 'majlis'; id: string };

/** Reads koutbh://join/CODE, koutbh://majlis/ID, or the https form of either. */
export function parseInvite(url: string): InviteTarget | null {
  const m = url.match(/(?:koutbh:\/\/|\/)(join|j|majlis|m)\/([A-Za-z0-9_-]+)/);
  if (!m) return null;
  return m[1] === 'join' || m[1] === 'j' ? { kind: 'join', code: m[2].toUpperCase() } : { kind: 'majlis', id: m[2] };
}

/** Opens the phone's share sheet (WhatsApp, Instagram, SMS...), or copies the link as a fallback. */
export async function shareInvite(text: string, url: string) {
  try {
    await Share.share({ title: 'كوت بحريني', text, url, dialogTitle: 'ادعُ ربعك' });
  } catch {
    try { await navigator.clipboard.writeText(`${text}\n${url}`); toast('نسخنا الرابط، الصقه في الواتساب'); }
    catch { toast(url, 6000); }
  }
}

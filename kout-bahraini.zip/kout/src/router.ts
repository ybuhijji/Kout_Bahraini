export type Screen = 'home' | 'login' | 'verify' | 'play' | 'online' | 'room' | 'game' | 'majlis' | 'store' | 'profile' | 'settings' | 'rules';
type Render = (root: HTMLElement, params: any) => void | (() => void);

const screens = new Map<Screen, Render>();
let root: HTMLElement;
let cleanup: (() => void) | void;
let stack: { s: Screen; p: any }[] = [];

export function register(s: Screen, r: Render) { screens.set(s, r); }
export function setRoot(el: HTMLElement) { root = el; }

export function go(s: Screen, params: any = {}, opts: { replace?: boolean } = {}) {
  if (typeof cleanup === 'function') cleanup();
  if (opts.replace) stack.pop();
  if (s === 'home') stack = [];
  stack.push({ s, p: params });
  root.scrollTop = 0;
  cleanup = screens.get(s)!(root, params);
}

export function canGoBack() { return stack.length > 1; }

export function back() {
  stack.pop();
  const prev = stack.pop() ?? { s: 'home' as Screen, p: {} };
  go(prev.s, prev.p);
}

import { describe, expect, it } from 'vitest';
import { cardMoment } from './moments';

const t = (...cards: string[]) => cards.map((card, seat) => ({ seat, card }));

describe('voice moments', () => {
  it('Joker, whoever plays it', () => {
    expect(cardMoment(2, 'JK', 'H', t('7S', 'KS', 'JK'))).toBe('joker');
  });
  it('Ace of trump', () => {
    expect(cardMoment(0, 'AH', 'H', t('AH'))).toBe('trumpAce');
    expect(cardMoment(1, 'AH', 'H', t('7S', 'AH'))).toBe('trumpAce');
  });
  it('cutting an Ace of the led suit with trump', () => {
    expect(cardMoment(1, '7H', 'H', t('AS', '7H'))).toBe('cutAce');          // Ace led, then cut
    expect(cardMoment(2, '9H', 'H', t('8S', 'AS', '9H'))).toBe('cutAce');    // Ace played second, then cut
  });
  it('no voice for ordinary cards', () => {
    expect(cardMoment(1, '7H', 'H', t('KS', '7H'))).toBeNull();              // cut, but no Ace in the trick
    expect(cardMoment(1, 'KS', 'H', t('AS', 'KS'))).toBeNull();              // followed suit, not trump
    expect(cardMoment(1, '9H', 'H', t('AH', '9H'))).toBeNull();              // trump led: the Ace of trump is not "cut"
    expect(cardMoment(0, '7H', 'H', t('7H'))).toBeNull();                    // leading a trump
    expect(cardMoment(2, '8H', 'H', t('AD', 'KD', '8H').slice(0, 2).concat({ seat: 2, card: '8H' }))).toBe('cutAce');
    expect(cardMoment(1, '9D', null, t('AS', '9D'))).toBeNull();             // no trump chosen yet
  });
  it('an Ace played after the cut does not count', () => {
    expect(cardMoment(1, '7H', 'H', t('8S', '7H', 'AS'))).toBeNull();
  });
});

// Sound reactions. Real clips go in public/sounds/<slot id>.mp3 (licensed, see SOUNDS.md).
// Until a clip exists, each slot plays a short built-in tone so the game still has feedback.
import { SOUND_SLOTS, SoundSlot } from '../../shared/catalog';
import { settings } from '../settings';

let ctx: AudioContext | null = null;
const cache = new Map<string, HTMLAudioElement | null>();

function ac() {
  if (!ctx) ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
  if (ctx.state === 'suspended') ctx.resume();
  return ctx;
}

async function loadClip(id: string): Promise<HTMLAudioElement | null> {
  if (cache.has(id)) return cache.get(id)!;
  const url = `sounds/${id}.mp3`;
  try {
    const r = await fetch(url, { method: 'HEAD' });
    const ok = r.ok && !(r.headers.get('content-type') ?? '').includes('text/html');
    const a = ok ? new Audio(url) : null;
    cache.set(id, a);
    return a;
  } catch {
    cache.set(id, null);
    return null;
  }
}

// Fallback tones: [frequency Hz, duration s] sequences.
const TONES: Record<string, [number, number][]> = {
  kout: [[523, .12], [659, .12], [784, .12], [1047, .35]],
  match_win: [[523, .12], [659, .12], [784, .3]],
  match_lose: [[392, .2], [330, .2], [262, .4]],
  hand_made: [[660, .1], [880, .18]],
  hand_failed: [[300, .15], [220, .25]],
  khayes: [[200, .2], [150, .2], [100, .5]],
  inzeli_call: [[440, .1], [554, .1], [659, .1], [880, .25]],
  inzeli_made: [[784, .1], [988, .1], [1175, .1], [1568, .4]],
  turn: [[880, .07]],
  card: [[1400, .025]],
};

function tone(id: string) {
  const seq = TONES[id] ?? [[600 + (hash(id) % 600), .12], [500 + (hash(id) % 400), .15]];
  const c = ac();
  let t = c.currentTime;
  for (const [f, d] of seq) {
    const o = c.createOscillator();
    const g = c.createGain();
    o.type = id === 'card' ? 'triangle' : 'square';
    o.frequency.value = f;
    g.gain.setValueAtTime(0.08, t);
    g.gain.exponentialRampToValueAtTime(0.0001, t + d);
    o.connect(g).connect(c.destination);
    o.start(t); o.stop(t + d);
    t += d * 0.9;
  }
}

function hash(s: string) { let x = 0; for (const ch of s) x = (x * 31 + ch.charCodeAt(0)) >>> 0; return x; }

export async function play(id: string) {
  if (!settings.get().sound) return;
  const clip = await loadClip(id);
  if (clip) {
    try { clip.currentTime = 0; await clip.play(); return; } catch { /* fall through to tone */ }
  }
  try { tone(id); } catch { /* audio unavailable */ }
}

export function playAuto(trigger: NonNullable<SoundSlot['auto']>) {
  const slot = SOUND_SLOTS.find(s => s.auto === trigger);
  if (slot) play(slot.id);
}

export function cardTick() {
  if (settings.get().sound) try { tone('card'); } catch { /* ignore */ }
}

export function vibrate(ms = 30) {
  if (settings.get().vibrate && navigator.vibrate) navigator.vibrate(ms);
}

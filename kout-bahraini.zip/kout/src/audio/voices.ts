// Voice clips (public/sounds/voice_N.mp3) played on game moments and as player reactions.
// One voice at a time: game results cut in over anything; card moments wait their turn.
import { settings } from '../settings';

/** Which voices can play on each moment. One is picked at random, never the same twice in a row. */
export const VOICE_POOLS = {
  matchLost: ['voice_1', 'voice_2', 'voice_4', 'voice_5', 'voice_6', 'voice_8'],
  matchWon: ['voice_5', 'voice_7', 'voice_9'],
  joker: ['voice_2', 'voice_9'],
  cutAce: ['voice_3'],          // an Ace (not of trump) is cut with a trump card
  trumpAce: ['voice_7'],        // the Ace of trump is played
  ourBidFailed: ['voice_6'],    // teammate's "الشرهه على الي يابك"
} as const;

export type VoiceMoment = keyof typeof VOICE_POOLS;

const PRIORITY: Record<VoiceMoment | 'reaction', number> = {
  matchLost: 3, matchWon: 3, ourBidFailed: 2, reaction: 2, joker: 1, cutAce: 1, trumpAce: 1,
};
const CARD_MOMENT_GAP_MS = 4000;

const audio = new Map<string, HTMLAudioElement>();
const lastPicked = new Map<string, string>();
let current: { el: HTMLAudioElement; priority: number } | null = null;
let lastCardMoment = 0;

function clip(id: string) {
  let a = audio.get(id);
  if (!a) { a = new Audio(`sounds/${id}.mp3`); a.preload = 'auto'; audio.set(id, a); }
  return a;
}

/** Load every voice ahead of time so the first play is instant. */
export function preloadVoices() {
  for (const pool of Object.values(VOICE_POOLS)) for (const id of pool) clip(id);
}

function start(id: string, priority: number) {
  if (!settings.get().sound) return;
  const busy = current && !current.el.paused && !current.el.ended;
  if (busy && current!.priority > priority) return;   // something more important is playing
  if (busy) { current!.el.pause(); }
  const el = clip(id);
  try { el.currentTime = 0; } catch { /* not loaded yet */ }
  el.play().catch(() => { /* blocked or missing: stay silent */ });
  current = { el, priority };
}

/** Plays a random voice for a game moment. */
export function voiceFor(moment: VoiceMoment) {
  const priority = PRIORITY[moment];
  if (priority === 1) {
    if (Date.now() - lastCardMoment < CARD_MOMENT_GAP_MS) return;
    lastCardMoment = Date.now();
  }
  const pool = VOICE_POOLS[moment] as readonly string[];
  const options = pool.length > 1 ? pool.filter(id => id !== lastPicked.get(moment)) : pool;
  const id = options[Math.floor(Math.random() * options.length)];
  lastPicked.set(moment, id);
  if (import.meta.env.DEV) ((window as any).__voiceLog ??= []).push(`${moment}:${id}`);
  start(id, priority);
}

/** A voice a player picked from the reactions menu. */
export function playVoiceReaction(id: string) {
  start(id, PRIORITY.reaction);
}

export const isVoice = (id: string) => id.startsWith('voice_');

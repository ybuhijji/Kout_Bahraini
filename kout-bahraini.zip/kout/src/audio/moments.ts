import { Card, JOKER, PlayedCard, Suit, suitOf } from '../../shared/engine';
import type { VoiceMoment } from './voices';

/**
 * Which voice moment a played card is, if any:
 *  - the Joker
 *  - the Ace of trump
 *  - a trump card cutting a trick in which an Ace of the led (non-trump) suit was already played
 * `trick` is the trick the card belongs to, in play order (it may already be complete).
 */
export function cardMoment(seat: number, card: Card, trump: Suit | null, trick: PlayedCard[]): VoiceMoment | null {
  if (card === JOKER) return 'joker';
  if (!trump || suitOf(card) !== trump) return null;
  if (card === `A${trump}`) return 'trumpAce';
  const i = trick.findIndex(p => p.seat === seat && p.card === card);
  if (i <= 0) return null;
  const before = trick.slice(0, i);
  const led = suitOf(before[0].card);
  if (led && led !== trump && before.some(p => p.card === `A${led}`)) return 'cutAce';
  return null;
}

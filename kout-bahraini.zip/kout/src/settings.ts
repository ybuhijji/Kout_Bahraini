// Device-local settings and guest profile (stored in localStorage).
export interface Settings {
  sound: boolean;
  vibrate: boolean;
  theme: string;
  variant: 4 | 6;
  botLevel: 'easy' | 'normal' | 'hard';
  guestName: string;
  speed: 'slow' | 'normal' | 'fast';
}

const KEY = 'kout.settings.v1';
const defaults: Settings = {
  sound: true, vibrate: true, theme: 'classic', variant: 4, botLevel: 'normal',
  guestName: 'لاعب', speed: 'normal',
};

function load(): Settings {
  try { return { ...defaults, ...JSON.parse(localStorage.getItem(KEY) ?? '{}') }; } catch { return { ...defaults }; }
}

let current = load();
const listeners = new Set<(s: Settings) => void>();

export const settings = {
  get: () => current,
  set(patch: Partial<Settings>) {
    current = { ...current, ...patch };
    try { localStorage.setItem(KEY, JSON.stringify(current)); } catch { /* storage unavailable */ }
    listeners.forEach(l => l(current));
  },
  on(l: (s: Settings) => void) { listeners.add(l); return () => listeners.delete(l); },
};

export function delayMs(base: number) {
  const f = { slow: 1.5, normal: 1, fast: 0.5 }[current.speed];
  return base * f;
}

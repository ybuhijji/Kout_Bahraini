// الميالس (clans). مجلس = one clan.
import { h, mount, toast, confirmBox } from '../dom';
import { avatarNode } from './avatar';
import { go, register } from '../router';
import { profileStore } from '../net/profile';
import {
  Majlis, MajlisMember, ChatMsg, createMajlis, findMajlisByTag, getMajlis, joinMajlis, kickMember,
  leaveMajlis, promoteMember, sendChat, topMajalis, watchChat, watchMembers,
} from '../net/majlis';
import { createRoom, joinRoomById, watchMajlisRooms, Room } from '../net/online';
import { field, screen, topbar } from './common';
import { majlisLink, shareInvite } from '../net/invite';

const EMBLEMS = ['🏛️', '⚓', '🦅', '🐪', '🌴', '🦪', '⛵', '🔥', '🦁', '🗡️', '👑', '☕'];

register('majlis', root => {
  const p = profileStore.get();
  if (!p) { go('login', {}, { replace: true }); return; }
  if (p.majlisId) return myMajlis(root, p.majlisId);
  browse(root);
});

function browse(root: HTMLElement) {
  let list: Majlis[] = [];
  const search = h('input', { placeholder: 'دوّر بالرمز (مثال: MHQ)', dir: 'ltr', maxlength: 5 }) as HTMLInputElement;
  const draw = () => mount(root, screen(
    topbar('الميالس'),
    h('div', { class: 'card-panel col gap' },
      h('p', { class: 'muted' }, 'انضم لمجلس عشان تلعب مع ربعك، تسولف في الشات، وتجمع كؤوس للمجلس.'),
      h('button', { class: 'btn big primary', onclick: () => createForm(root) }, '➕ سوّ مجلس جديد (500 بيزة)'),
      h('div', { class: 'row gap' }, search, h('button', { class: 'btn', onclick: async () => {
        list = search.value.trim() ? await findMajlisByTag(search.value) : await topMajalis(); draw();
      } }, 'دوّر')),
      h('h3', {}, 'أقوى الميالس'),
      list.length ? h('div', { class: 'list' }, ...list.map(m => h('div', { class: 'list-row' },
        h('span', { class: 'emblem' }, m.emblem),
        h('div', { class: 'grow' }, h('b', {}, m.name), ' ', h('span', { class: 'tag' }, m.tag), h('div', { class: 'muted small' }, `${m.memberCount}/30 عضو · 🏆 ${m.trophies}`)),
        h('button', { class: 'btn small', disabled: !m.open, onclick: async () => {
          try { await joinMajlis(m.id); toast(`هلا فيك في مجلس ${m.name}`); go('majlis', {}, { replace: true }); }
          catch (e: any) { toast(e.message); }
        } }, m.open ? 'انضم' : 'مقفل'))))
        : h('p', { class: 'muted' }, 'ما في نتائج'))));
  draw();
  topMajalis().then(l => { list = l; draw(); }).catch(e => toast(e.message));
}

function createForm(root: HTMLElement) {
  const name = h('input', { maxlength: 24, placeholder: 'مجلس الربع' }) as HTMLInputElement;
  const tag = h('input', { maxlength: 5, placeholder: 'RBA', dir: 'ltr' }) as HTMLInputElement;
  const desc = h('textarea', { maxlength: 140, rows: 3, placeholder: 'نبذة عن المجلس' }) as HTMLTextAreaElement;
  let emblem = EMBLEMS[0];
  let open = true;
  const draw = () => mount(root, screen(
    topbar('مجلس جديد'),
    h('div', { class: 'card-panel col gap' },
      field('اسم المجلس', name), field('الرمز (2 إلى 5 حروف إنجليزي)', tag), field('النبذة', desc),
      h('h3', {}, 'الشعار'),
      h('div', { class: 'avatar-pick' }, ...EMBLEMS.map(e => h('button', { class: emblem === e ? 'on' : '', onclick: () => { emblem = e; draw(); } }, e))),
      h('label', { class: 'toggle' }, h('input', { type: 'checkbox', checked: open, onchange: (e: Event) => { open = (e.target as HTMLInputElement).checked; } }), h('span', {}, 'مفتوح للكل')),
      h('button', { class: 'btn primary', onclick: async () => {
        try {
          await createMajlis({ name: name.value, tag: tag.value, description: desc.value, open, emblem });
          toast('تم إنشاء المجلس'); go('majlis', {}, { replace: true });
        } catch (e: any) { toast(e.message); }
      } }, 'سوّ المجلس'))));
  draw();
}

function myMajlis(root: HTMLElement, id: string) {
  const me = profileStore.get()!;
  let m: Majlis | null = null;
  let members: MajlisMember[] = [];
  let chat: ChatMsg[] = [];
  let rooms: Room[] = [];
  let tab: 'chat' | 'members' | 'tables' = 'chat';
  const input = h('input', { placeholder: 'اكتب رسالة…', maxlength: 300 }) as HTMLInputElement;

  const send = async () => { const t = input.value; input.value = ''; await sendChat(id, me.uid, me.name, t).catch(e => toast(e.message)); };
  input.addEventListener('keydown', e => { if (e.key === 'Enter') send(); });

  const myRole = () => members.find(x => x.uid === me.uid)?.role ?? 'member';

  const draw = () => {
    if (!m) { mount(root, screen(topbar('مجلسي'), h('div', { class: 'spinner' }))); return; }
    const body = tab === 'chat'
      ? h('div', { class: 'chat' },
        h('div', { class: 'chat-log' }, ...chat.map(c => h('div', { class: `msg${c.uid === me.uid ? ' mine' : ''}` }, h('b', {}, c.name), h('span', {}, c.text)))),
        h('div', { class: 'row gap' }, input, h('button', { class: 'btn primary', onclick: send }, 'أرسل')))
      : tab === 'members'
        ? h('div', { class: 'list' }, ...members.map(x => h('div', { class: 'list-row' },
          h('span', { class: 'emblem member-pic' }, avatarNode(x.avatar)),
          h('div', { class: 'grow' }, h('b', {}, x.name), h('div', { class: 'muted small' }, `${{ owner: 'صاحب المجلس', elder: 'كبير', member: 'عضو' }[x.role]} · فوز ${x.wins}`)),
          myRole() !== 'member' && x.uid !== me.uid && x.role !== 'owner' ? h('div', { class: 'row gap' },
            myRole() === 'owner' && x.role === 'member' ? h('button', { class: 'btn small', onclick: () => promoteMember(x.uid).catch(e => toast(e.message)) }, 'رقّي') : null,
            h('button', { class: 'btn small danger', onclick: async () => { if (await confirmBox(`تطلع ${x.name} من المجلس؟`)) kickMember(x.uid).catch(e => toast(e.message)); } }, 'طلّع')) : null)))
        : h('div', { class: 'col gap' },
          h('div', { class: 'row gap' },
            h('button', { class: 'btn primary', onclick: () => createRoom(4, id).then(r => go('room', { roomId: r.roomId })).catch(e => toast(e.message)) }, '➕ طاولة بو 4'),
            h('button', { class: 'btn primary', onclick: () => createRoom(6, id).then(r => go('room', { roomId: r.roomId })).catch(e => toast(e.message)) }, '➕ طاولة بو 6')),
          rooms.length ? h('div', { class: 'list' }, ...rooms.map(r => h('div', { class: 'list-row' },
            h('div', { class: 'grow' }, h('b', {}, `كوت بو ${r.variant}`), h('div', { class: 'muted small' }, `${r.seats.filter(Boolean).length}/${r.variant} · ${r.seats.find(s => s?.uid === r.hostUid)?.name ?? ''}`)),
            h('button', { class: 'btn small', onclick: () => joinRoomById(r.id).then(x => go('room', { roomId: x.roomId })).catch(e => toast(e.message)) }, 'اقعد'))))
            : h('p', { class: 'muted' }, 'ما في طاولات مفتوحة في المجلس'));
    mount(root, screen(
      topbar(`${m.emblem} ${m.name}`),
      h('div', { class: 'card-panel col gap' },
        h('div', { class: 'majlis-head' }, h('span', { class: 'tag' }, m.tag), h('span', {}, `👥 ${m.memberCount}/30`), h('span', {}, `🏆 ${m.trophies}`)),
        h('button', { class: 'btn', onclick: () => shareInvite(`تعال انضم لمجلس ${m!.name} في كوت بحريني 🃏`, majlisLink(id)) }, '📤 ادعُ ربعك للمجلس'),
        m.description ? h('p', { class: 'muted' }, m.description) : null,
        h('div', { class: 'seg' },
          h('button', { class: tab === 'chat' ? 'on' : '', onclick: () => { tab = 'chat'; draw(); } }, 'السوالف'),
          h('button', { class: tab === 'tables' ? 'on' : '', onclick: () => { tab = 'tables'; draw(); } }, 'الطاولات'),
          h('button', { class: tab === 'members' ? 'on' : '', onclick: () => { tab = 'members'; draw(); } }, 'الأعضاء')),
        body,
        h('button', { class: 'link small', onclick: async () => {
          if (await confirmBox('تطلع من المجلس؟')) { try { await leaveMajlis(); go('majlis', {}, { replace: true }); } catch (e: any) { toast(e.message); } }
        } }, 'اطلع من المجلس'))));
    const log = root.querySelector('.chat-log');
    if (log) log.scrollTop = log.scrollHeight;
  };

  getMajlis(id).then(x => { m = x; draw(); });
  const u1 = watchMembers(id, x => { members = x; if (tab === 'members') draw(); });
  const u2 = watchChat(id, x => { chat = x; if (tab === 'chat') { const focused = document.activeElement === input; draw(); if (focused) input.focus(); } });
  const u3 = watchMajlisRooms(id, x => { rooms = x; if (tab === 'tables') draw(); });
  draw();
  return () => { u1(); u2(); u3(); };
}

import { h, mount, toast } from '../dom';
import { go, register } from '../router';
import { settings } from '../settings';
import { onlineConfigured } from '../net/firebase';
import { demoMode, isVerified, profileStore } from '../net/profile';
import { LocalController } from '../game/controller';
import { renderTable } from './table';
import { field, screen, topbar } from './common';
import { ITEM_BY_ID, THEMES } from '../../shared/catalog';
import { WIN_SCORE } from '../../shared/engine';

function needOnline(then: () => void) {
  if (demoMode) { then(); return; }
  if (!onlineConfigured) { toast('اللعب أونلاين يحتاج إعداد Firebase (شوف SETUP.md)'); return; }
  const u = profileStore.user();
  if (!u) { go('login', { next: 'online' }); return; }
  if (!isVerified(u)) { go('verify'); return; }
  then();
}

register('home', root => {
  const draw = () => {
    const p = profileStore.get();
    const name = p?.name ?? settings.get().guestName;
    mount(root, screen(
      h('div', { class: 'home-head' },
        h('button', { class: 'chip', onclick: () => (p ? go('profile') : go('login')) },
          h('span', { class: 'emoji' }, p?.avatar && !p.avatar.startsWith('http') ? p.avatar : '🧔'),
          h('span', {}, name),
          p?.equipped?.accessory ? h('span', {}, ITEM_BY_ID[p.equipped.accessory]?.emoji ?? '') : null),
        p ? h('button', { class: 'chip coins', onclick: () => go('store', { tab: 'coins' }) }, `🪙 ${p.coins.toLocaleString('en-US')}`) : null),
      h('div', { class: 'logo' },
        h('div', { class: 'logo-cards' }, '♠ ♥ ♣ ♦'),
        h('h1', {}, 'كوت'),
        h('div', { class: 'sub' }, 'النسخة البحرينية')),
      h('div', { class: 'menu' },
        h('button', { class: 'btn big primary', onclick: () => needOnline(() => go('online')) }, '🌐 العب أونلاين'),
        h('button', { class: 'btn big', onclick: () => go('play') }, '🤖 العب ضد الكمبيوتر'),
        h('button', { class: 'btn big', onclick: () => needOnline(() => go('majlis')) }, '🏛️ الميالس'),
        h('button', { class: 'btn big', onclick: () => needOnline(() => go('store')) }, '🛍️ المتجر'),
        h('div', { class: 'row gap' },
          h('button', { class: 'btn', onclick: () => go('rules') }, '📜 القوانين'),
          h('button', { class: 'btn', onclick: () => go('settings') }, '⚙️ الإعدادات'))),
      !onlineConfigured ? h('p', { class: 'muted small center' }, 'وضع بدون إنترنت') : null));
  };
  draw();
  return profileStore.on(() => draw());
});

register('play', root => {
  let variant = settings.get().variant;
  let level = settings.get().botLevel;
  const owned = new Set(profileStore.get()?.owned ?? []);
  const themes = THEMES.filter(t => !t.item || owned.has(t.item));
  let theme = themes.find(t => t.id === settings.get().theme)?.id ?? 'classic';
  const draw = () => mount(root, screen(
    topbar('ضد الكمبيوتر'),
    h('div', { class: 'card-panel col gap' },
      h('h3', {}, 'نوع اللعبة'),
      h('div', { class: 'seg' },
        h('button', { class: variant === 4 ? 'on' : '', onclick: () => { variant = 4; draw(); } }, 'كوت بو 4', h('small', {}, '32 ورقة')),
        h('button', { class: variant === 6 ? 'on' : '', onclick: () => { variant = 6; draw(); } }, 'كوت بو 6', h('small', {}, '48 ورقة'))),
      h('h3', {}, 'مستوى الكمبيوتر'),
      h('div', { class: 'seg' },
        ...(['easy', 'normal', 'hard'] as const).map(l => h('button', { class: level === l ? 'on' : '', onclick: () => { level = l; draw(); } },
          { easy: 'سهل', normal: 'عادي', hard: 'صعب' }[l]))),
      h('h3', {}, 'الطاولة'),
      h('div', { class: 'seg wrap' }, ...themes.map(t => h('button', { class: theme === t.id ? 'on' : '', onclick: () => { theme = t.id; draw(); } },
        h('span', { class: 'swatch', style: { background: t.felt } }), t.name))),
      h('button', { class: 'btn big primary', onclick: start }, 'يلا نلعب')),
  ));
  function start() {
    settings.set({ variant, botLevel: level, theme });
    go('game', { local: true, variant, theme });
  }
  draw();
});

register('settings', root => {
  const s = settings.get();
  const name = h('input', { value: s.guestName, maxlength: 16 }) as HTMLInputElement;
  const toggle = (k: 'sound' | 'vibrate', label: string) => h('label', { class: 'toggle' },
    h('input', { type: 'checkbox', checked: s[k], onchange: (e: Event) => settings.set({ [k]: (e.target as HTMLInputElement).checked }) }),
    h('span', {}, label));
  mount(root, screen(
    topbar('الإعدادات'),
    h('div', { class: 'card-panel col gap' },
      field('اسمك (بدون حساب)', name),
      toggle('sound', 'الأصوات'),
      toggle('vibrate', 'الاهتزاز'),
      h('h3', {}, 'سرعة اللعب'),
      h('div', { class: 'seg' }, ...(['slow', 'normal', 'fast'] as const).map(sp =>
        h('button', { class: s.speed === sp ? 'on' : '', onclick: () => { settings.set({ speed: sp }); go('settings', {}, { replace: true }); } },
          { slow: 'بطيء', normal: 'عادي', fast: 'سريع' }[sp]))),
      h('button', { class: 'btn primary', onclick: () => { settings.set({ guestName: name.value.trim() || 'لاعب' }); toast('تم الحفظ'); } }, 'حفظ'))));
});

register('rules', root => {
  mount(root, screen(
    topbar('قوانين الكوت البحريني'),
    h('div', { class: 'card-panel rules' },
      h('h3', {}, 'اللاعبين والورق'),
      h('ul', {},
        h('li', {}, 'كوت بو 4: فريقين كل فريق 2، و32 ورقة: الجوكر، ومن 7 إلى الإكة في السبيت والهاس والشريها، ومن 8 إلى الإكة في الديمن.'),
        h('li', {}, 'كوت بو 6: فريقين كل فريق 3، و48 ورقة: الجوكر، ومن 3 إلى الإكة في السبيت والهاس والشريها، ومن 4 إلى الإكة في الديمن.'),
        h('li', {}, 'كل لاعب ياخذ 8 ورقات، واللعب عكس عقارب الساعة.')),
      h('h3', {}, 'الأوراق'),
      h('ul', {},
        h('li', {}, 'الجوكر الأحمر أقوى ورقة في اللعبة، أقوى من إكة الحكم.'),
        h('li', {}, 'بعده الإكة ثم الشايب ثم البنت ثم الولد ثم الأرقام. الحكم يغلب أي لون ثاني.')),
      h('h3', {}, 'الطلبات'),
      h('ul', {},
        h('li', {}, 'الطلبات: 5، 6، 7، وانزلي (كل الأكلات الـ8).'),
        h('li', {}, 'اللي يفوز بالمزاد يختار الحكم، واللي على يمينه يبدي اللعب.'),
        h('li', {}, 'إذا الكل باس، يتوزع الورق من جديد.')),
      h('h3', {}, 'اللعب'),
      h('ul', {},
        h('li', {}, 'لازم تنزل من نفس اللون إذا عندك. إذا ما عندك، تقدر تنزل أي ورقة أو تحكم.'),
        h('li', {}, 'الجوكر ينلعب في أي وقت إلا إنك تبدي فيه.'),
        h('li', {}, 'خيس الجوكر: إذا اضطريت تبدي بالجوكر (آخر ورقة عندك)، فريقك يخسر اللعبة.')),
      h('h3', {}, 'الحساب'),
      h('ul', {},
        h('li', {}, 'الطلبة الناجحة تحسب بقيمتها (5 أو 6 أو 7). الطلبة اللي تطيح تنحسب ضعف للفريق الثاني (10 أو 12 أو 14).'),
        h('li', {}, `النتيجة وحدة بين الفريقين وتتحرك لجهة اللي يكسب. أول فريق يوصل ${WIN_SCORE} يفوز.`),
        h('li', {}, 'مثال: فزتوا بطلبة 5 (لكم 5)، بعدين طاحت طلبتكم 5 (ناقص 10)، تصير النتيجة 5 للفريق الثاني.')),
      h('h3', {}, 'انزلي'),
      h('ul', {},
        h('li', {}, 'مسموحة في أي يد إلا أول يد، وبس اللي عنده الجوكر يقدر يطلبها.'),
        h('li', {}, 'إذا نجحت، فريقه يفوز باللعبة على طول. إذا طاحت، الفريق الثاني يفوز.')),
      h('h3', {}, 'الكوت'),
      h('p', {}, `الكوت هو الفوز باللعبة: يا توصل ${WIN_SCORE} أول، يا تنجح في انزلي.`))));
});

register('game', (root, p: { local?: boolean; variant?: 4 | 6; theme?: string; ctrl?: any; room?: any }) => {
  if (p.local) {
    const prof = profileStore.get();
    const ctrl = new LocalController(p.variant ?? 4, {
      name: prof?.name ?? settings.get().guestName, bot: false,
      avatar: prof?.avatar && !prof.avatar.startsWith('http') ? prof.avatar : '😎',
      accessory: prof?.equipped?.accessory,
    });
    const t = renderTable(root, ctrl, {
      themeId: p.theme,
      onExit: () => go('home'),
      onRematch: () => go('game', p, { replace: true }),
    });
    return t.teardown;
  }
  const t = renderTable(root, p.ctrl, { themeId: p.theme, onExit: () => go('home') });
  return t.teardown;
});

export { needOnline };

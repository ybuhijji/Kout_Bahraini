// Every message shown on the table, in one place so the wording is easy to change.
// "we" = the reader's own team. {name}, {bid}, {n}, {p} are filled in by the game.

export const T = {
  // ---------- تحكيم (bidding) ----------
  biddingLabel: 'تحكيم',                         // shown in the top box while bids are being made
  yourBid: 'شنو طلبتك؟',                          // your turn to bid, nobody has bid yet
  highestBid: 'أعلى طلبة {bid} ({name})',          // your turn, someone has already bid
  lastToBid: 'الكل باس: تطلب ولا نوزع من جديد؟',   // everyone else passed
  pass: 'باس',
  reshuffle: '🔀 وزّع من جديد',
  othersBidding: '{name} يطلب…',
  pickTrump: 'اختار الحكم',
  othersPickTrump: '{name} يختار الحكم…',
  noInzeliFirstHand: 'انزلي مو مسموحة في أول يد',
  allPassed: 'الكل باس.. توزيع جديد',

  // ---------- dealer ----------
  drawTitle: 'سحب الورق: أقل ورقة توزع',
  drawTie: 'تعادل.. سحبوا مرة ثانية',
  dealerIs: '{name} يوزع',
  dealerBadge: 'يوزع',

  // ---------- end of a hand ----------
  handWeMade: 'فزنا',                             // our team bid and made it
  handWeFailed: 'خسرنا',                          // our team bid and failed
  handTheyMade: 'فازو',                           // their team bid and made it
  handTheyFailed: 'خسرو',                         // their team bid and failed
  handDetailMade: '{name} دش {bid} وفازو',         // detail line when the bid was made
  handDetailFailed: '{name} دش {bid} وخسرو',       // detail line when the bid failed
  pointsUs: '+{p} لنا',
  pointsThem: '+{p} لهم',
  scoreUsAhead: 'احنا مجدمين {n}',
  scoreThemAhead: 'اهمه مجدمين {n}',
  scoreLevel: 'بشرف',
  nextHandButton: 'اليد الياية',
  nextHandSoon: 'اصبُر',

  // ---------- end of the game ----------
  matchWonTitle: 'كوتناهم السهليين',
  matchLostTitle: 'كوتوونا',
  wonByPoints: 'وصلنا',
  lostByPoints: 'وصلوا',
  wonByInzeli: 'كوتناهم',                        // our Inzeli made
  lostByInzeli: 'كوتوونا',                       // their Inzeli made
  wonByTheirInzeliFailing: 'كوتناهم',            // their Inzeli failed, so we win
  lostByOurInzeliFailing: 'كوت علينا',           // our Inzeli failed, so they win
  wonByKhayes: 'خييس الجوكر: {name} بدا بالجوكر',   // a player on their team led the Joker
  lostByKhayes: 'خييسنا الجوكر: {name} بدا بالجوكر', // a player on our team led the Joker
  coinsUpdated: 'تم إيداع الراتب بنجاح',
  playAgain: 'قيم ثاني',
  home: 'الرئيسية',
};

/** Fills {placeholders} in a message. */
export function t(text: string, vars: Record<string, string | number> = {}) {
  return text.replace(/\{(\w+)\}/g, (_, k) => String(vars[k] ?? ''));
}

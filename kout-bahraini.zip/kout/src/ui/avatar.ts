// One place that turns a player's avatar value into something to show:
// a character id (char_*) shows its picture, a web address shows that photo, anything else is an emoji.
import { h } from '../dom';
import { isCharacter, ITEM_BY_ID } from '../../shared/catalog';

export const characterSrc = (id: string, full = false) => `characters/${id}${full ? '_full' : ''}.webp`;

export function avatarNode(a?: string | null, fallback = '🧔') {
  if (isCharacter(a)) return h('img', { class: 'char', src: characterSrc(a!), alt: ITEM_BY_ID[a!].name, draggable: false });
  if (a && /^https?:/.test(a)) return h('img', { src: a, referrerpolicy: 'no-referrer', alt: '' });
  return h('span', { class: 'emoji' }, a || fallback);
}

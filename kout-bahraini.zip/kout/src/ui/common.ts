import { h } from '../dom';
import { back } from '../router';
import { profileStore } from '../net/profile';

export function topbar(title: string, right?: Node | null) {
  return h('div', { class: 'topbar' },
    h('button', { class: 'icon-btn', onclick: back, title: 'رجوع' }, '→'),
    h('h2', {}, title),
    right ?? h('span', { class: 'coins' }, coinsLabel()));
}

export function coinsLabel() {
  const p = profileStore.get();
  return p ? `🪙 ${p.coins.toLocaleString('en-US')}` : '';
}

export function screen(...children: (Node | null)[]) {
  return h('div', { class: 'screen' }, ...children);
}

export function field(label: string, input: HTMLElement) {
  return h('label', { class: 'field' }, h('span', {}, label), input);
}

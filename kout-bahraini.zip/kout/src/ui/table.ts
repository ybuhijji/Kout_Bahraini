import {
  BidValue, Card, GameEvent, INZELI, JOKER, SUITS, SUIT_NAME_AR, SUIT_SYMBOL, Suit, WIN_SCORE,
  isLastToBid, legalBids, legalCards, mustLeadTrump, suitOf, teamOf, trickWinner, tricksNeeded,
} from '../../shared/engine';
import { ITEM_BY_ID, SOUND_SLOTS, THEMES } from '../../shared/catalog';
import { confirmBox, h, modal, mount, toast } from '../dom';
import { GameController, LocalController, ViewState } from '../game/controller';
import { cardBack, cardEl } from './cards';
import { cardSwish, cardTick, play, playAuto, preloadCardSounds, vibrate } from '../audio/sounds';
import { settings } from '../settings';
import { profileStore } from '../net/profile';

const POS4 = ['p-bottom', 'p-right', 'p-top', 'p-left'];
const POS6 = ['p-bottom', 'p-bright', 'p-tright', 'p-top', 'p-tleft', 'p-bleft'];
const SWIPE_PX = 45;

export function bidLabel(b: BidValue) { return b === INZELI ? 'انزلي' : String(b); }

export interface TableOpts {
  onExit: () => void;
  onRematch?: () => void;
  themeId?: string;
}

function actorOf(s: ViewState): number | null {
  if (s.phase === 'bidding') return s.bidTurn;
  if (s.phase === 'trump') return s.bidder;
  if (s.phase === 'playing') return s.turn;
  return null;
}

/**
 * The table is built once. Each part (header, seats, played cards, hand, buttons) keeps a
 * signature of what it shows and is redrawn only when that changes, so animations and timers
 * are not restarted by unrelated updates.
 */
export function renderTable(root: HTMLElement, ctrl: GameController, opts: TableOpts) {
  const theme = THEMES.find(t => t.id === (opts.themeId ?? settings.get().theme)) ?? THEMES[0];
  const n = ctrl.view().players;
  const pos = n === 4 ? POS4 : POS6;
  const rel = (seat: number) => (seat - ctrl.mySeat + n) % n;
  const myTeam = teamOf(ctrl.mySeat);
  let closeModal: (() => void) | null = null;
  let modalKind: 'hand' | 'match' | null = null;   // which result box is open
  let shownHandKey = '';
  let matchShown = false;
  let selected: Card | null = null;          // card raised by a first tap
  let lastTurnKey = '';
  const animated = new Set<string>();        // played cards already animated in this trick
  let flying: Card | null = null;            // my card currently in the air (hidden on the table until it lands)
  preloadCardSounds();
  const deadlineTotals = new Map<number, number>();
  const sig: Record<string, string> = {};

  // ---------- skeleton ----------
  const el = h('div', { class: `table-screen n${n}` });
  el.style.setProperty('--felt', theme.felt);
  el.style.setProperty('--felt2', theme.felt2);
  el.style.setProperty('--accent', theme.accent);
  el.style.setProperty('--rim', theme.rim);

  const headerSlot = h('div', { class: 'tbl-head' });
  const seatInner: HTMLElement[] = [];
  const seatBox: HTMLElement[] = [];
  const reactBubbles: HTMLElement[] = [];
  for (let seat = 0; seat < n; seat++) {
    const inner = h('div', { class: 'seat-inner' });
    const bubble = h('div', { class: 'react-bubble' });
    const box = h('div', { class: `seat ${pos[rel(seat)]}`, 'data-seat': seat }, inner, bubble);
    seatInner.push(inner); seatBox.push(box); reactBubbles.push(bubble);
  }
  const trickSlot = h('div', { class: 'trick' });
  const felt = h('div', { class: 'felt' },
    theme.crest ? h('img', { class: 'crest', src: theme.crest, onerror: (e: Event) => (e.target as HTMLElement).remove() }) : null,
    h('div', { class: 'felt-logo' }, 'كوت'),
    ...seatBox, trickSlot);
  const handSlot = h('div', { class: 'hand' });
  const panelSlot = h('div', { class: 'panel-slot' });
  const ring = h('div', { class: 'timer' });
  el.append(headerSlot, felt, handSlot, panelSlot);
  mount(root, el);

  function seatName(seat: number) {
    return seat === ctrl.mySeat ? 'أنت' : ctrl.seats[seat]?.name ?? `لاعب ${seat + 1}`;
  }

  /** Redraws a part only when its signature changed. */
  function part(key: string, signature: string, draw: () => void) {
    if (sig[key] === signature) return;
    sig[key] = signature;
    draw();
  }

  // ---------- render ----------
  function render() {
    const s = ctrl.view();
    const pending = ctrl.pending?.() ?? false;

    part('header', JSON.stringify([s.score, s.bid, s.bidder, s.trump, s.tricksWon, s.phase === 'bidding']), () => drawHeader(s));
    for (let seat = 0; seat < n; seat++) {
      const lastBid = s.phase === 'bidding' ? [...s.bidLog].reverse().find(b => b.seat === seat)?.bid ?? '' : '';
      const info = ctrl.seats[seat];
      part(`seat${seat}`, JSON.stringify([actorOf(s) === seat, s.handCounts[seat], lastBid, s.bidder === seat && s.phase !== 'bidding' ? s.bid : null, info?.name, info?.accessory, info?.avatar, info?.bot, ctrl.seatAway?.(seat) ?? false]),
        () => drawSeat(s, seat));
    }
    const tKey = s.trick.length ? s.trick : s.lastTrick ?? [];
    part('trick', JSON.stringify([s.phase, tKey, s.trick.length === 0 ? s.lastTrickWinner : null, s.handNo]), () => drawTrick(s));
    const hand = s.hands[ctrl.mySeat] ?? [];
    const myTurn = s.phase === 'playing' && s.turn === ctrl.mySeat;
    part('hand', JSON.stringify([hand, myTurn, pending, s.trump, s.trick.length, selected, mustLeadTrump(s, ctrl.mySeat), ctrl.away?.() ?? false]), () => drawHand(s));
    syncModals(s);
    part('panel', JSON.stringify([s.phase, s.bidTurn, s.bidder, s.highBid, s.bidLog.length, pending, s.handNo, s.redeals]), () => drawPanel(s));
    placeTimer(s);
  }

  function drawHeader(s: ViewState) {
    const myScore = myTeam === 0 ? s.score : -s.score;
    const pct = Math.max(-1, Math.min(1, myScore / WIN_SCORE));
    headerSlot.replaceChildren(
      h('button', { class: 'icon-btn', onclick: exit, title: 'خروج' }, '✕'),
      h('div', { class: 'scorebox' },
        h('div', { class: 'score-labels' },
          h('span', { class: myScore > 0 ? 'lead us' : 'us' }, `نحن ${myScore > 0 ? myScore : 0}`),
          h('span', { class: 'target' }, `الهدف ${WIN_SCORE}`),
          h('span', { class: myScore < 0 ? 'lead them' : 'them' }, `هم ${myScore < 0 ? -myScore : 0}`)),
        h('div', { class: 'meter' },
          h('div', { class: 'meter-fill', style: {
            width: `${Math.abs(pct) * 50}%`,
            [pct >= 0 ? 'right' : 'left']: '50%',
            background: pct >= 0 ? 'var(--us)' : 'var(--them)',
          } }),
          h('div', { class: 'meter-mid' }))),
      contractBox(s),
      h('button', { class: 'icon-btn', onclick: openReactions, title: 'تفاعل' }, '🔊'));
  }

  function contractBox(s: ViewState) {
    if (s.bid && s.bidder !== null) {
      const us = teamOf(s.bidder) === myTeam;
      const need = tricksNeeded(s.bid);
      const got = s.tricksWon[teamOf(s.bidder)];
      return h('div', { class: `contract ${us ? 'us' : 'them'}` },
        h('div', { class: 'c-bid' }, bidLabel(s.bid)),
        s.trump ? h('div', { class: `c-trump ${s.trump === 'H' || s.trump === 'D' ? 'red' : ''}` }, SUIT_SYMBOL[s.trump]) : h('div', { class: 'c-trump' }, '…'),
        h('div', { class: 'c-prog' }, `${got}/${need}`));
    }
    return h('div', { class: 'contract empty' }, h('div', { class: 'c-bid' }, s.phase === 'bidding' ? 'مزاد' : ''));
  }

  function drawSeat(s: ViewState, seat: number) {
    const info = ctrl.seats[seat] ?? { name: '…', bot: true };
    const r = rel(seat);
    const active = actorOf(s) === seat;
    const lastBid = [...s.bidLog].reverse().find(b => b.seat === seat);
    const acc = info.accessory ? ITEM_BY_ID[info.accessory] : null;
    const isBidder = s.bidder === seat && s.phase !== 'bidding';
    seatBox[seat].className = `seat ${pos[r]} ${teamOf(seat) === myTeam ? 'us' : 'them'}${active ? ' active' : ''}`;
    seatInner[seat].replaceChildren(
      r === 0 ? h('span') : h('div', { class: 'seat-cards' }, cardBack(), h('span', { class: 'cnt' }, String(s.handCounts[seat]))),
      h('div', { class: 'avatar' },
        avatarContent(info.avatar),
        acc ? h('span', { class: 'acc', title: acc.name }, acc.emoji) : null,
        isBidder ? h('span', { class: 'bidder-badge' }, bidLabel(s.bid!)) : null),
      h('div', { class: 'seat-name' }, info.majlis ? h('span', { class: 'tag' }, info.majlis) : null, seatName(seat), info.bot && ctrl.online ? ' 🤖' : ''),
      ctrl.seatAway?.(seat) ? h('div', { class: 'away-badge' }, '🤖 بوت يلعب بداله') : h('span'),
      s.phase === 'bidding' && lastBid ? h('div', { class: `bubble ${lastBid.bid === 'pass' ? 'pass' : ''}` }, lastBid.bid === 'pass' ? 'باس' : bidLabel(lastBid.bid)) : h('span'));
  }

  function avatarContent(a?: string | null) {
    if (a && /^https?:/.test(a)) return h('img', { src: a, referrerpolicy: 'no-referrer' });
    return h('span', { class: 'emoji' }, a ?? '🧔');
  }

  function drawTrick(s: ViewState) {
    const showing = s.trick.length ? s.trick : s.lastTrick ?? [];
    const finished = !s.trick.length && !!s.lastTrick && s.phase === 'playing';
    const winner = finished && s.lastTrickWinner !== null ? s.lastTrickWinner : null;
    const leading = s.trick.length > 1 && s.trump ? trickWinner(s.trick, s.trump).seat : null;
    if (!s.trick.length && !finished) animated.clear();
    if (!(s.phase === 'playing' || s.phase === 'handOver' || s.phase === 'matchOver')) { trickSlot.replaceChildren(); animated.clear(); return; }
    trickSlot.replaceChildren(...showing.map(p => {
      const c = cardEl(p.card, { small: true });
      c.classList.add('played', `from-${pos[rel(p.seat)]}`);
      const key = `${p.seat}:${p.card}`;
      if (!animated.has(key)) { c.classList.add('fresh'); animated.add(key); }
      if (s.trump && suitOf(p.card) === s.trump) c.classList.add('trump');
      if (winner !== null) c.classList.add('collect', `to-${pos[rel(winner)]}`);
      if (p.seat === leading) c.classList.add('winning');
      if (p.seat === ctrl.mySeat && p.card === flying) c.style.visibility = 'hidden';
      return c;
    }));
    if (winner !== null) animated.clear();
  }

  function drawHand(s: ViewState) {
    const raw = s.hands[ctrl.mySeat] ?? [];
    const myTurn = s.phase === 'playing' && s.turn === ctrl.mySeat;
    const pending = ctrl.pending?.() ?? false;
    const legal = new Set(myTurn && !pending ? legalCards(s, ctrl.mySeat) : []);
    // Trumps (and the Joker) first, so your strong cards sit together.
    const isTrump = (c: Card) => c === JOKER || (!!s.trump && suitOf(c) === s.trump);
    const hand = s.trump ? [...raw.filter(isTrump), ...raw.filter(c => !isTrump(c))] : raw;
    if (selected && !legal.has(selected)) selected = null;

    const jokerWarn = myTurn && raw.includes(JOKER) && raw.length <= 3 && s.trick.length > 0;
    let hint = '';
    if (myTurn && !pending) {
      if (mustLeadTrump(s, ctrl.mySeat) && [...legal].some(c => suitOf(c) === s.trump)) hint = 'انزلي: لازم تبدي بحكم';
      else if (jokerWarn) hint = 'انتبه: تخلص من الجوكر قبل ما يصير آخر ورقة (خيس)';
      else hint = (s.trick.length === 0 ? 'دورك تبدي' : 'دورك') + ' · اسحب الورقة لفوق';
    }
    handSlot.className = `hand${myTurn ? ' my-turn' : ''}`;
    if (ctrl.away?.()) {
      handSlot.replaceChildren(
        h('div', { class: 'away-banner' },
          h('span', {}, '🤖 الكمبيوتر يلعب بدالك'),
          h('button', { class: 'btn primary small', onclick: async (ev: Event) => {
            const b = ev.currentTarget as HTMLButtonElement;
            b.disabled = true; b.textContent = 'لحظة…';
            try { await ctrl.rejoin!(); } catch (e: any) { toast(e.message); b.disabled = false; b.textContent = 'ارجع للعب'; }
          } }, 'ارجع للعب')),
        h('div', { class: 'hand-cards dim-all', style: { '--count': String(hand.length) } }, ...hand.map(c => cardEl(c))));
      return;
    }
    handSlot.replaceChildren(
      h('div', { class: `hint${jokerWarn || hint.startsWith('انزلي') ? ' warn' : ''}` }, hint),
      h('div', { class: 'hand-cards', style: { '--count': String(hand.length) } },
        ...hand.map((c, i) => {
          const isLegal = legal.has(c);
          const e = cardEl(c, { legal: myTurn ? isLegal : undefined });
          if (s.trump && isTrump(c)) e.classList.add('trump');
          if (selected === c) e.classList.add('selected');
          e.style.setProperty('--i', String(i));
          attachGesture(e, c, isLegal, s);
          return e;
        })));
  }

  /** Swipe a card up to play it. A tap raises it; a second tap plays it. */
  function attachGesture(e: HTMLElement, c: Card, isLegal: boolean, s: ViewState) {
    let startX = 0, startY = 0, dragging = false, moved = false, scale = 1, rot = 0;
    e.addEventListener('pointerdown', ev => {
      if (!isLegal) return;
      dragging = true; moved = false;
      startX = ev.clientX; startY = ev.clientY;
      e.setPointerCapture(ev.pointerId);
      e.classList.add('dragging');
    });
    e.addEventListener('pointermove', ev => {
      if (!dragging) return;
      const dx = ev.clientX - startX, dy = Math.min(0, ev.clientY - startY);
      if (Math.abs(dx) > 6 || dy < -6) moved = true;
      // The card follows the finger and grows as it is lifted off the hand, like picking it up.
      scale = 1 + Math.min(0.45, -dy / 140);
      rot = dx * 0.06;
      e.style.transform = `translate(${dx * 0.7}px, ${dy}px) rotate(${rot}deg) scale(${scale})`;
      e.classList.toggle('will-play', -dy > SWIPE_PX);
    });
    const end = (ev: PointerEvent) => {
      if (!dragging) return;
      dragging = false;
      e.classList.remove('dragging');
      const dy = ev.clientY - startY;
      if (-dy > SWIPE_PX) { throwCard(e, c, scale, rot); return; }
      e.style.transform = '';
      e.classList.remove('will-play');
      if (!moved) {
        if (selected === c) throwCard(e, c, 1.15, 0);
        else { selected = c; vibrate(8); sig.hand = ''; render(); }
      }
    };
    e.addEventListener('pointerup', end);
    e.addEventListener('pointercancel', () => { dragging = false; e.style.transform = ''; e.classList.remove('dragging', 'will-play'); });
    if (!isLegal) {
      e.addEventListener('click', () => {
        if (!(s.phase === 'playing' && s.turn === ctrl.mySeat)) return;
        if (c === JOKER && s.trick.length === 0) toast('ما تقدر تبدي بالجوكر');
        else if (mustLeadTrump(s, ctrl.mySeat)) toast('انزلي: لازم تبدي بحكم');
        else toast('لازم تنزل من نفس اللون');
      });
    }
  }

  function drawPanel(s: ViewState) {
    const pending = ctrl.pending?.() ?? false;
    let panel: HTMLElement;
    if (s.phase === 'bidding' && s.bidTurn === ctrl.mySeat) {
      const bids = pending ? [] : legalBids(s, ctrl.mySeat);
      const last = isLastToBid(s, ctrl.mySeat);
      panel = h('div', { class: 'panel' },
        h('div', { class: 'panel-title' },
          last ? 'الكل باس: تطلب ولا نوزع من جديد؟' : s.highBid ? `أعلى طلبة ${bidLabel(s.highBid)} (${seatName(s.highBidder!)})` : 'شنو طلبتك؟',
          h('span', { class: 'countdown' })),
        h('div', { class: 'row gap center wrap' },
          ...([5, 6, 7] as BidValue[]).map(b => h('button', {
            class: 'btn bid', disabled: !bids.includes(b), onclick: () => send({ type: 'bid', seat: ctrl.mySeat, bid: b }),
          }, String(b))),
          bids.includes(INZELI) ? h('button', { class: 'btn bid inzeli', onclick: async () => {
            if (await confirmBox('انزلي؟ لازم تاخذ كل الأكلات. إذا خسرت أكلة وحدة يفوز الفريق الثاني باللعبة.', 'انزلي!', 'لا'))
              send({ type: 'bid', seat: ctrl.mySeat, bid: INZELI });
          } }, 'انزلي') : null,
          h('button', { class: `btn pass${last ? ' reshuffle' : ''}`, disabled: pending, onclick: () => send({ type: 'pass', seat: ctrl.mySeat }) },
            last ? '🔀 وزّع من جديد' : 'باس')),
        s.handNo === 0 && s.hands[ctrl.mySeat]?.includes(JOKER) ? h('div', { class: 'note' }, 'انزلي مو مسموحة في أول يد') : null);
    } else if (s.phase === 'trump' && s.bidder === ctrl.mySeat) {
      panel = h('div', { class: 'panel' },
        h('div', { class: 'panel-title' }, 'اختار الحكم', h('span', { class: 'countdown' })),
        h('div', { class: 'row gap center' }, ...SUITS.map((su: Suit) => h('button', {
          class: `btn suit ${su === 'H' || su === 'D' ? 'red' : ''}`, disabled: pending,
          onclick: () => send({ type: 'trump', seat: ctrl.mySeat, suit: su }),
        }, h('span', { class: 'sym' }, SUIT_SYMBOL[su]), h('span', {}, SUIT_NAME_AR[su])))));
    } else if (s.phase === 'bidding') {
      panel = h('div', { class: 'panel muted' }, `${seatName(s.bidTurn)} يطلب…`);
    } else if (s.phase === 'trump') {
      panel = h('div', { class: 'panel muted' }, `${seatName(s.bidder!)} يختار الحكم…`);
    } else {
      panel = h('div', { class: 'panel-spacer' });
    }
    panelSlot.replaceChildren(panel);
  }

  async function send(a: Parameters<GameController['act']>[0]) {
    if (ctrl.pending?.()) return;
    try { await ctrl.act(a); }
    catch (e: any) { toast(e?.message ?? 'خطأ'); }
  }

  /**
   * Throws my card onto the table: it leaves the hand at the size it was lifted to, then flies
   * to its place in the middle and shrinks down to table size as it lands.
   */
  function throwCard(from: HTMLElement, c: Card, startScale: number, startRot: number) {
    if (ctrl.pending?.() || flying) return;
    selected = null;
    const box = from.getBoundingClientRect();
    const w = from.offsetWidth, hgt = from.offsetHeight;
    const cx = box.left + box.width / 2, cy = box.top + box.height / 2;
    const ghost = cardEl(c);
    if (from.classList.contains('trump')) ghost.classList.add('trump');
    ghost.classList.add('flying');
    Object.assign(ghost.style, {
      left: `${cx - w / 2}px`, top: `${cy - hgt / 2}px`, width: `${w}px`, height: `${hgt}px`,
      transform: `rotate(${startRot}deg) scale(${startScale})`,
    });
    document.body.append(ghost);
    from.style.visibility = 'hidden';
    flying = c;
    animated.add(`${ctrl.mySeat}:${c}`);       // the table copy must not run its own animation
    vibrate(15);
    cardSwish();
    const sent = send({ type: 'play', seat: ctrl.mySeat, card: c });
    requestAnimationFrame(() => {
      const target = trickSlot.querySelector(`[data-card="${c}"]`) as HTMLElement | null;
      if (!target) { land(ghost, null); return; }
      const tb = target.getBoundingClientRect();
      const dx = tb.left + tb.width / 2 - cx, dy = tb.top + tb.height / 2 - cy;
      const endScale = target.offsetWidth / w;
      const endRot = parseFloat(getComputedStyle(target).getPropertyValue('--r')) || 0;
      const anim = ghost.animate([
        { transform: `translate(0px, 0px) rotate(${startRot}deg) scale(${startScale})` },
        { transform: `translate(${dx * 0.45}px, ${dy * 0.45 - 24}px) rotate(${(startRot + endRot) / 2}deg) scale(${startScale * 1.08})`, offset: 0.4 },
        { transform: `translate(${dx}px, ${dy}px) rotate(${endRot}deg) scale(${endScale})` },
      ], { duration: 330, easing: 'cubic-bezier(.25,.7,.35,1)', fill: 'forwards' });
      anim.onfinish = () => land(ghost, c);
    });
    sent.finally(() => { if (flying === c && !trickSlot.querySelector(`[data-card="${c}"]`)) land(ghost, null); });
  }

  /** The thrown card reaches the table: show the real one, play the landing sound. */
  function land(ghost: HTMLElement, c: Card | null) {
    ghost.remove();
    flying = null;
    if (!c) { sig.hand = ''; render(); return; }    // move refused: card goes back to the hand
    const onTable = trickSlot.querySelector(`[data-card="${c}"]`) as HTMLElement | null;
    if (onTable) { onTable.style.visibility = ''; onTable.classList.add('landed'); }
    cardTick();
  }

  // ---------- turn timer ----------
  let timerHandle: number | undefined;
  function placeTimer(s: ViewState) {
    const dl = ctrl.deadline?.() ?? null;
    const a = actorOf(s);
    if (!dl || a === null) { ring.remove(); clearInterval(timerHandle); timerHandle = undefined; return; }
    if (!deadlineTotals.has(dl)) deadlineTotals.set(dl, Math.max(1000, dl - Date.now()));
    const total = deadlineTotals.get(dl)!;
    const avatar = seatInner[a].querySelector('.avatar');
    if (avatar && ring.parentElement !== avatar) avatar.append(ring);
    const tick = () => {
      const left = dl - Date.now();
      ring.style.setProperty('--p', String(Math.max(0, left / total)));
      const cd = panelSlot.querySelector('.countdown');
      if (cd) cd.textContent = left > 0 ? ` (${Math.ceil(left / 1000)})` : '';
      ring.classList.toggle('urgent', left < 4000);
    };
    tick();
    clearInterval(timerHandle);
    timerHandle = window.setInterval(tick, 200);
  }

  // ---------- events ----------
  function onEvents(events: GameEvent[]) {
    for (const e of events) {
      if (e.type === 'play' && e.seat !== ctrl.mySeat) setTimeout(cardTick, 260);
      if (e.type === 'contract' && e.bid === INZELI) { playAuto('inzeliCall'); toast(`${seatName(e.seat)}: انزلي!`); }
      if (e.type === 'redeal') toast('الكل باس.. توزيع جديد');
      if (e.type === 'trump') toast(`الحكم ${SUIT_NAME_AR[e.suit]} ${SUIT_SYMBOL[e.suit]}`, 1500);
      if (e.type === 'khayes') playAuto('khayes');
      if (e.type === 'handOver') playAuto(e.result.toTeam === myTeam ? 'handMade' : 'handFailed');
      if (e.type === 'matchOver') {
        const won = e.winner === myTeam;
        if (e.reason === 'inzeli') playAuto('inzeliMade');
        if (won) { playAuto('kout'); setTimeout(() => playAuto('matchWin'), 1300); } else playAuto('matchLose');
      }
      if (e.type === 'dealt') { animated.clear(); selected = null; }
    }
    const s = ctrl.view();
    const mine = actorOf(s) === ctrl.mySeat && (s.phase === 'playing' || s.phase === 'bidding');
    const key = `${s.handNo}:${s.redeals}:${s.phase}:${s.bidLog.length}:${s.played.length}`;
    if (mine && key !== lastTurnKey) { playAuto('myTurn'); vibrate(40); }
    if (mine) lastTurnKey = key;
    render();
  }

  /**
   * Result boxes follow the game state, not individual messages: online, a quick burst of
   * updates can arrive as one, so a "new hand dealt" message may never be seen on its own.
   */
  function syncModals(s: ViewState) {
    if (s.phase === 'handOver') {
      const key = `${s.handNo}:${s.redeals}`;
      if (shownHandKey !== key) { shownHandKey = key; setTimeout(showHandOver, 700); }
    } else if (modalKind === 'hand') {
      closeModal?.(); closeModal = null; modalKind = null;
    }
    if (s.phase === 'matchOver' && !matchShown) { matchShown = true; setTimeout(showMatchOver, 900); }
  }

  function closeResult() { closeModal?.(); closeModal = null; modalKind = null; }

  function showHandOver() {
    const s = ctrl.view();
    const r = s.lastHand;
    if (!r) return;
    const us = r.toTeam === myTeam;
    const myScore = myTeam === 0 ? s.score : -s.score;
    const box = h('div', { class: 'col gap center result' },
      h('div', { class: `big ${us ? 'good' : 'bad'}` }, r.made ? 'ربحت الطلبة' : 'طاحت الطلبة'),
      h('p', {}, `${seatName(r.bidder)} طلب ${bidLabel(r.bid)} وأخذ فريقه ${r.bidderTeamTricks}`),
      h('p', { class: us ? 'good' : 'bad' }, `${us ? '+' : '-'}${r.points} ${us ? 'لنا' : 'لهم'}`),
      h('p', {}, myScore === 0 ? 'التعادل 0' : myScore > 0 ? `نحن متقدمين ${myScore}` : `هم متقدمين ${-myScore}`),
      ctrl instanceof LocalController ? h('button', { class: 'btn primary', onclick: () => { closeResult(); (ctrl as LocalController).nextHand(); } }, 'اليد الجاية') : h('p', { class: 'muted' }, 'اليد الجاية بعد شوي…'));
    if (ctrl.view().phase !== 'handOver' || torn) return;
    closeResult();
    closeModal = modal(box, { dismiss: false });
    modalKind = 'hand';
    if (ctrl instanceof LocalController) setTimeout(() => {
      if (ctrl.view().phase === 'handOver') { closeResult(); (ctrl as LocalController).nextHand(); }
    }, 5000);
  }

  function showMatchOver() {
    const s = ctrl.view();
    const won = s.winner === myTeam;
    const reason = {
      points: won ? `وصلتوا ${WIN_SCORE}` : `وصلوا ${WIN_SCORE}`,
      inzeli: 'انزلي ناجحة',
      inzeliFailed: 'انزلي طاحت',
      khayes: `خيس الجوكر (${seatName(s.lastHand?.khayesSeat ?? 0)})`,
    }[s.winReason!];
    const box = h('div', { class: 'col gap center result' },
      h('div', { class: `kout ${won ? 'good' : 'bad'}` }, won ? 'كوت!' : 'انكوتّينا'),
      h('p', {}, reason),
      ctrl.online ? h('p', { class: 'muted' }, 'تم تحديث رصيدك') : null,
      h('div', { class: 'row gap center' },
        opts.onRematch ? h('button', { class: 'btn primary', onclick: () => { closeResult(); opts.onRematch!(); } }, 'لعبة ثانية') : null,
        h('button', { class: 'btn', onclick: () => { closeResult(); teardown(); opts.onExit(); } }, 'الرئيسية')));
    if (torn) return;
    closeResult();
    closeModal = modal(box, { dismiss: false });
    modalKind = 'match';
  }

  function openReactions() {
    const owned = new Set(profileStore.get()?.owned ?? []);
    let close = () => {};
    const grid = h('div', { class: 'react-grid' },
      ...SOUND_SLOTS.filter(sl => sl.reaction).map(sl => {
        const locked = !!sl.pack && !owned.has(sl.pack);
        return h('button', {
          class: `btn react${locked ? ' locked' : ''}`,
          onclick: () => {
            if (locked) { toast('افتحها من المتجر: باقة الميمز'); return; }
            close();
            ctrl.react(sl.id);
          },
        }, locked ? '🔒 ' : '', sl.label);
      }));
    close = modal(h('div', { class: 'col gap' }, h('h3', {}, 'تفاعل'), grid));
  }

  function showReaction(seat: number, slot: string) {
    play(slot);
    const b = reactBubbles[seat];
    if (!b) return;
    b.textContent = SOUND_SLOTS.find(s => s.id === slot)?.label ?? '';
    b.classList.remove('show'); void b.offsetWidth; b.classList.add('show');
  }

  async function exit() {
    const s = ctrl.view();
    if (s.phase !== 'matchOver' && !(await confirmBox(ctrl.online ? 'تطلع من اللعبة؟ بوت بيلعب بدالك.' : 'تطلع من اللعبة؟'))) return;
    teardown();
    opts.onExit();
  }

  const unsub = ctrl.subscribe(onEvents);
  const unreact = ctrl.onReaction(showReaction);
  let torn = false;
  function teardown() {
    if (torn) return;
    torn = true;
    unsub(); unreact(); clearInterval(timerHandle); closeModal?.();
    ctrl.leave();
  }

  render();
  return { teardown };
}

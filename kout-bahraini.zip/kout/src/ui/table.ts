import {
  BidValue, GameEvent, INZELI, JOKER, SUITS, SUIT_NAME_AR, SUIT_SYMBOL, Suit, WIN_SCORE,
  legalBids, legalCards, teamOf, trickWinner, tricksNeeded,
} from '../../shared/engine';
import { ITEM_BY_ID, SOUND_SLOTS, THEMES } from '../../shared/catalog';
import { confirmBox, h, modal, mount, toast } from '../dom';
import { GameController, LocalController, ViewState } from '../game/controller';
import { cardBack, cardEl } from './cards';
import { cardTick, play, playAuto, vibrate } from '../audio/sounds';
import { settings } from '../settings';
import { profileStore } from '../net/profile';

const POS4 = ['p-bottom', 'p-right', 'p-top', 'p-left'];
const POS6 = ['p-bottom', 'p-bright', 'p-tright', 'p-top', 'p-tleft', 'p-bleft'];

export function bidLabel(b: BidValue) { return b === INZELI ? 'انزلي' : String(b); }

export interface TableOpts {
  onExit: () => void;
  onRematch?: () => void;
  themeId?: string;
}

export function renderTable(root: HTMLElement, ctrl: GameController, opts: TableOpts) {
  const theme = THEMES.find(t => t.id === (opts.themeId ?? settings.get().theme)) ?? THEMES[0];
  const n = ctrl.view().players;
  const pos = n === 4 ? POS4 : POS6;
  const rel = (seat: number) => (seat - ctrl.mySeat + n) % n;
  const myTeam = teamOf(ctrl.mySeat);
  let closeModal: (() => void) | null = null;
  let lastTrickCount = 0;
  let timerHandle: number | undefined;

  const el = h('div', { class: `table-screen n${n}` });
  el.style.setProperty('--felt', theme.felt);
  el.style.setProperty('--felt2', theme.felt2);
  el.style.setProperty('--accent', theme.accent);
  el.style.setProperty('--rim', theme.rim);
  mount(root, el);

  function seatName(seat: number) {
    return seat === ctrl.mySeat ? 'أنت' : ctrl.seats[seat]?.name ?? `لاعب ${seat + 1}`;
  }

  function render() {
    const s = ctrl.view();
    const myScore = myTeam === 0 ? s.score : -s.score;
    const pct = Math.max(-1, Math.min(1, myScore / WIN_SCORE));

    const header = h('div', { class: 'tbl-head' },
      h('button', { class: 'icon-btn', onclick: exit, title: 'خروج' }, '✕'),
      h('div', { class: 'scorebox' },
        h('div', { class: 'score-labels' },
          h('span', { class: myScore > 0 ? 'lead us' : 'us' }, `نحن ${myScore > 0 ? myScore : 0}`),
          h('span', { class: 'target' }, `الهدف ${WIN_SCORE}`),
          h('span', { class: myScore < 0 ? 'lead them' : 'them' }, `هم ${myScore < 0 ? -myScore : 0}`)),
        h('div', { class: 'meter' },
          h('div', { class: 'meter-fill', style: {
            width: `${Math.abs(pct) * 50}%`,
            [pct >= 0 ? 'right' : 'left']: '50%',
            background: pct >= 0 ? 'var(--us)' : 'var(--them)',
          } }),
          h('div', { class: 'meter-mid' }))),
      contractBox(s),
      h('button', { class: 'icon-btn', onclick: openReactions, title: 'تفاعل' }, '🔊'));

    const felt = h('div', { class: 'felt' },
      theme.crest ? h('img', { class: 'crest', src: theme.crest, onerror: (e: Event) => (e.target as HTMLElement).remove() }) : null,
      h('div', { class: 'felt-logo' }, 'كوت'),
      ...Array.from({ length: n }, (_, seat) => seatEl(s, seat)),
      trickArea(s));

    el.replaceChildren(header, felt, handArea(s), actionPanel(s));
    setupTimer();
  }

  function contractBox(s: ViewState) {
    if (s.bid && s.bidder !== null) {
      const us = teamOf(s.bidder) === myTeam;
      const need = tricksNeeded(s.bid);
      const got = s.tricksWon[teamOf(s.bidder)];
      return h('div', { class: `contract ${us ? 'us' : 'them'}` },
        h('div', { class: 'c-bid' }, bidLabel(s.bid)),
        s.trump ? h('div', { class: `c-trump ${s.trump === 'H' || s.trump === 'D' ? 'red' : ''}` }, SUIT_SYMBOL[s.trump]) : h('div', { class: 'c-trump' }, '…'),
        h('div', { class: 'c-prog' }, `${got}/${need}`));
    }
    return h('div', { class: 'contract empty' }, h('div', { class: 'c-bid' }, s.phase === 'bidding' ? 'مزاد' : ''));
  }

  function seatEl(s: ViewState, seat: number) {
    const info = ctrl.seats[seat] ?? { name: '…', bot: true };
    const r = rel(seat);
    const active = (s.phase === 'bidding' && s.bidTurn === seat) || (s.phase === 'trump' && s.bidder === seat) || (s.phase === 'playing' && s.turn === seat);
    const lastBid = [...s.bidLog].reverse().find(b => b.seat === seat);
    const team = teamOf(seat) === myTeam ? 'us' : 'them';
    const acc = info.accessory ? ITEM_BY_ID[info.accessory] : null;
    const isBidder = s.bidder === seat && s.phase !== 'bidding';
    return h('div', { class: `seat ${pos[r]} ${team}${active ? ' active' : ''}`, 'data-seat': seat },
      r === 0 ? null : h('div', { class: 'seat-cards' }, cardBack(), h('span', { class: 'cnt' }, String(s.handCounts[seat]))),
      h('div', { class: 'avatar' },
        avatarContent(info.avatar),
        acc ? h('span', { class: 'acc', title: acc.name }, acc.emoji) : null,
        isBidder ? h('span', { class: 'bidder-badge' }, bidLabel(s.bid!)) : null),
      h('div', { class: 'seat-name' }, info.majlis ? h('span', { class: 'tag' }, info.majlis) : null, seatName(seat), info.bot && ctrl.online ? ' 🤖' : ''),
      s.phase === 'bidding' && lastBid ? h('div', { class: `bubble ${lastBid.bid === 'pass' ? 'pass' : ''}` }, lastBid.bid === 'pass' ? 'باس' : bidLabel(lastBid.bid)) : null,
      h('div', { class: 'react-bubble' }));
  }

  function avatarContent(a?: string) {
    if (a && /^https?:/.test(a)) return h('img', { src: a, referrerpolicy: 'no-referrer' });
    return h('span', { class: 'emoji' }, a ?? '🧔');
  }

  function trickArea(s: ViewState) {
    const area = h('div', { class: 'trick' });
    const showing = s.trick.length ? s.trick : s.lastTrick ?? [];
    const finished = !s.trick.length && s.lastTrick && s.phase === 'playing';
    const winner = finished && s.lastTrickWinner !== null ? s.lastTrickWinner : null;
    const leaderWinning = s.trick.length && s.trump ? trickWinner(s.trick, s.trump).seat : null;
    if (s.phase === 'playing' || s.phase === 'handOver' || s.phase === 'matchOver') {
      showing.forEach((p, i) => {
        const c = cardEl(p.card, { small: true });
        c.classList.add('played', `from-${pos[rel(p.seat)]}`);
        if (s.trick.length && i >= lastTrickCount) c.classList.add('fresh');
        if (winner !== null) c.classList.add('collect', `to-${pos[rel(winner)]}`);
        if (p.seat === leaderWinning && s.trick.length > 1) c.classList.add('winning');
        area.append(c);
      });
    }
    lastTrickCount = s.trick.length;
    return area;
  }

  function handArea(s: ViewState) {
    const hand = s.hands[ctrl.mySeat] ?? [];
    const legal = new Set(legalCards(s, ctrl.mySeat));
    const myTurn = s.phase === 'playing' && s.turn === ctrl.mySeat;
    const jokerWarn = myTurn && hand.includes(JOKER) && hand.length <= 3 && s.trick.length > 0;
    return h('div', { class: `hand${myTurn ? ' my-turn' : ''}` },
      jokerWarn ? h('div', { class: 'hint warn' }, 'انتبه: تخلص من الجوكر قبل ما يصير آخر ورقة (خيس)') : null,
      myTurn && !jokerWarn ? h('div', { class: 'hint' }, s.trick.length === 0 ? 'دورك تبدي' : 'دورك') : null,
      h('div', { class: 'hand-cards', style: { '--count': String(hand.length) } as any },
        ...hand.map((c, i) => {
          const isLegal = myTurn && legal.has(c);
          const e = cardEl(c, { legal: myTurn ? isLegal : undefined, onClick: isLegal ? () => playCard(c) : () => myTurn && c === JOKER && s.trick.length === 0 ? toast('ما تقدر تبدي بالجوكر') : undefined });
          e.style.setProperty('--i', String(i));
          return e;
        })));
  }

  function actionPanel(s: ViewState) {
    if (s.phase === 'bidding' && s.bidTurn === ctrl.mySeat) {
      const bids = legalBids(s, ctrl.mySeat);
      return h('div', { class: 'panel' },
        h('div', { class: 'panel-title' }, s.highBid ? `أعلى طلبة ${bidLabel(s.highBid)} (${seatName(s.highBidder!)})` : 'شنو طلبتك؟'),
        h('div', { class: 'row gap center wrap' },
          ...([5, 6, 7] as BidValue[]).map(b => h('button', {
            class: 'btn bid', disabled: !bids.includes(b), onclick: () => ctrl.act({ type: 'bid', seat: ctrl.mySeat, bid: b }),
          }, String(b))),
          bids.includes(INZELI) ? h('button', { class: 'btn bid inzeli', onclick: async () => {
            if (await confirmBox('انزلي؟ لازم تاخذ كل الأكلات. إذا خسرت أكلة وحدة يفوز الفريق الثاني باللعبة.', 'انزلي!', 'لا'))
              ctrl.act({ type: 'bid', seat: ctrl.mySeat, bid: INZELI });
          } }, 'انزلي') : null,
          h('button', { class: 'btn pass', onclick: () => ctrl.act({ type: 'pass', seat: ctrl.mySeat }) }, 'باس')),
        s.handNo === 0 && s.hands[ctrl.mySeat]?.includes(JOKER) ? h('div', { class: 'note' }, 'انزلي مو مسموحة في أول يد') : null);
    }
    if (s.phase === 'trump' && s.bidder === ctrl.mySeat) {
      return h('div', { class: 'panel' },
        h('div', { class: 'panel-title' }, 'اختار الحكم'),
        h('div', { class: 'row gap center' }, ...SUITS.map((su: Suit) => h('button', {
          class: `btn suit ${su === 'H' || su === 'D' ? 'red' : ''}`,
          onclick: () => ctrl.act({ type: 'trump', seat: ctrl.mySeat, suit: su }),
        }, h('span', { class: 'sym' }, SUIT_SYMBOL[su]), h('span', {}, SUIT_NAME_AR[su])))));
    }
    if (s.phase === 'bidding') return h('div', { class: 'panel muted' }, `${seatName(s.bidTurn)} يطلب…`);
    if (s.phase === 'trump') return h('div', { class: 'panel muted' }, `${seatName(s.bidder!)} يختار الحكم…`);
    return h('div', { class: 'panel-spacer' });
  }

  async function playCard(c: string) {
    vibrate(15);
    cardTick();
    try { await ctrl.act({ type: 'play', seat: ctrl.mySeat, card: c }); }
    catch (e: any) { toast(e?.message ?? 'خطأ'); }
  }

  function onEvents(events: GameEvent[]) {
    for (const e of events) {
      if (e.type === 'play' && e.seat !== ctrl.mySeat) cardTick();
      if (e.type === 'contract' && e.bid === INZELI) { playAuto('inzeliCall'); toast(`${seatName(e.seat)}: انزلي!`); }
      if (e.type === 'redeal') toast('الكل باس.. توزيع جديد');
      if (e.type === 'trump') toast(`الحكم ${SUIT_NAME_AR[e.suit]} ${SUIT_SYMBOL[e.suit]}`, 1500);
      if (e.type === 'khayes') playAuto('khayes');
      if (e.type === 'handOver') {
        const good = (e.result.toTeam === myTeam);
        playAuto(good ? 'handMade' : 'handFailed');
        if (e.result.bid !== INZELI) showHandOver();
      }
      if (e.type === 'matchOver') {
        const won = e.winner === myTeam;
        if (e.reason === 'inzeli') playAuto('inzeliMade');
        if (won) { playAuto('kout'); setTimeout(() => playAuto('matchWin'), 1300); } else playAuto('matchLose');
        setTimeout(showMatchOver, 900);
      }
      if (e.type === 'dealt') { closeModal?.(); closeModal = null; lastTrickCount = 0; }
    }
    const s = ctrl.view();
    const myTurnNow = (s.phase === 'playing' && s.turn === ctrl.mySeat) || (s.phase === 'bidding' && s.bidTurn === ctrl.mySeat);
    if (myTurnNow && events.length) { playAuto('myTurn'); vibrate(40); }
    render();
  }

  function showHandOver() {
    const s = ctrl.view();
    const r = s.lastHand!;
    const us = r.toTeam === myTeam;
    const myScore = myTeam === 0 ? s.score : -s.score;
    const box = h('div', { class: 'col gap center result' },
      h('div', { class: `big ${us ? 'good' : 'bad'}` }, r.made ? 'ربحت الطلبة' : 'طاحت الطلبة'),
      h('p', {}, `${seatName(r.bidder)} طلب ${bidLabel(r.bid)} وأخذ فريقه ${r.bidderTeamTricks}`),
      h('p', { class: us ? 'good' : 'bad' }, `${us ? '+' : '-'}${r.points} ${us ? 'لنا' : 'لهم'}`),
      h('p', {}, myScore === 0 ? 'التعادل 0' : myScore > 0 ? `نحن متقدمين ${myScore}` : `هم متقدمين ${-myScore}`),
      ctrl instanceof LocalController ? h('button', { class: 'btn primary', onclick: () => { closeModal?.(); (ctrl as LocalController).nextHand(); } }, 'اليد الجاية') : h('p', { class: 'muted' }, 'اليد الجاية بعد شوي…'));
    closeModal?.();
    setTimeout(() => {
      if (ctrl.view().phase !== 'handOver') return;
      closeModal = modal(box, { dismiss: false });
      if (ctrl instanceof LocalController) setTimeout(() => {
        if (ctrl.view().phase === 'handOver') { closeModal?.(); (ctrl as LocalController).nextHand(); }
      }, 5000);
    }, 900);
  }

  function showMatchOver() {
    const s = ctrl.view();
    const won = s.winner === myTeam;
    const reason = {
      points: won ? `وصلتوا ${WIN_SCORE}` : `وصلوا ${WIN_SCORE}`,
      inzeli: 'انزلي ناجحة',
      inzeliFailed: 'انزلي طاحت',
      khayes: `خيس الجوكر (${seatName(s.lastHand?.khayesSeat ?? 0)})`,
    }[s.winReason!];
    const box = h('div', { class: 'col gap center result' },
      h('div', { class: `kout ${won ? 'good' : 'bad'}` }, won ? 'كوت!' : 'انكوتّينا'),
      h('p', {}, reason),
      ctrl.online ? h('p', { class: 'muted' }, 'تم تحديث رصيدك') : null,
      h('div', { class: 'row gap center' },
        opts.onRematch ? h('button', { class: 'btn primary', onclick: () => { closeModal?.(); opts.onRematch!(); } }, 'لعبة ثانية') : null,
        h('button', { class: 'btn', onclick: () => { closeModal?.(); teardown(); opts.onExit(); } }, 'الرئيسية')));
    closeModal?.();
    closeModal = modal(box, { dismiss: false });
    if (ctrl.online && won) profileStore.refresh();
  }

  function openReactions() {
    const owned = new Set(profileStore.get()?.owned ?? []);
    let close = () => {};
    const grid = h('div', { class: 'react-grid' },
      ...SOUND_SLOTS.filter(sl => sl.reaction).map(sl => {
        const locked = !!sl.pack && !owned.has(sl.pack);
        return h('button', {
          class: `btn react${locked ? ' locked' : ''}`,
          onclick: () => {
            if (locked) { toast('افتحها من المتجر: باقة الميمز'); return; }
            close();
            ctrl.react(sl.id);
          },
        }, locked ? '🔒 ' : '', sl.label);
      }));
    close = modal(h('div', { class: 'col gap' }, h('h3', {}, 'تفاعل'), grid));
  }

  function showReaction(seat: number, slot: string) {
    play(slot);
    const label = SOUND_SLOTS.find(s => s.id === slot)?.label ?? '';
    const b = el.querySelector(`.seat[data-seat="${seat}"] .react-bubble`) as HTMLElement | null;
    if (b) {
      b.textContent = label;
      b.classList.remove('show'); void b.offsetWidth; b.classList.add('show');
    }
  }

  function setupTimer() {
    clearInterval(timerHandle);
    if (!ctrl.deadline) return;
    const dl = ctrl.deadline();
    if (!dl) return;
    const s = ctrl.view();
    const seat = s.phase === 'bidding' ? s.bidTurn : s.phase === 'trump' ? s.bidder : s.turn;
    const seatNode = el.querySelector(`.seat[data-seat="${seat}"] .avatar`) as HTMLElement | null;
    if (!seatNode) return;
    const ring = h('div', { class: 'timer' });
    seatNode.append(ring);
    const total = Math.max(1000, dl - Date.now());
    const tick = () => {
      const left = dl - Date.now();
      ring.style.setProperty('--p', String(Math.max(0, left / total)));
      if (left <= 0) clearInterval(timerHandle);
    };
    tick();
    timerHandle = window.setInterval(tick, 250);
  }

  async function exit() {
    const s = ctrl.view();
    if (s.phase !== 'matchOver' && !(await confirmBox(ctrl.online ? 'تطلع من اللعبة؟ بوت بيلعب بدالك.' : 'تطلع من اللعبة؟'))) return;
    teardown();
    opts.onExit();
  }

  const unsub = ctrl.subscribe(onEvents);
  const unreact = ctrl.onReaction(showReaction);
  let torn = false;
  function teardown() {
    if (torn) return;
    torn = true;
    unsub(); unreact(); clearInterval(timerHandle); closeModal?.();
    ctrl.leave();
  }

  render();
  return { teardown };
}

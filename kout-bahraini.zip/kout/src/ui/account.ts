import { confirmBox, h, mount, toast } from '../dom';
import { go, register } from '../router';
import { authErrorAr, checkVerified, logout, registerEmail, resendVerification, resetPassword, signInEmail, signInSocial } from '../net/auth';
import { isVerified, profileStore } from '../net/profile';
import { call } from '../net/firebase';
import { field, screen, topbar } from './common';
import { CATALOG, CHARACTERS, FREE_AVATARS, ITEM_BY_ID } from '../../shared/catalog';
import { avatarNode } from './avatar';
import { equipItem } from '../net/store';


register('login', (root, p: { next?: string }) => {
  let mode: 'signin' | 'register' = 'signin';
  const name = h('input', { placeholder: 'الاسم في اللعبة', maxlength: 16 }) as HTMLInputElement;
  const email = h('input', { type: 'email', placeholder: 'email@example.com', dir: 'ltr', autocomplete: 'email' }) as HTMLInputElement;
  const pass = h('input', { type: 'password', placeholder: '••••••', dir: 'ltr', autocomplete: 'current-password' }) as HTMLInputElement;
  let busy = false;

  const after = () => {
    const u = profileStore.user();
    if (u && !isVerified(u)) go('verify', p, { replace: true });
    else go((p.next as any) ?? 'home', {}, { replace: true });
  };

  async function social(provider: 'google' | 'facebook' | 'x') {
    if (busy) return; busy = true;
    try { await signInSocial(provider); after(); }
    catch (e) { toast(authErrorAr(e)); }
    finally { busy = false; }
  }

  async function submit() {
    if (busy) return; busy = true;
    try {
      if (mode === 'register') {
        if (!name.value.trim()) throw { message: 'اكتب اسمك' };
        await registerEmail(name.value.trim(), email.value.trim(), pass.value);
        go('verify', p, { replace: true });
      } else {
        await signInEmail(email.value.trim(), pass.value);
        after();
      }
    } catch (e) { toast(authErrorAr(e)); }
    finally { busy = false; }
  }

  const draw = () => mount(root, screen(
    topbar('تسجيل الدخول', h('span')),
    h('div', { class: 'card-panel col gap' },
      h('button', { class: 'btn social google', onclick: () => social('google') }, h('b', {}, 'G'), ' الدخول بحساب Google'),
      h('button', { class: 'btn social facebook', onclick: () => social('facebook') }, h('b', {}, 'f'), ' الدخول بحساب Facebook'),
      h('button', { class: 'btn social x', onclick: () => social('x') }, h('b', {}, '𝕏'), ' الدخول بحساب X'),
      h('div', { class: 'divider' }, 'أو بالإيميل'),
      h('div', { class: 'seg' },
        h('button', { class: mode === 'signin' ? 'on' : '', onclick: () => { mode = 'signin'; draw(); } }, 'دخول'),
        h('button', { class: mode === 'register' ? 'on' : '', onclick: () => { mode = 'register'; draw(); } }, 'حساب جديد')),
      mode === 'register' ? field('الاسم', name) : null,
      field('الإيميل', email),
      field('كلمة السر', pass),
      h('button', { class: 'btn primary', onclick: submit }, mode === 'register' ? 'سجل وأرسل رابط التأكيد' : 'دخول'),
      mode === 'signin' ? h('button', { class: 'link', onclick: async () => {
        if (!email.value.trim()) return toast('اكتب إيميلك أول');
        try { await resetPassword(email.value.trim()); toast('أرسلنا رابط تغيير كلمة السر'); } catch (e) { toast(authErrorAr(e)); }
      } }, 'نسيت كلمة السر؟') : h('p', { class: 'muted small' }, 'بنرسل لك رابط تأكيد على الإيميل. لازم تأكد إيميلك قبل اللعب أونلاين.'))));
  draw();
});

register('verify', (root, p) => {
  const u = profileStore.user();
  mount(root, screen(
    topbar('تأكيد الإيميل', h('span')),
    h('div', { class: 'card-panel col gap center' },
      h('div', { class: 'big-emoji' }, '📧'),
      h('p', {}, 'أرسلنا رابط تأكيد على:'),
      h('p', { dir: 'ltr' }, h('b', {}, u?.email ?? '')),
      h('p', { class: 'muted' }, 'افتح الإيميل واضغط الرابط، بعدين ارجع واضغط "أكدت".'),
      h('button', { class: 'btn primary', onclick: async () => {
        if (await checkVerified()) { toast('تم التأكيد، هلا والله'); location.reload(); }
        else toast('لسه ما تأكد. شيك على البريد (والسبام)');
      } }, 'أكدت'),
      h('button', { class: 'btn', onclick: async () => { try { await resendVerification(); toast('أرسلنا الرابط مرة ثانية'); } catch (e) { toast(authErrorAr(e)); } } }, 'أرسل الرابط مرة ثانية'),
      h('button', { class: 'link', onclick: async () => { await logout(); go('home'); } }, 'دخول بحساب ثاني'))));
  void p;
});

register('profile', root => {
  const draw = () => {
    const p = profileStore.get();
    if (!p) { go('login', {}, { replace: true }); return; }
    const owned = CATALOG.filter(i => p.owned.includes(i.id) && i.kind === 'accessory');
    const nameIn = h('input', { value: p.name, maxlength: 16 }) as HTMLInputElement;
    mount(root, screen(
      topbar('حسابي'),
      h('div', { class: 'card-panel col gap' },
        h('div', { class: 'profile-head' },
          h('div', { class: 'avatar big' }, avatarNode(p.avatar?.startsWith('http') ? '🧔' : p.avatar),
            p.equipped.accessory ? h('span', { class: 'acc' }, ITEM_BY_ID[p.equipped.accessory]?.emoji) : null),
          h('div', {},
            h('h3', {}, p.name),
            p.majlisTag ? h('div', { class: 'tag' }, `مجلس ${p.majlisTag}`) : h('div', { class: 'muted' }, 'بدون مجلس'))),
        h('div', { class: 'stats' },
          h('div', {}, h('b', {}, String(p.stats.played)), h('span', {}, 'لعبات')),
          h('div', {}, h('b', {}, String(p.stats.won)), h('span', {}, 'فوز')),
          h('div', {}, h('b', {}, String(p.stats.kouts)), h('span', {}, 'انزلي ناجحة'))),
        field('الاسم', nameIn),
        h('h3', {}, 'الصورة'),
        h('div', { class: 'avatar-pick' }, ...FREE_AVATARS.map(a => h('button', {
          class: p.avatar === a ? 'on' : '',
          onclick: () => call('updateProfile', { avatar: a }).catch(e => toast(e.message)),
        }, a))),
        h('h3', {}, 'الشخصيات'),
        h('div', { class: 'char-pick' }, ...CHARACTERS.map(c => {
          const has = p.owned.includes(c.id);
          return h('button', {
            class: `${p.avatar === c.id ? 'on' : ''}${has ? '' : ' locked'}`,
            title: c.name,
            onclick: () => has
              ? call('updateProfile', { avatar: c.id }).then(() => toast(`صرت ${c.name}`)).catch(e => toast(e.message))
              : go('store', { tab: 'character' }),
          }, avatarNode(c.id), h('small', {}, c.name), has ? null : h('span', { class: 'lock' }, `🪙 ${c.price}`));
        })),
        h('h3', {}, 'الإكسسوار'),
        owned.length ? h('div', { class: 'avatar-pick' },
          h('button', { class: !p.equipped.accessory ? 'on' : '', onclick: () => equipItem(null, 'accessory') }, '∅'),
          ...owned.map(i => h('button', { class: p.equipped.accessory === i.id ? 'on' : '', title: i.name, onclick: () => equipItem(i.id, 'accessory').catch(e => toast(e.message)) }, i.emoji)))
          : h('p', { class: 'muted' }, 'اشتر إكسسوارات من المتجر'),
        h('button', { class: 'btn primary', onclick: () => call('updateProfile', { name: nameIn.value }).then(() => toast('تم الحفظ')).catch(e => toast(e.message)) }, 'حفظ الاسم'),
        h('button', { class: 'btn danger', onclick: async () => { await logout(); go('home'); } }, 'تسجيل خروج'),
        h('button', { class: 'link small', onclick: async () => {
          if (await confirmBox('حذف الحساب نهائياً؟ بتروح كل البيزات والأغراض.', 'احذف', 'لا')) {
            try { await call('deleteAccount', {}); await logout(); go('home'); } catch (e: any) { toast(e.message); }
          }
        } }, 'حذف الحساب'))));
  };
  draw();
  return profileStore.on(() => { if (document.querySelector('.profile-head')) draw(); });
});

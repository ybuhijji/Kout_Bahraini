import { Card, JOKER, Suit, SUIT_SYMBOL, rankLabel, suitOf } from '../../shared/engine';
import { h } from '../dom';

const RANK_AR: Record<string, string> = { A: 'A', K: 'K', Q: 'Q', J: 'J' };

export function cardEl(c: Card, opts: { small?: boolean; legal?: boolean; onClick?: () => void } = {}) {
  const cls = ['card'];
  if (opts.small) cls.push('small');
  if (opts.legal === false) cls.push('dim');
  if (opts.legal) cls.push('legal');
  if (c === JOKER) {
    return h('div', { class: cls.concat('joker').join(' '), onclick: opts.onClick, 'data-card': c },
      h('span', { class: 'corner' }, '♛'),
      h('span', { class: 'pip' }, '♛'),
      h('span', { class: 'jlabel' }, 'جوكر'));
  }
  const s = suitOf(c) as Suit;
  const red = s === 'H' || s === 'D';
  const r = rankLabel(c);
  return h('div', { class: cls.concat(red ? 'red' : 'black').join(' '), onclick: opts.onClick, 'data-card': c },
    h('span', { class: 'corner' }, h('b', {}, RANK_AR[r] ?? r), h('i', {}, SUIT_SYMBOL[s])),
    h('span', { class: 'pip' }, SUIT_SYMBOL[s]),
    h('span', { class: 'corner br' }, h('b', {}, RANK_AR[r] ?? r), h('i', {}, SUIT_SYMBOL[s])));
}

export function cardBack(back = 'default', small = true) {
  return h('div', { class: `card back back-${back}${small ? ' small' : ''}` });
}

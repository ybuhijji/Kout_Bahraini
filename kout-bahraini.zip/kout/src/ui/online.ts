import { h, mount, toast } from '../dom';
import { roomLink, shareInvite } from '../net/invite';
import { go, register } from '../router';
import { profileStore } from '../net/profile';
import { OnlineController, Room, createRoom, joinRoom, leaveRoom, quickMatch, startRoom, switchSeat, watchRoom } from '../net/online';
import { screen, topbar } from './common';
import { ITEM_BY_ID } from '../../shared/catalog';
import { teamOf } from '../../shared/engine';

register('online', root => {
  let variant: 4 | 6 = 4;
  let busy = false;
  const code = h('input', { placeholder: 'كود الغرفة', maxlength: 6, dir: 'ltr', class: 'code-input' }) as HTMLInputElement;
  const run = async (ev: Event, fn: () => Promise<{ roomId: string }>) => {
    if (busy) return;
    busy = true;
    const btn = ev.currentTarget as HTMLButtonElement;
    const label = btn.textContent;
    root.querySelectorAll('button').forEach(b => (b as HTMLButtonElement).disabled = true);
    btn.classList.add('loading');
    btn.textContent = 'لحظة…';
    try { const r = await fn(); go('room', { roomId: r.roomId }); }
    catch (e: any) {
      toast(e.message);
      root.querySelectorAll('button').forEach(b => (b as HTMLButtonElement).disabled = false);
      btn.classList.remove('loading');
      btn.textContent = label;
    }
    finally { busy = false; }
  };
  const draw = () => mount(root, screen(
    topbar('أونلاين'),
    h('div', { class: 'card-panel col gap' },
      h('div', { class: 'seg' },
        h('button', { class: variant === 4 ? 'on' : '', onclick: () => { variant = 4; draw(); } }, 'كوت بو 4'),
        h('button', { class: variant === 6 ? 'on' : '', onclick: () => { variant = 6; draw(); } }, 'كوت بو 6')),
      h('button', { class: 'btn big primary', onclick: (ev: Event) => run(ev, () => quickMatch(variant)) }, '⚡ لعب سريع مع أي أحد'),
      h('p', { class: 'muted small' }, 'ندورلك طاولة فيها ناس. إذا ما اكتملت خلال 40 ثانية، بوتات تكمل الكراسي.'),
      h('div', { class: 'divider' }, 'مع ربعك'),
      h('button', { class: 'btn big', onclick: (ev: Event) => run(ev, () => createRoom(variant)) }, '➕ سوّ غرفة خاصة'),
      h('div', { class: 'row gap' }, code,
        h('button', { class: 'btn', onclick: (ev: Event) => code.value.trim().length >= 4 ? run(ev, () => joinRoom(code.value)) : toast('اكتب الكود') }, 'ادخل')))));
  draw();
});

register('room', (root, p: { roomId: string }) => {
  const me = profileStore.get();
  let room: Room | null = null;
  let entering = false;
  let fillTimer: number | undefined;
  let tick: number | undefined;
  const unsub = watchRoom(p.roomId, async r => {
    room = r;
    if (!r) { toast('الغرفة انقفلت'); go('home'); return; }
    if (r.status === 'playing' && !entering) {
      entering = true;
      try {
        const ctrl = await OnlineController.open(r.id, me!.uid);
        go('game', { ctrl, theme: r.theme }, { replace: true });
      } catch (e: any) { toast(e.message); entering = false; }
      return;
    }
    draw();
  });

  async function share() {
    if (!room) return;
    await shareInvite(`تعال العب كوت بحريني معاي 🃏 اضغط الرابط وادخل الطاولة (كود الغرفة: ${room.code})`, roomLink(room.code));
  }

  function scheduleFill() {
    clearTimeout(fillTimer); clearInterval(tick);
    if (!room || !room.isPublic || room.status !== 'waiting' || !room.createdAt) return;
    const at = room.createdAt.toMillis() + 40_000;
    tick = window.setInterval(() => {
      const el = root.querySelector('.countdown');
      if (el) el.textContent = `البوتات تكمل الطاولة بعد ${Math.max(0, Math.ceil((at - Date.now()) / 1000))} ثانية`;
    }, 500);
    fillTimer = window.setTimeout(() => startRoom(room!.id).catch(() => {}), Math.max(0, at - Date.now()) + Math.random() * 1500);
  }

  function draw() {
    if (!room) { mount(root, screen(topbar('الغرفة'), h('div', { class: 'spinner' }))); return; }
    scheduleFill();
    const isHost = room.hostUid === me?.uid;
    const filled = room.seats.filter(Boolean).length;
    mount(root, screen(
      topbar(room.isPublic ? 'ندوّر لاعبين…' : 'غرفة خاصة', h('button', { class: 'icon-btn', onclick: async () => { await leaveRoom(room!.id).catch(() => {}); go('home'); } }, '✕')),
      h('div', { class: 'card-panel col gap center' },
        !room.isPublic ? h('div', { class: 'room-code', onclick: share }, h('small', {}, 'كود الغرفة'), h('b', { dir: 'ltr' }, room.code), h('small', {}, 'اضغط للمشاركة')) : h('div', { class: 'spinner' }),
        h('div', { class: 'muted' }, `كوت بو ${room.variant} · ${filled}/${room.variant}`),
        h('div', { class: `room-seats n${room.variant}` },
          ...room.seats.map((s, i) => h('button', {
            class: `room-seat team${teamOf(i)}${s?.uid === me?.uid ? ' me' : ''}`,
            onclick: () => !s && switchSeat(room!.id, i).catch(e => toast(e.message)),
          },
            h('span', { class: 'emoji' }, s ? (s.avatar?.startsWith('http') ? '🧔' : s.avatar ?? '🧔') : '➕'),
            h('span', {}, s ? s.name : 'كرسي فاضي'),
            s?.accessory ? h('span', {}, ITEM_BY_ID[s.accessory]?.emoji ?? '') : null,
            h('small', {}, teamOf(i) === 0 ? 'الفريق الأول' : 'الفريق الثاني')))),
        isHost ? h('button', { class: 'btn big primary', onclick: (ev: Event) => {
          const b = ev.currentTarget as HTMLButtonElement;
          b.disabled = true; b.textContent = 'نبدأ…';
          startRoom(room!.id).catch(e => { toast(e.message); b.disabled = false; draw(); });
        } },
          filled < room.variant ? 'ابدأ (بوتات تكمل الكراسي الفاضية)' : 'ابدأ اللعبة') :
          h('p', { class: 'muted' }, room.isPublic ? 'اللعبة تبدأ أول ما تكمل الطاولة' : 'ننتظر صاحب الغرفة يبدأ…'),
        room.isPublic ? h('p', { class: 'countdown muted small' }) : null,
        !room.isPublic ? h('button', { class: 'btn primary', onclick: share }, '📤 أرسل رابط الطاولة (واتساب وغيره)') : null)));
  }
  draw();
  return () => { unsub(); clearTimeout(fillTimer); clearInterval(tick); };
});

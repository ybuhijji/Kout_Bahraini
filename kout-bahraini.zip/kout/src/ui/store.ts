import { h, mount, toast, confirmBox } from '../dom';
import { register } from '../router';
import { profileStore } from '../net/profile';
import { billingAvailable, buyCoins, buyItem, equipItem, initBilling } from '../net/store';
import { CATALOG, COIN_PACKS, ItemKind, THEMES } from '../../shared/catalog';
import { screen, topbar } from './common';
import { play } from '../audio/sounds';
import { settings } from '../settings';
import { call } from '../net/firebase';
import { characterSrc } from './avatar';

const TABS: { id: ItemKind | 'coins'; label: string }[] = [
  { id: 'character', label: 'شخصيات' },
  { id: 'accessory', label: 'إكسسوارات' },
  { id: 'theme', label: 'طاولات' },
  { id: 'soundpack', label: 'أصوات' },
  { id: 'cardback', label: 'ورق' },
  { id: 'coins', label: '🪙 بيزات' },
];

register('store', (root, params: { tab?: string }) => {
  let tab = (params.tab as any) ?? 'character';
  let prices: Record<string, string> = {};
  initBilling(coins => toast(`انضاف ${coins} بيزة لرصيدك`)).then(p => { prices = p; if (tab === 'coins') draw(); });

  function draw() {
    const p = profileStore.get();
    if (!p) return;
    const owned = new Set(p.owned);
    const items = CATALOG.filter(i => i.kind === tab);
    const content = tab === 'coins'
      ? h('div', { class: 'grid' }, ...COIN_PACKS.map(c => h('button', {
        class: 'shop-item', onclick: async () => {
          if (!billingAvailable()) { toast('شراء البيزات متوفر في تطبيق أندرويد من Google Play'); return; }
          try { await buyCoins(c.productId); } catch (e: any) { toast(e.message); }
        },
      }, h('div', { class: 'icon' }, '🪙'), h('b', {}, c.label), h('span', { class: 'price' }, prices[c.productId] ?? '—'))))
      : h('div', { class: 'grid' }, ...items.map(i => {
        const has = owned.has(i.id);
        const equipped = i.kind === 'character' ? p.avatar === i.id : Object.values(p.equipped).includes(i.id);
        const theme = THEMES.find(t => t.item === i.id);
        return h('div', { class: `shop-item ${i.rarity ?? 'common'}${has ? ' owned' : ''}` },
          i.kind === 'character' ? h('div', { class: 'icon char-art' }, h('img', { src: characterSrc(i.id, true), alt: i.name, loading: 'lazy' })) :
          theme ? h('div', { class: 'icon swatch-big', style: { background: `radial-gradient(circle, ${theme.felt}, ${theme.felt2})`, borderColor: theme.rim } }) :
            h('div', { class: 'icon' }, h('img', { src: `items/${i.id}.png`, alt: '', onerror: (e: Event) => { (e.target as HTMLElement).replaceWith(i.emoji); } })),
          h('b', {}, i.name),
          i.rarity && i.rarity !== 'common' ? h('small', { class: 'rarity' }, i.rarity === 'legendary' ? 'أسطوري' : 'نادر') : null,
          has
            ? (i.kind === 'character' ? h('button', { class: `btn small${equipped ? ' on' : ''}`, onclick: () => call('updateProfile', { avatar: i.id }).then(() => toast(`صرت ${i.name}`)).catch(e => toast(e.message)) }, equipped ? 'صورتك ✓' : 'خلها صورتي') :
              i.kind === 'soundpack' ? h('button', { class: 'btn small', onclick: () => play('voice_1') }, 'جرّب') :
              i.kind === 'theme' ? h('button', { class: 'btn small', onclick: () => { settings.set({ theme: theme!.id }); toast('تم اختيار الطاولة'); } }, 'استخدم') :
              h('button', { class: `btn small${equipped ? ' on' : ''}`, onclick: () => equipItem(equipped ? null : i.id, i.kind as any).catch(e => toast(e.message)) }, equipped ? 'لابسه ✓' : 'البس'))
            : h('button', { class: 'btn small primary', onclick: async () => {
              if (p.coins < i.price) { toast('رصيدك ما يكفي'); tab = 'coins'; draw(); return; }
              if (!(await confirmBox(`تشتري ${i.name} بـ ${i.price} بيزة؟`, 'اشتر'))) return;
              try { await buyItem(i.id); toast('مبروك!'); play('r_clap'); } catch (e: any) { toast(e.message); }
            } }, `🪙 ${i.price}`));
      }));
    mount(root, screen(
      topbar('المتجر'),
      h('div', { class: 'tabs' }, ...TABS.map(t => h('button', { class: tab === t.id ? 'on' : '', onclick: () => { tab = t.id; draw(); } }, t.label))),
      content,
      tab === 'coins' ? h('p', { class: 'muted small center' }, 'الدفع عن طريق Google Play. تكسب بيزات بعد على كل لعبة أونلاين.') : null));
  }
  draw();
  return profileStore.on(() => draw());
});

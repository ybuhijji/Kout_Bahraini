// Tiny DOM helpers.
type Child = Node | string | null | undefined | false;
type Props = Record<string, any>;

export function h<K extends keyof HTMLElementTagNameMap>(tag: K, props: Props = {}, ...children: (Child | Child[])[]): HTMLElementTagNameMap[K] {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(props)) {
    if (v === undefined || v === null || v === false) continue;
    if (k === 'class') el.className = v;
    else if (k === 'style' && typeof v === 'object') {
      for (const [sk, sv] of Object.entries(v)) {
        if (sk.startsWith('--')) el.style.setProperty(sk, String(sv));
        else (el.style as any)[sk] = sv;
      }
    }
    else if (k.startsWith('on') && typeof v === 'function') el.addEventListener(k.slice(2).toLowerCase(), v);
    else if (k === 'html') el.innerHTML = v;
    else el.setAttribute(k, v === true ? '' : String(v));
  }
  for (const c of children.flat()) {
    if (c === null || c === undefined || c === false) continue;
    el.append(typeof c === 'string' ? document.createTextNode(c) : c);
  }
  return el;
}

export function mount(root: HTMLElement, ...nodes: Node[]) {
  root.replaceChildren(...nodes);
}

let toastTimer: number | undefined;
export function toast(msg: string, ms = 2600) {
  let t = document.getElementById('toast');
  if (!t) { t = h('div', { id: 'toast' }); document.body.append(t); }
  t.textContent = msg;
  t.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = window.setTimeout(() => t!.classList.remove('show'), ms);
}

export function modal(content: Node, opts: { dismiss?: boolean } = {}): () => void {
  const back = h('div', { class: 'modal-back' }, h('div', { class: 'modal' }, content));
  const close = () => back.remove();
  if (opts.dismiss !== false) back.addEventListener('click', e => { if (e.target === back) close(); });
  document.body.append(back);
  return close;
}

export function confirmBox(msg: string, yes = 'نعم', no = 'إلغاء'): Promise<boolean> {
  return new Promise(res => {
    let close = () => {};
    const box = h('div', { class: 'col gap' },
      h('p', {}, msg),
      h('div', { class: 'row gap' },
        h('button', { class: 'btn primary', onclick: () => { close(); res(true); } }, yes),
        h('button', { class: 'btn', onclick: () => { close(); res(false); } }, no)));
    close = modal(box, { dismiss: false });
  });
}

export const sleep = (ms: number) => new Promise(r => setTimeout(r, ms));

export function esc(s: string) {
  return s.replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]!));
}

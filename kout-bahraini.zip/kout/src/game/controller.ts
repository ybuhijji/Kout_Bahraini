import { Action, GameEvent, MatchState, Variant, apply, mulberry32, newMatch, viewFor } from '../../shared/engine';
import { BotLevel, bestTrump, chooseAction } from '../../shared/bot';
import { delayMs, settings } from '../settings';

export interface SeatInfo {
  name: string;
  bot: boolean;
  uid?: string;
  avatar?: string;     // emoji or image url
  accessory?: string;  // equipped store item id
  majlis?: string;     // majlis tag
}

export type ViewState = MatchState & { handCounts: number[] };

export interface GameController {
  readonly online: boolean;
  readonly mySeat: number;
  seats: SeatInfo[];
  view(): ViewState;
  act(a: Action): Promise<void>;
  /** Called on every state change with the events that caused it. */
  subscribe(cb: (events: GameEvent[]) => void): () => void;
  react(slot: string): void;
  onReaction(cb: (seat: number, slot: string) => void): () => void;
  /** Epoch ms when the current turn times out, if it has a timer. */
  deadline?(): number | null;
  /** True while a move this phone sent is waiting for the server. */
  pending?(): boolean;
  /** Online: is a bot covering this seat because the player is away? */
  seatAway?(seat: number): boolean;
  away?(): boolean;
  rejoin?(): Promise<void>;
  leave(): void;
}

const BOT_NAMES = ['بو جاسم', 'بو خليل', 'بو علي', 'بو عيسى', 'بو راشد', 'بو حسن', 'بو محمد', 'بو يوسف'];
const BOT_ITEMS = ['misbah_wood', 'karak', 'dallah', 'ghutra', 'misbah_kahraman', undefined];

/** Offline match against bots on this device. */
export class LocalController implements GameController {
  readonly online = false;
  readonly mySeat = 0;
  seats: SeatInfo[];
  private s: MatchState;
  private rng = mulberry32(Date.now() & 0xffffffff);
  private subs = new Set<(e: GameEvent[]) => void>();
  private reacts = new Set<(seat: number, slot: string) => void>();
  private stopped = false;
  private busy = false;
  private myDeadline: number | null = null;
  private myTimer: number | undefined;
  static readonly BID_MS = 10_000;

  constructor(variant: Variant, me: SeatInfo, private level: BotLevel = settings.get().botLevel) {
    this.s = newMatch(variant, this.rng, Math.floor(Math.random() * variant));
    const names = BOT_NAMES.slice().sort(() => Math.random() - 0.5);
    this.seats = Array.from({ length: variant }, (_, i) =>
      i === 0 ? me : { name: names[i], bot: true, avatar: '🧔', accessory: BOT_ITEMS[i % BOT_ITEMS.length] });
    setTimeout(() => { this.emit([]); this.runBots(); }, 600);
  }

  view() { return viewFor(this.s, this.mySeat); }

  subscribe(cb: (e: GameEvent[]) => void) { this.subs.add(cb); return () => this.subs.delete(cb); }
  onReaction(cb: (seat: number, slot: string) => void) { this.reacts.add(cb); return () => this.reacts.delete(cb); }

  react(slot: string) {
    this.reacts.forEach(r => r(this.mySeat, slot));
  }

  deadline() { return this.myDeadline; }

  private emit(ev: GameEvent[]) {
    this.armBidTimer();
    this.subs.forEach(s => s(ev));
  }

  /** 10 seconds to bid (or pick trump); when it runs out you are skipped. */
  private armBidTimer() {
    const s = this.s;
    const mine = (s.phase === 'bidding' && s.bidTurn === this.mySeat) || (s.phase === 'trump' && s.bidder === this.mySeat);
    if (!mine) { clearTimeout(this.myTimer); this.myDeadline = null; return; }
    if (this.myDeadline) return;
    this.myDeadline = Date.now() + LocalController.BID_MS;
    this.myTimer = window.setTimeout(() => {
      if (this.stopped) return;
      const cur = this.s;
      if (cur.phase === 'bidding' && cur.bidTurn === this.mySeat) this.act({ type: 'pass', seat: this.mySeat });
      else if (cur.phase === 'trump' && cur.bidder === this.mySeat) this.act({ type: 'trump', seat: this.mySeat, suit: bestTrump(cur.hands[this.mySeat]).suit });
    }, LocalController.BID_MS);
  }

  async act(a: Action) {
    if (a.type !== 'nextHand' && (a as any).seat === this.mySeat) { clearTimeout(this.myTimer); this.myDeadline = null; }
    const ev = apply(this.s, a, this.rng);
    this.emit(ev);
    if (a.type === 'play' && ev.some(e => e.type === 'trickWon')) await this.pause(1100);
    this.runBots();
  }

  private pause(ms: number) { return new Promise(r => setTimeout(r, delayMs(ms))); }

  private actorSeat(): number | null {
    const s = this.s;
    if (s.phase === 'bidding') return s.bidTurn;
    if (s.phase === 'trump') return s.bidder;
    if (s.phase === 'playing') return s.turn;
    return null;
  }

  private async runBots() {
    if (this.busy) return;
    this.busy = true;
    try {
      while (!this.stopped) {
        const seat = this.actorSeat();
        if (seat === null || seat === this.mySeat) break;
        await this.pause(this.s.phase === 'bidding' ? 700 : 750);
        if (this.stopped) break;
        const a = chooseAction(this.s, seat, this.level);
        const ev = apply(this.s, a, this.rng);
        this.emit(ev);
        // Occasional bot banter
        if (ev.some(e => e.type === 'handOver') && Math.random() < 0.3) {
          const slot = ['r_laugh', 'r_clap', 'r_wow'][Math.floor(Math.random() * 3)];
          setTimeout(() => this.reacts.forEach(r => r(seat, slot)), 400);
        }
        if (ev.some(e => e.type === 'trickWon')) await this.pause(1100);
      }
    } finally {
      this.busy = false;
    }
  }

  nextHand() {
    if (this.s.phase !== 'handOver') return;
    this.act({ type: 'nextHand' });
  }

  leave() { this.stopped = true; clearTimeout(this.myTimer); this.subs.clear(); }
}

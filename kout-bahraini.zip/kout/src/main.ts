import '@fontsource/tajawal/400.css';
import '@fontsource/tajawal/700.css';
import '@fontsource/tajawal/900.css';
import '@fontsource/reem-kufi/700.css';
import './styles.css';
import { App } from '@capacitor/app';
import { Capacitor } from '@capacitor/core';
import { go, back, canGoBack, setRoot } from './router';
import { isVerified, profileStore } from './net/profile';
import { InviteTarget, parseInvite } from './net/invite';
import { joinRoom } from './net/online';
import { joinMajlis } from './net/majlis';
import { onlineConfigured } from './net/firebase';
import { toast } from './dom';
import './ui/home';
import './ui/account';
import './ui/online';
import './ui/majlis';
import './ui/store';

const root = document.getElementById('app')!;
setRoot(root);
profileStore.start();
go('home');

// ---------- invite links (koutbh://join/CODE, koutbh://majlis/ID) ----------
let pendingInvite: InviteTarget | null = null;

async function openInvite(target: InviteTarget) {
  const user = profileStore.user();
  if (!onlineConfigured) return;
  if (!user || !isVerified(user) || !profileStore.get()) {
    pendingInvite = target;                      // handled once the player has signed in
    if (!user) { toast('سجل دخول عشان تدخل الطاولة'); go('login', { next: 'home' }); }
    return;
  }
  pendingInvite = null;
  try {
    if (target.kind === 'join') {
      const r = await joinRoom(target.code);
      go('room', { roomId: r.roomId });
    } else {
      await joinMajlis(target.id);
      toast('هلا فيك في المجلس');
      go('majlis');
    }
  } catch (e: any) {
    toast(e.message);
    if (target.kind === 'majlis') go('majlis');
  }
}

profileStore.on(p => { if (p && pendingInvite) openInvite(pendingInvite); });

if (Capacitor.isNativePlatform()) {
  App.addListener('appUrlOpen', ({ url }) => { const t = parseInvite(url); if (t) openInvite(t); });
  App.getLaunchUrl().then(r => { const t = r?.url ? parseInvite(r.url) : null; if (t) openInvite(t); });

  App.addListener('backButton', () => {
    if (document.querySelector('.modal-back')) { (document.querySelector('.modal-back') as HTMLElement).click(); return; }
    if (document.querySelector('.table-screen')) { (document.querySelector('.tbl-head .icon-btn') as HTMLElement)?.click(); return; }
    if (canGoBack()) back(); else App.exitApp();
  });
}

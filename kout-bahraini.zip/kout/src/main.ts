import '@fontsource/tajawal/400.css';
import '@fontsource/tajawal/700.css';
import '@fontsource/tajawal/900.css';
import '@fontsource/reem-kufi/700.css';
import './styles.css';
import { App } from '@capacitor/app';
import { Capacitor } from '@capacitor/core';
import { go, back, canGoBack, setRoot } from './router';
import { profileStore } from './net/profile';
import './ui/home';
import './ui/account';
import './ui/online';
import './ui/majlis';
import './ui/store';

const root = document.getElementById('app')!;
setRoot(root);
profileStore.start();
go('home');

if (Capacitor.isNativePlatform()) {
  App.addListener('backButton', () => {
    if (document.querySelector('.modal-back')) { (document.querySelector('.modal-back') as HTMLElement).click(); return; }
    if (document.querySelector('.table-screen')) { (document.querySelector('.tbl-head .icon-btn') as HTMLElement)?.click(); return; }
    if (canGoBack()) back(); else App.exitApp();
  });
}

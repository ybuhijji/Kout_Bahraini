// Reads the Firebase web config pasted into the FIREBASE_CONFIG GitHub secret
// (either the JS snippet from Firebase console or plain JSON).
//   node scripts/firebase-config.mjs write    -> fills src/net/firebase-config.ts
//   node scripts/firebase-config.mjs project  -> prints the project ID
import fs from 'node:fs';

const raw = process.env.FIREBASE_CONFIG ?? '';
const keys = ['apiKey', 'authDomain', 'projectId', 'storageBucket', 'messagingSenderId', 'appId'];
const cfg = {};
for (const k of keys) {
  const m = raw.match(new RegExp(`["']?${k}["']?\\s*:\\s*["']([^"']+)["']`));
  if (m) cfg[k] = m[1];
}
if (!cfg.apiKey || !cfg.projectId || !cfg.appId) {
  console.error('FIREBASE_CONFIG secret is missing or incomplete (need apiKey, projectId, appId).');
  process.exit(1);
}

if (process.argv[2] === 'project') {
  process.stdout.write(cfg.projectId);
} else {
  const file = 'src/net/firebase-config.ts';
  let src = fs.readFileSync(file, 'utf8');
  for (const k of keys) src = src.replace(new RegExp(`${k}: '[^']*'`), `${k}: '${cfg[k] ?? ''}'`);
  fs.writeFileSync(file, src);
  console.log(`Firebase config written for project ${cfg.projectId}`);
}

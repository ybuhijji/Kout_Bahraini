"""Builds the card sounds bundled with the app (public/sounds/card_place.wav, card_slide.wav).

Physically modelled from noise, so they are original and free to ship:
  card_slide: the swish of air as a card is flicked off the hand.
  card_place: a card landing on felt: a crisp paper snap, its fast flutter, and a soft table thud.
Run:  python3 scripts/make-card-sounds.py
To use a real recording instead, replace the .wav files (same names) and rebuild.
"""
import numpy as np
from scipy.signal import butter, sosfilt
from scipy.io import wavfile

SR = 44100
rng = np.random.default_rng(20261024)


def band(x, lo, hi, order=2):
    return sosfilt(butter(order, [lo, hi], btype='band', fs=SR, output='sos'), x)


def high(x, f, order=2):
    return sosfilt(butter(order, f, btype='high', fs=SR, output='sos'), x)


def low(x, f, order=2):
    return sosfilt(butter(order, f, btype='low', fs=SR, output='sos'), x)


def env(n, attack, decay):
    t = np.arange(n) / SR
    a = np.clip(t / max(attack, 1e-4), 0, 1)
    return a * np.exp(-np.maximum(t - attack, 0) / decay)


def fade(x, ms=4):
    k = int(SR * ms / 1000)
    x[-k:] *= np.linspace(1, 0, k)
    return x


def normalize(x, peak=0.89):
    return x / (np.max(np.abs(x)) + 1e-9) * peak


def card_place():
    n = int(SR * 0.16)
    t = np.arange(n) / SR
    # 1) the paper snap: broadband click, strongest 1.1 to 5.5 kHz, very fast decay
    snap = band(rng.standard_normal(n), 1100, 5500) * env(n, 0.0006, 0.011)
    # 2) the card's edge fluttering as it settles: brief band-limited noise, 2nd smaller hit
    flutter = band(rng.standard_normal(n), 900, 3500) * env(n, 0.002, 0.022) * 0.35
    second = np.zeros(n)
    k = int(SR * 0.009)
    second[k:] = (band(rng.standard_normal(n - k), 2000, 6000) * env(n - k, 0.0004, 0.006))[: n - k] * 0.45
    # 3) the table under the felt: low, short, damped thump
    f = 170 * np.exp(-t / 0.03) + 70
    thump = np.sin(2 * np.pi * np.cumsum(f) / SR) * env(n, 0.0015, 0.02) * 0.8
    thump = low(thump, 400)
    # 4) a breath of air pushed out from under the card
    air = low(rng.standard_normal(n), 1200) * env(n, 0.004, 0.03) * 0.18
    x = snap + flutter + second + thump + air
    x = high(x, 60)
    return fade(normalize(x))


def card_slide():
    n = int(SR * 0.17)
    t = np.arange(n) / SR
    noise = rng.standard_normal(n)
    # swish: band of noise whose center rises then falls, like a card cutting the air
    out = np.zeros(n)
    hop = 256
    for i in range(0, n, hop):
        seg = slice(max(0, i - hop), min(n, i + 2 * hop))
        frac = i / n
        center = 1100 + 1700 * np.sin(np.pi * min(frac * 1.2, 1))
        y = band(noise[seg], center * 0.6, min(center * 1.5, SR / 2 - 100))
        mid = slice(i, min(n, i + hop))
        out[mid] = y[(i - seg.start):(i - seg.start) + (mid.stop - mid.start)]
    shape = np.sin(np.pi * np.clip(t / 0.15, 0, 1)) ** 1.6
    x = out * shape
    x = high(x, 300)
    return fade(normalize(x, 0.55))


def stats(name, x):
    spec = np.abs(np.fft.rfft(x))
    freqs = np.fft.rfftfreq(len(x), 1 / SR)
    centroid = float((spec * freqs).sum() / spec.sum())
    e = np.abs(x)
    peak_ms = 1000 * np.argmax(e) / SR
    above = np.where(e > 0.05 * e.max())[0]
    length_ms = 1000 * (above[-1] - above[0]) / SR
    print(f'{name}: {len(x)/SR*1000:.0f} ms file, audible ~{length_ms:.0f} ms, peak at {peak_ms:.1f} ms, spectral centre {centroid:.0f} Hz')


if __name__ == '__main__':
    import os
    out = os.path.join(os.path.dirname(__file__), '..', 'public', 'sounds')
    for name, fn in [('card_place', card_place), ('card_slide', card_slide)]:
        x = fn()
        stats(name, x)
        wavfile.write(os.path.join(out, f'{name}.wav'), SR, (x * 32767).astype(np.int16))

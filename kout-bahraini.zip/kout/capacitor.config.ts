import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  // Change this once, before the first upload to Play Store. It can never change afterwards.
  appId: 'bh.kout.game',
  appName: 'كوت بحريني',
  webDir: 'dist',
  android: {
    backgroundColor: '#0b1d16',
  },
  plugins: {
    FirebaseAuthentication: {
      // Native SDKs do the provider login; the web Firebase SDK holds the session.
      skipNativeAuth: true,
      providers: ['google.com', 'facebook.com', 'twitter.com'],
    },
  },
};

export default config;

# سياسة الخصوصية / Privacy Policy: كوت بحريني

_Last updated: [date]. Replace the bracketed parts before publishing. This is a starting draft, not legal advice; have it reviewed against Bahrain's Personal Data Protection Law (PDPL)._

**Who we are.** "كوت بحريني" is published by [your name or company], [address], Bahrain. Contact: [email].

**What we collect**
- Account details: your display name, email address, and the ID of the login provider you choose (Google, Facebook, X, or email).
- Game data: matches played, wins, coins, items owned, Majlis membership.
- Messages you write in Majlis chat.
- Purchase records from Google Play (we receive an order ID and product, not your card details).
- Basic technical data needed to run the service (device type, app version, error logs).

**Why we use it.** To create your account, run online matches, keep your coins and items, run Majlis features, verify purchases, prevent cheating and abuse, and fix problems.

**Who we share it with.** Google Firebase and Google Cloud (hosting and database), Google Play (payments), and the login provider you choose. We do not sell personal data and do not show ads.

**Other players see** your display name, avatar, equipped items, Majlis tag, and messages you post in your Majlis.

**Storage and retention.** Data is stored on Google Cloud servers in [region]. We keep it while your account is active. When you delete your account (Profile → حذف الحساب) your profile and login are deleted; purchase records may be kept as long as the law requires.

**Your rights.** You can access, correct, or delete your data. Delete your account in the app, or email [email].

**Children.** The game is intended for players aged 18 and over.

**Changes.** We will post updates on this page.

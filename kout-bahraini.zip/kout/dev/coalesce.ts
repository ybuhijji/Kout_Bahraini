// Dev-only check: a hand ends, then the next update arrives without the "dealt" message
// (what happens online when updates arrive together). The result box must close by itself.
import '../src/styles.css';
import { apply, mulberry32, newMatch, viewFor, MatchState, GameEvent } from '../shared/engine';
import { chooseAction } from '../shared/bot';
import { renderTable } from '../src/ui/table';

const rng = mulberry32(7);
let s: MatchState = newMatch(4, rng, 0);
s.handNo = 1;
const subs = new Set<(e: GameEvent[]) => void>();
const ctrl: any = {
  online: true, mySeat: 0,
  seats: [0, 1, 2, 3].map(i => ({ name: 'لاعب ' + i, bot: i !== 0 })),
  view: () => viewFor(s, 0), act: async () => {}, react() {}, leave() {},
  subscribe: (cb: any) => { subs.add(cb); return () => subs.delete(cb); },
  onReaction: () => () => {}, deadline: () => null, pending: () => false,
};
renderTable(document.getElementById('app')!, ctrl, { onExit() {} });
const emit = (e: GameEvent[]) => subs.forEach(f => f(e));
// Play bots to the end of the hand
while (s.phase !== 'handOver' && s.phase !== 'matchOver') {
  const seat = s.phase === 'bidding' ? s.bidTurn : s.phase === 'trump' ? s.bidder! : s.turn;
  apply(s, chooseAction(s, seat, 'normal', rng), rng);
}
(window as any).phase1 = s.phase;
emit([{ type: 'handOver', result: s.lastHand! }]);
setTimeout(() => {
  (window as any).modalAfterHand = !!document.querySelector('.modal-back');
  // Next hand dealt AND bidding already moved on, delivered as one update with no 'dealt' message
  apply(s, { type: 'nextHand' }, rng);
  const seat = s.bidTurn;
  apply(s, chooseAction(s, seat, 'normal', rng), rng);
  emit([{ type: 'bid', seat, bid: 5 } as any]);
  setTimeout(() => { (window as any).modalAfterSkip = !!document.querySelector('.modal-back'); (window as any).done = true; }, 300);
}, 1500);

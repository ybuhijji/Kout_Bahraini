// Dev-only preview of the end-of-game box (win, then loss).
import '../src/styles.css';
import '@fontsource/reem-kufi/700.css';
import '@fontsource/tajawal/700.css';
import { mulberry32, newMatch, viewFor } from '../shared/engine';
import { renderTable } from '../src/ui/table';
const won = new URLSearchParams(location.search).get('w') !== '0';
const s = newMatch(4, mulberry32(1), 0);
Object.assign(s, { phase: 'matchOver', winner: won ? 0 : 1, winReason: 'points', score: won ? 33 : -33, dealerDraw: [] });
const ctrl: any = {
  online: true, mySeat: 0, seats: ['أنت', 'بو علي', 'جاسم', 'بو حسن'].map(name => ({ name, bot: false })),
  view: () => viewFor(s, 0), act: async () => {}, react() {}, leave() {},
  subscribe: () => () => {}, onReaction: () => () => {}, deadline: () => null, pending: () => false,
};
renderTable(document.getElementById('app')!, ctrl, { onExit() {}, onRematch() {} });

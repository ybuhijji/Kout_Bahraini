// Dev-only preview: this player is away (bot covering), and the player opposite is away too.
import '../src/styles.css';
import '@fontsource/tajawal/700.css';
import { apply, mulberry32, newMatch, viewFor, MatchState } from '../shared/engine';
import { chooseAction } from '../shared/bot';
import { renderTable } from '../src/ui/table';
const rng = mulberry32(3);
const s: MatchState = newMatch(4, rng, 0);
while (s.phase !== 'playing') {
  const seat = s.phase === 'bidding' ? s.bidTurn : s.bidder!;
  apply(s, chooseAction(s, seat, 'normal', rng), rng);
}
for (let k = 0; k < 2; k++) apply(s, chooseAction(s, s.turn, 'normal', rng), rng);
const ctrl: any = {
  online: true, mySeat: 0,
  seats: [{ name: 'يوسف', bot: false, avatar: '🦅' }, { name: 'بو علي', bot: true, avatar: '🤖' }, { name: 'جاسم', bot: false, avatar: '😎' }, { name: 'بو حسن', bot: true, avatar: '🤖' }],
  view: () => viewFor(s, 0), act: async () => {}, react() {}, leave() {},
  subscribe: () => () => {}, onReaction: () => () => {}, deadline: () => null, pending: () => false,
  seatAway: (i: number) => i === 0 || i === 2, away: () => true, rejoin: async () => {},
};
renderTable(document.getElementById('app')!, ctrl, { onExit() {} });

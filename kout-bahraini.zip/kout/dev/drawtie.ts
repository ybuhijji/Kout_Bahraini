// Dev-only preview: an opening draw with a tie, played back round by round.
import '../src/styles.css';
import '@fontsource/tajawal/700.css';
import { mulberry32, newMatch, viewFor, MatchState } from '../shared/engine';
import { renderTable } from '../src/ui/table';
let s!: MatchState;
for (let seed = 0; ; seed++) { s = newMatch(4, mulberry32(seed)); if (s.dealerDraw.some(d => d.round === 1)) break; }
(window as any).draws = s.dealerDraw;
const ctrl: any = {
  online: false, mySeat: 0,
  seats: ['أنت', 'بو علي', 'بو حسن', 'بو يوسف'].map((name, i) => ({ name, bot: i !== 0 })),
  view: () => viewFor(s, 0), act: async () => {}, react() {}, leave() {},
  subscribe: () => () => {}, onReaction: () => () => {}, deadline: () => null, pending: () => false,
};
renderTable(document.getElementById('app')!, ctrl, { onExit() {} });

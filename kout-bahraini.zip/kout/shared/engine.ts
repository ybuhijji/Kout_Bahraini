// Bahraini Kout rules engine. Pure TypeScript, no DOM, shared by the app and Cloud Functions.
//
// Seats are numbered in PLAY ORDER (counterclockwise around the table).
// Seat i+1 is the player on seat i's right. Teams alternate: team = seat % 2.

export type Suit = 'S' | 'H' | 'C' | 'D';
export type Card = string; // e.g. "AS", "10H", "7D", or "JK" for the red Joker
export type Variant = 4 | 6;
export type BidValue = 5 | 6 | 7 | 8; // 8 = Inzeli (all tricks)

export const JOKER: Card = 'JK';
export const INZELI: BidValue = 8;
export const TRICKS_PER_HAND = 8;
export const WIN_SCORE = 31;
export const SUITS: Suit[] = ['S', 'H', 'C', 'D'];
export const SUIT_SYMBOL: Record<Suit, string> = { S: '♠', H: '♥', C: '♣', D: '♦' };
export const SUIT_NAME_AR: Record<Suit, string> = { S: 'سبيت', H: 'هاس', C: 'شريها', D: 'ديمن' };

export type Phase = 'bidding' | 'trump' | 'playing' | 'handOver' | 'matchOver';
export type WinReason = 'points' | 'inzeli' | 'inzeliFailed' | 'khayes';

export interface PlayedCard { seat: number; card: Card }

export interface HandResult {
  bidder: number;
  bid: BidValue;
  bidderTeamTricks: number;
  made: boolean;
  points: number;        // points moved
  toTeam: 0 | 1;         // team the points moved toward
  khayesSeat?: number;   // set when the hand ended by leading the Joker
}

export interface MatchState {
  variant: Variant;
  players: number;
  handNo: number;            // 0 = first hand of the match (Inzeli not allowed)
  dealer: number;
  score: number;             // running score: >0 means team 0 is ahead, <0 team 1
  phase: Phase;
  hands: Card[][];
  // bidding
  bidTurn: number;
  highBid: BidValue | null;
  highBidder: number | null;
  passed: boolean[];
  bidLog: { seat: number; bid: BidValue | 'pass' }[];
  // contract
  bid: BidValue | null;
  bidder: number | null;
  trump: Suit | null;
  // play
  turn: number;
  trick: PlayedCard[];
  lastTrick: PlayedCard[] | null;
  lastTrickWinner: number | null;
  tricksWon: [number, number];
  played: Card[];            // every card played this hand, for bots and UI
  // outcome
  lastHand: HandResult | null;
  winner: 0 | 1 | null;
  winReason: WinReason | null;
  redeals: number;
}

export type Action =
  | { type: 'bid'; seat: number; bid: BidValue }
  | { type: 'pass'; seat: number }
  | { type: 'trump'; seat: number; suit: Suit }
  | { type: 'play'; seat: number; card: Card }
  | { type: 'nextHand' };

export type GameEvent =
  | { type: 'dealt' }
  | { type: 'bid'; seat: number; bid: BidValue }
  | { type: 'pass'; seat: number }
  | { type: 'redeal' }
  | { type: 'contract'; seat: number; bid: BidValue }
  | { type: 'trump'; seat: number; suit: Suit }
  | { type: 'play'; seat: number; card: Card }
  | { type: 'trickWon'; seat: number; cards: PlayedCard[] }
  | { type: 'handOver'; result: HandResult }
  | { type: 'khayes'; seat: number }
  | { type: 'matchOver'; winner: 0 | 1; reason: WinReason };

export class RuleError extends Error {}

// ---------- cards ----------

export function suitOf(c: Card): Suit | null {
  return c === JOKER ? null : (c.slice(-1) as Suit);
}
export function rankOf(c: Card): number {
  if (c === JOKER) return 100;
  const r = c.slice(0, -1);
  return ({ J: 11, Q: 12, K: 13, A: 14 } as Record<string, number>)[r] ?? Number(r);
}
export function rankLabel(c: Card): string {
  return c === JOKER ? 'J' : c.slice(0, -1);
}
export function teamOf(seat: number): 0 | 1 {
  return (seat % 2) as 0 | 1;
}

/** Bahraini decks. bu 4: 32 cards, bu 6: 48 cards, both with one red Joker. */
export function buildDeck(variant: Variant): Card[] {
  const low = variant === 4 ? 7 : 3; // lowest rank in spades, hearts, clubs
  const deck: Card[] = [JOKER];
  const names: Record<number, string> = { 11: 'J', 12: 'Q', 13: 'K', 14: 'A' };
  for (const s of SUITS) {
    const start = s === 'D' ? low + 1 : low; // diamonds start one rank higher
    for (let r = start; r <= 14; r++) deck.push((names[r] ?? String(r)) + s);
  }
  return deck;
}

export type Rng = () => number;

export function mulberry32(seed: number): Rng {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export function shuffle<T>(arr: T[], rng: Rng): T[] {
  const a = arr.slice();
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

const SUIT_ORDER: Record<string, number> = { S: 0, H: 1, C: 2, D: 3 };
export function sortHand(hand: Card[]): Card[] {
  return hand.slice().sort((a, b) => {
    if (a === JOKER) return -1;
    if (b === JOKER) return 1;
    const ds = SUIT_ORDER[suitOf(a)!] - SUIT_ORDER[suitOf(b)!];
    return ds !== 0 ? ds : rankOf(b) - rankOf(a);
  });
}

// ---------- match setup ----------

export function newMatch(variant: Variant, rng: Rng, dealer = 0): MatchState {
  const players = variant;
  const s: MatchState = {
    variant, players, handNo: 0, dealer, score: 0, phase: 'bidding',
    hands: [], bidTurn: 0, highBid: null, highBidder: null, passed: [], bidLog: [],
    bid: null, bidder: null, trump: null, turn: 0, trick: [], lastTrick: null,
    lastTrickWinner: null, tricksWon: [0, 0], played: [], lastHand: null,
    winner: null, winReason: null, redeals: 0,
  };
  deal(s, rng);
  return s;
}

function deal(s: MatchState, rng: Rng) {
  const deck = shuffle(buildDeck(s.variant), rng);
  s.hands = Array.from({ length: s.players }, (_, i) =>
    sortHand(deck.slice(i * TRICKS_PER_HAND, (i + 1) * TRICKS_PER_HAND)));
  s.phase = 'bidding';
  s.bidTurn = (s.dealer + 1) % s.players; // player on the dealer's right bids first
  s.highBid = null; s.highBidder = null;
  s.passed = Array(s.players).fill(false);
  s.bidLog = [];
  s.bid = null; s.bidder = null; s.trump = null;
  s.trick = []; s.lastTrick = null; s.lastTrickWinner = null;
  s.tricksWon = [0, 0]; s.played = [];
}

// ---------- queries ----------

export function holdsJoker(s: MatchState, seat: number) {
  return s.hands[seat].includes(JOKER);
}

/** Bids the seat may make right now (pass is always allowed). */
export function legalBids(s: MatchState, seat: number): BidValue[] {
  if (s.phase !== 'bidding' || s.bidTurn !== seat) return [];
  const out: BidValue[] = [];
  for (const b of [5, 6, 7] as BidValue[]) if (s.highBid === null || b > s.highBid) out.push(b);
  if (s.handNo > 0 && holdsJoker(s, seat)) out.push(INZELI);
  return out;
}

/** First lead of an Inzeli hand, by the player on the caller's right. */
export function mustLeadTrump(s: MatchState, seat: number): boolean {
  return s.bid === INZELI && s.bidder !== null && s.played.length === 0 &&
    seat === (s.bidder + 1) % s.players;
}

/** Everyone else has passed with no bid: this seat decides between bidding and a reshuffle. */
export function isLastToBid(s: MatchState, seat: number): boolean {
  return s.phase === 'bidding' && s.bidTurn === seat && s.highBid === null &&
    s.passed.filter(p => !p).length === 1;
}

/** Cards the seat may play right now. */
export function legalCards(s: MatchState, seat: number): Card[] {
  if (s.phase !== 'playing' || s.turn !== seat) return [];
  const hand = s.hands[seat];
  if (s.trick.length === 0) {
    // Leading: the Joker may never lead.
    const leads = hand.filter(c => c !== JOKER);
    // Inzeli: the player on the caller's right opens the hand and must lead trump if he has one.
    if (mustLeadTrump(s, seat)) {
      const trumps = leads.filter(c => suitOf(c) === s.trump);
      if (trumps.length) return trumps;
    }
    return leads;
  }
  const led = suitOf(s.trick[0].card)!;
  const follow = hand.filter(c => suitOf(c) === led);
  if (follow.length > 0) {
    // Must follow suit; the Joker may still be played (it is the top trump).
    return hand.includes(JOKER) ? [...follow, JOKER] : follow;
  }
  return hand.slice();
}

export function trickWinner(trick: PlayedCard[], trump: Suit): PlayedCard {
  const led = suitOf(trick[0].card);
  const power = (c: Card) => {
    if (c === JOKER) return 1000;
    const su = suitOf(c);
    if (su === trump) return 500 + rankOf(c);
    if (su === led) return 100 + rankOf(c);
    return 0;
  };
  return trick.reduce((best, p) => (power(p.card) > power(best.card) ? p : best));
}

export function tricksNeeded(bid: BidValue) {
  return bid === INZELI ? TRICKS_PER_HAND : bid;
}

export function teamName(team: 0 | 1) {
  return team === 0 ? 'نحن' : 'هم';
}

// ---------- reducer ----------

/** Applies an action. Mutates and returns the state, plus the events it produced. */
export function apply(s: MatchState, a: Action, rng: Rng): GameEvent[] {
  const ev: GameEvent[] = [];
  switch (a.type) {
    case 'bid':
    case 'pass': {
      if (s.phase !== 'bidding') throw new RuleError('not bidding');
      if (a.seat !== s.bidTurn) throw new RuleError('not your turn to bid');
      if (a.type === 'bid') {
        if (!legalBids(s, a.seat).includes(a.bid)) throw new RuleError('illegal bid');
        s.highBid = a.bid; s.highBidder = a.seat;
        s.bidLog.push({ seat: a.seat, bid: a.bid });
        ev.push({ type: 'bid', seat: a.seat, bid: a.bid });
      } else {
        s.passed[a.seat] = true;
        s.bidLog.push({ seat: a.seat, bid: 'pass' });
        ev.push({ type: 'pass', seat: a.seat });
      }
      const active = s.passed.map((p, i) => (!p ? i : -1)).filter(i => i >= 0);
      const done =
        s.highBid === INZELI ||
        (s.highBidder !== null && active.length === 1 && active[0] === s.highBidder) ||
        active.length === 0;
      if (done) {
        if (s.highBidder === null) {
          // Everyone passed: redeal with the next dealer.
          s.redeals++;
          s.dealer = (s.dealer + 1) % s.players;
          deal(s, rng);
          ev.push({ type: 'redeal' }, { type: 'dealt' });
        } else {
          s.bid = s.highBid; s.bidder = s.highBidder;
          s.phase = 'trump';
          ev.push({ type: 'contract', seat: s.bidder!, bid: s.bid! });
        }
      } else {
        let n = (s.bidTurn + 1) % s.players;
        while (s.passed[n]) n = (n + 1) % s.players;
        s.bidTurn = n;
      }
      return ev;
    }
    case 'trump': {
      if (s.phase !== 'trump' || a.seat !== s.bidder) throw new RuleError('not your trump call');
      s.trump = a.suit;
      s.phase = 'playing';
      s.turn = (s.bidder! + 1) % s.players; // player on the bid winner's right leads
      ev.push({ type: 'trump', seat: a.seat, suit: a.suit });
      checkKhayes(s, ev);
      return ev;
    }
    case 'play': {
      if (!legalCards(s, a.seat).includes(a.card)) throw new RuleError('illegal card');
      s.hands[a.seat] = s.hands[a.seat].filter(c => c !== a.card);
      s.trick.push({ seat: a.seat, card: a.card });
      s.played.push(a.card);
      ev.push({ type: 'play', seat: a.seat, card: a.card });
      if (s.trick.length < s.players) {
        s.turn = (s.turn + 1) % s.players;
        return ev;
      }
      const w = trickWinner(s.trick, s.trump!);
      s.tricksWon[teamOf(w.seat)]++;
      s.lastTrick = s.trick; s.lastTrickWinner = w.seat;
      ev.push({ type: 'trickWon', seat: w.seat, cards: s.trick });
      s.trick = [];
      s.turn = w.seat;
      if (!resolveIfDecided(s, ev)) checkKhayes(s, ev);
      return ev;
    }
    case 'nextHand': {
      if (s.phase !== 'handOver') throw new RuleError('hand not over');
      s.handNo++;
      s.dealer = (s.dealer + 1) % s.players;
      deal(s, rng);
      ev.push({ type: 'dealt' });
      return ev;
    }
  }
}

/** A player forced to lead with only the Joker left: خيس الجوكر, their team loses. */
function checkKhayes(s: MatchState, ev: GameEvent[]) {
  if (s.phase !== 'playing' || s.trick.length !== 0) return;
  const h = s.hands[s.turn];
  if (h.length === 1 && h[0] === JOKER) {
    const loser = teamOf(s.turn);
    s.lastHand = {
      bidder: s.bidder!, bid: s.bid!, bidderTeamTricks: s.tricksWon[teamOf(s.bidder!)],
      made: false, points: 0, toTeam: (1 - loser) as 0 | 1, khayesSeat: s.turn,
    };
    ev.push({ type: 'khayes', seat: s.turn });
    endMatch(s, (1 - loser) as 0 | 1, 'khayes', ev);
  }
}

function resolveIfDecided(s: MatchState, ev: GameEvent[]): boolean {
  const bt = teamOf(s.bidder!);
  const need = tricksNeeded(s.bid!);
  const got = s.tricksWon[bt];
  const lost = s.tricksWon[1 - bt];
  const made = got >= need;
  const failed = lost > TRICKS_PER_HAND - need;
  if (!made && !failed) return false;

  if (s.bid === INZELI) {
    s.lastHand = { bidder: s.bidder!, bid: s.bid, bidderTeamTricks: got, made, points: 0,
      toTeam: made ? bt : ((1 - bt) as 0 | 1) };
    ev.push({ type: 'handOver', result: s.lastHand });
    endMatch(s, made ? bt : ((1 - bt) as 0 | 1), made ? 'inzeli' : 'inzeliFailed', ev);
    return true;
  }
  const points = made ? s.bid! : s.bid! * 2;
  const toTeam = (made ? bt : 1 - bt) as 0 | 1;
  s.score += toTeam === 0 ? points : -points;
  s.lastHand = { bidder: s.bidder!, bid: s.bid!, bidderTeamTricks: got, made, points, toTeam };
  ev.push({ type: 'handOver', result: s.lastHand });
  if (Math.abs(s.score) >= WIN_SCORE) {
    endMatch(s, s.score > 0 ? 0 : 1, 'points', ev);
  } else {
    s.phase = 'handOver';
  }
  return true;
}

function endMatch(s: MatchState, winner: 0 | 1, reason: WinReason, ev: GameEvent[]) {
  s.phase = 'matchOver';
  s.winner = winner;
  s.winReason = reason;
  ev.push({ type: 'matchOver', winner, reason });
}

/** The state a given seat is allowed to see (other hands hidden as counts). */
export function viewFor(s: MatchState, seat: number): MatchState & { handCounts: number[] } {
  const v = structuredClone(s) as MatchState & { handCounts: number[] };
  v.handCounts = s.hands.map(h => h.length);
  v.hands = s.hands.map((h, i) => (i === seat || s.phase === 'matchOver' ? h : []));
  return v;
}

// ---------- storage ----------
// Firestore cannot store an array inside an array, so hands are stored as { "0": [...], "1": [...] }.

export type StoredState<T extends { hands: Card[][] }> = Omit<T, 'hands'> & { hands: Record<string, Card[]> };

export function packState<T extends { hands: Card[][] }>(s: T): StoredState<T> {
  return { ...s, hands: Object.fromEntries(s.hands.map((h, i) => [String(i), h])) };
}

export function unpackState<T extends { hands: Card[][] }>(s: StoredState<T>, players: number): T {
  const hands: Card[][] = Array.from({ length: players }, (_, i) => s.hands?.[String(i)] ?? []);
  return { ...(s as any), hands } as T;
}

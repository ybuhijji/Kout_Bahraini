import { describe, it, expect } from 'vitest';
import {
  apply, buildDeck, legalBids, legalCards, mulberry32, newMatch, trickWinner, JOKER, INZELI,
  drawForDealer, nextDealer, rankOf,
  MatchState, RuleError, teamOf,
} from './engine';
import { chooseAction } from './bot';

describe('decks', () => {
  it('bu 4 has 32 cards: Joker, 7-A in S/H/C, 8-A in D', () => {
    const d = buildDeck(4);
    expect(d.length).toBe(32);
    expect(new Set(d).size).toBe(32);
    expect(d).toContain('7S'); expect(d).toContain('7H'); expect(d).toContain('7C');
    expect(d).not.toContain('7D'); expect(d).toContain('8D'); expect(d).toContain(JOKER);
    expect(d).not.toContain('6S');
  });
  it('bu 6 has 48 cards: Joker, 3-A in S/H/C, 4-A in D', () => {
    const d = buildDeck(6);
    expect(d.length).toBe(48);
    expect(new Set(d).size).toBe(48);
    expect(d).toContain('3S'); expect(d).not.toContain('3D'); expect(d).toContain('4D');
    expect(d).not.toContain('2S'); expect(d).not.toContain('2D');
  });
});

describe('trick winner', () => {
  it('Joker beats the trump Ace', () => {
    expect(trickWinner([{ seat: 0, card: 'AS' }, { seat: 1, card: JOKER }], 'S').seat).toBe(1);
  });
  it('trump beats led suit, off-suit loses', () => {
    const t = [{ seat: 0, card: 'AH' }, { seat: 1, card: '7S' }, { seat: 2, card: 'KD' }, { seat: 3, card: 'KH' }];
    expect(trickWinner(t, 'S').seat).toBe(1);
    expect(trickWinner(t, 'C').seat).toBe(0);
  });
});

function fixed(hands: string[][], over: Partial<MatchState> = {}): MatchState {
  const s = newMatch(4, mulberry32(1));
  s.hands = hands;
  Object.assign(s, over);
  return s;
}

describe('dealer', () => {
  it('opening draw: lowest card deals, the Joker counts as lowest, ties draw again', () => {
    let sawTie = false, sawJoker = false;
    for (let g = 0; g < 400; g++) {
      const { dealer, draws } = drawForDealer(g % 2 ? 4 : 6, mulberry32(g));
      const last = Math.max(...draws.map(d => d.round));
      const final = draws.filter(d => d.round === last);
      const val = (c: string) => (c === JOKER ? 0 : rankOf(c));
      const low = Math.min(...final.map(d => val(d.card)));
      expect(final.filter(d => val(d.card) === low).map(d => d.seat)).toEqual([dealer]);
      if (last > 0) sawTie = true;
      if (draws.some(d => d.card === JOKER && d.seat === dealer)) sawJoker = true;
      expect(new Set(draws.map(d => d.card)).size).toBe(draws.length);   // no card drawn twice
    }
    expect(sawTie).toBe(true); expect(sawJoker).toBe(true);
  });
  it('a new match starts with the drawn dealer; the player on the dealer right bids first', () => {
    const s = newMatch(4, mulberry32(11));
    expect(s.dealerDraw.length).toBeGreaterThanOrEqual(4);
    expect(s.bidTurn).toBe((s.dealer + 1) % 4);
  });
  it('the deal moves anticlockwise only when the dealer team is ahead', () => {
    const s = newMatch(4, mulberry32(5), 0);       // dealer seat 0, team 0
    s.score = 5;  expect(nextDealer(s)).toBe(1);    // dealer team ahead: passes on
    s.score = 0;  expect(nextDealer(s)).toBe(0);    // level: same dealer
    s.score = -7; expect(nextDealer(s)).toBe(0);    // behind: same dealer
    s.dealer = 1; s.score = -7; expect(nextDealer(s)).toBe(2);   // seat 1 is team 1, ahead
  });
  it('after a hand and after an all-pass redeal, the rule is applied', () => {
    const s = newMatch(4, mulberry32(9), 2);        // dealer 2 (team 0), level score
    for (const seat of [3, 0, 1, 2]) apply(s, { type: 'pass', seat }, mulberry32(1));
    expect(s.dealer).toBe(2);                         // all passed, level: same dealer reshuffles
    s.phase = 'handOver'; s.score = 5;
    apply(s, { type: 'nextHand' }, mulberry32(2));
    expect(s.dealer).toBe(3);
  });
});

describe('bidding', () => {
  it('Inzeli not allowed in the first hand, and only for the Joker holder', () => {
    const s = newMatch(4, mulberry32(3));
    const holder = s.hands.findIndex(h => h.includes(JOKER));
    s.bidTurn = holder;
    expect(legalBids(s, holder)).not.toContain(INZELI);
    s.handNo = 1;
    expect(legalBids(s, holder)).toContain(INZELI);
    const other = (holder + 1) % 4;
    s.bidTurn = other;
    expect(legalBids(s, other)).not.toContain(INZELI);
  });
  it('player on bidder right leads, bids must rise, all pass redeals', () => {
    const s = newMatch(4, mulberry32(5), 0);
    expect(s.bidTurn).toBe(1);
    apply(s, { type: 'bid', seat: 1, bid: 5 }, mulberry32(1));
    expect(() => apply(s, { type: 'bid', seat: 2, bid: 5 }, mulberry32(1))).toThrow(RuleError);
    apply(s, { type: 'pass', seat: 2 }, mulberry32(1));
    apply(s, { type: 'pass', seat: 3 }, mulberry32(1));
    apply(s, { type: 'pass', seat: 0 }, mulberry32(1));
    expect(s.phase).toBe('trump');
    apply(s, { type: 'trump', seat: 1, suit: 'H' }, mulberry32(1));
    expect(s.turn).toBe(2);

    const r = newMatch(4, mulberry32(9), 0);
    for (const seat of [1, 2, 3, 0]) apply(r, { type: 'pass', seat }, mulberry32(1));
    expect(r.phase).toBe('bidding');
    expect(r.dealer).toBe(0);
    expect(r.bidTurn).toBe(1);
  });
});

describe('play rules', () => {
  it('cannot lead the Joker; must follow suit but may play Joker', () => {
    const s = fixed([[JOKER, 'AS', '7H'], ['8S', '9H', 'KC'], [], []],
      { phase: 'playing', trump: 'C', turn: 0, bidder: 3, bid: 5 });
    expect(legalCards(s, 0)).not.toContain(JOKER);
    s.trick = [{ seat: 3, card: '10S' }];
    expect(legalCards(s, 0).sort()).toEqual(['AS', JOKER].sort());
    expect(legalCards({ ...s, turn: 1 } as MatchState, 1)).toEqual(['8S']);
  });
  it('leading with only the Joker left loses the game (khayes)', () => {
    const s = fixed([[JOKER], ['8S'], ['9S'], ['7S']],
      { phase: 'playing', trump: 'C', turn: 3, bidder: 1, bid: 5, tricksWon: [3, 4] });
    s.trick = [];
    // seat 3 leads 7S; seat 0 must... has only Joker -> plays it and wins; then must lead nothing (hand ends)
    // Construct the real khayes: seat 0 wins a trick then has only the Joker.
    const k = fixed([[JOKER, 'AS'], ['8S', '8H'], ['9S', '9H'], ['7S', '7H']],
      { phase: 'playing', trump: 'C', turn: 1, bidder: 1, bid: 7, tricksWon: [0, 6] });
    apply(k, { type: 'play', seat: 1, card: '8S' }, mulberry32(1));
    apply(k, { type: 'play', seat: 2, card: '9S' }, mulberry32(1));
    apply(k, { type: 'play', seat: 3, card: '7S' }, mulberry32(1));
    apply(k, { type: 'play', seat: 0, card: 'AS' }, mulberry32(1));
    expect(k.phase).toBe('matchOver');
    expect(k.winReason).toBe('khayes');
    expect(k.winner).toBe(1);
    expect(s.phase).toBe('playing');
  });
});

describe('inzeli opening lead', () => {
  it('player on the caller right must lead trump when holding one', () => {
    const s = fixed([['AS', JOKER], ['7H', 'KS', '9C'], [], []],
      { phase: 'playing', trump: 'H', turn: 1, bidder: 0, bid: INZELI });
    expect(legalCards(s, 1)).toEqual(['7H']);
  });
  it('no trump in hand: any card except the Joker', () => {
    const s = fixed([['AS'], ['KS', '9C', JOKER], [], []],
      { phase: 'playing', trump: 'H', turn: 1, bidder: 0, bid: INZELI });
    expect(legalCards(s, 1).sort()).toEqual(['9C', 'KS']);
  });
  it('only applies to the first lead, and not to normal bids', () => {
    const s = fixed([['AS'], ['7H', 'KS'], [], []],
      { phase: 'playing', trump: 'H', turn: 1, bidder: 0, bid: INZELI, played: ['8D', '9D', '10D', 'JD'] });
    expect(legalCards(s, 1).sort()).toEqual(['7H', 'KS']);
    const n = fixed([['AS'], ['7H', 'KS'], [], []],
      { phase: 'playing', trump: 'H', turn: 1, bidder: 0, bid: 7 });
    expect(legalCards(n, 1).sort()).toEqual(['7H', 'KS']);
  });
});

describe('scoring', () => {
  it('made bid scores the bid, failed costs double, single running score', () => {
    const s = fixed([['AS'], ['KS'], ['QS'], ['JS']],
      { phase: 'playing', trump: 'S', turn: 0, bidder: 0, bid: 5, tricksWon: [4, 3] });
    for (const [seat, card] of [[0, 'AS'], [1, 'KS'], [2, 'QS'], [3, 'JS']] as const) apply(s, { type: 'play', seat, card }, mulberry32(1));
    expect(s.score).toBe(5);
    // Next: team 0 bids 5 and fails -> -10, score becomes 5 to team 1
    const t = fixed([['7S'], ['KS'], ['QS'], ['JS']],
      { phase: 'playing', trump: 'S', turn: 0, bidder: 0, bid: 5, tricksWon: [4, 3], score: 5 });
    for (const [seat, card] of [[0, '7S'], [1, 'KS'], [2, 'QS'], [3, 'JS']] as const) apply(t, { type: 'play', seat, card }, mulberry32(1));
    expect(t.score).toBe(-5);
  });
  it('reaching 31 wins the match', () => {
    const s = fixed([['AS'], ['KS'], ['QS'], ['JS']],
      { phase: 'playing', trump: 'S', turn: 0, bidder: 0, bid: 7, tricksWon: [6, 1], score: 25 });
    for (const [seat, card] of [[0, 'AS'], [1, 'KS'], [2, 'QS'], [3, 'JS']] as const) apply(s, { type: 'play', seat, card }, mulberry32(1));
    expect(s.phase).toBe('matchOver');
    expect(s.winner).toBe(0);
  });
  it('failed Inzeli gives the game to the other team', () => {
    const s = fixed([['7S', 'AH'], ['KS', '8H'], ['QS', '9H'], ['JS', '10H']],
      { phase: 'playing', trump: 'H', turn: 0, bidder: 0, bid: INZELI, tricksWon: [6, 0] });
    for (const [seat, card] of [[0, '7S'], [1, 'KS'], [2, 'QS'], [3, 'JS']] as const) apply(s, { type: 'play', seat, card }, mulberry32(1));
    expect(s.winner).toBe(1);
    expect(s.winReason).toBe('inzeliFailed');
  });
});

describe('bot simulation', () => {
  for (const variant of [4, 6] as const) {
    it(`plays 300 full bu ${variant} matches without rule errors`, () => {
      const reasons: Record<string, number> = {};
      let hands = 0;
      for (let g = 0; g < 300; g++) {
        const rng = mulberry32(1000 + g);
        const s = newMatch(variant, rng);
        let steps = 0;
        while (s.phase !== 'matchOver' && steps++ < 20000) {
          if (s.phase === 'handOver') { hands++; apply(s, { type: 'nextHand' }, rng); continue; }
          const seat = s.phase === 'bidding' ? s.bidTurn : s.phase === 'trump' ? s.bidder! : s.turn;
          apply(s, chooseAction(s, seat, 'normal', rng), rng);
        }
        expect(s.phase).toBe('matchOver');
        expect(s.winner === 0 || s.winner === 1).toBe(true);
        reasons[s.winReason!] = (reasons[s.winReason!] ?? 0) + 1;
        if (s.winReason === 'points') expect(Math.abs(s.score)).toBeGreaterThanOrEqual(31);
        expect(teamOf(0)).toBe(0);
      }
      console.log(`bu ${variant}`, reasons, 'avg hands/match', (hands / 300).toFixed(1));
    });
  }
});

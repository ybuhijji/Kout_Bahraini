// Heuristic bot for Bahraini Kout. Sees only its own hand and public information.
import {
  Action, BidValue, Card, INZELI, JOKER, MatchState, Suit, SUITS,
  legalBids, legalCards, rankOf, suitOf, teamOf, trickWinner,
} from './engine';

export type BotLevel = 'easy' | 'normal' | 'hard';

/** Estimated tricks this hand can win with `trump` as trump (own hand only). */
function handStrength(hand: Card[], trump: Suit): number {
  let est = 0;
  if (hand.includes(JOKER)) est += 1;
  const trumps = hand.filter(c => suitOf(c) === trump).map(rankOf).sort((a, b) => b - a);
  trumps.forEach((r, i) => {
    if (r === 14) est += 0.95;
    else if (r === 13) est += trumps.length >= 2 ? 0.8 : 0.4;
    else if (r === 12) est += trumps.length >= 3 ? 0.6 : 0.2;
    else if (i >= 3) est += 0.6; // long trumps take ruffs
    else est += 0.15;
  });
  for (const s of SUITS) {
    if (s === trump) continue;
    const side = hand.filter(c => suitOf(c) === s).map(rankOf).sort((a, b) => b - a);
    if (side[0] === 14) est += 0.85;
    if (side[0] === 13 && side.length >= 2) est += 0.35;
    if (side[0] === 14 && side[1] === 13) est += 0.5;
    if (side.length === 0 && trumps.length >= 3) est += 0.35; // void: can ruff
  }
  return est;
}

export function bestTrump(hand: Card[]): { suit: Suit; strength: number } {
  let best = { suit: 'S' as Suit, strength: -1 };
  for (const s of SUITS) {
    const v = handStrength(hand, s);
    if (v > best.strength) best = { suit: s, strength: v };
  }
  return best;
}

export function chooseAction(s: MatchState, seat: number, level: BotLevel = 'normal', rng = Math.random): Action {
  if (s.phase === 'bidding') return chooseBid(s, seat, level, rng);
  if (s.phase === 'trump') return { type: 'trump', seat, suit: bestTrump(s.hands[seat]).suit };
  return { type: 'play', seat, card: chooseCard(s, seat, level, rng) };
}

function chooseBid(s: MatchState, seat: number, level: BotLevel, rng: () => number): Action {
  const legal = legalBids(s, seat);
  const { strength } = bestTrump(s.hands[seat]);
  // Expected tricks from partners (tuned by self-play simulation).
  const partnerValue = s.variant === 4 ? 2.0 : 2.3;
  let est = strength + partnerValue + (level === 'easy' ? (rng() - 0.5) * 1.5 : 0);
  if (level === 'hard') est += 0.2;
  if (legal.includes(INZELI) && strength >= 7.4) return { type: 'bid', seat, bid: INZELI };
  const target = Math.floor(est) as number;
  const options = legal.filter(b => b !== INZELI && b <= target) as BidValue[];
  // Bid the cheapest bid that wins the auction, not the maximum.
  if (options.length > 0) return { type: 'bid', seat, bid: options[0] };
  return { type: 'pass', seat };
}

function lowest(cards: Card[], trump: Suit): Card {
  // Prefer discarding low non-trumps; never waste the Joker.
  const pool = cards.filter(c => c !== JOKER);
  const nonTrump = pool.filter(c => suitOf(c) !== trump);
  const from = nonTrump.length ? nonTrump : pool.length ? pool : cards;
  return from.reduce((a, b) => (rankOf(b) < rankOf(a) ? b : a));
}

function isMaster(card: Card, s: MatchState, hand: Card[]): boolean {
  // Is this the highest unplayed card of its suit (ignoring the Joker)?
  const su = suitOf(card);
  const r = rankOf(card);
  const seen = new Set([...s.played, ...hand]);
  for (let higher = r + 1; higher <= 14; higher++) {
    const name = ({ 11: 'J', 12: 'Q', 13: 'K', 14: 'A' } as Record<number, string>)[higher] ?? String(higher);
    const c = name + su;
    if (!seen.has(c) && deckHas(s, c)) return false;
  }
  return true;
}

function deckHas(s: MatchState, c: Card): boolean {
  const r = rankOf(c);
  const low = s.variant === 4 ? 7 : 3;
  return r >= (suitOf(c) === 'D' ? low + 1 : low);
}

function chooseCard(s: MatchState, seat: number, level: BotLevel, rng: () => number): Card {
  const legal = legalCards(s, seat);
  if (legal.length === 1) return legal[0];
  if (level === 'easy' && rng() < 0.3) return legal[Math.floor(rng() * legal.length)];
  const hand = s.hands[seat];
  const trump = s.trump!;
  const myTeam = teamOf(seat);
  const hasJoker = hand.includes(JOKER);

  // Joker safety: never get stuck leading it as the last card (خيس).
  if (hasJoker && s.trick.length > 0 && hand.length <= 3) return JOKER;

  if (s.trick.length === 0) {
    const nonJ = legal;
    // Holding the Joker late: lead low so someone else takes the lead and we can dump it.
    if (hasJoker && hand.length <= 3) return lowest(nonJ, trump);
    const myTrumps = nonJ.filter(c => suitOf(c) === trump);
    const weAreBidders = teamOf(s.bidder!) === myTeam;
    // Pull trumps when we own the contract and hold the master trump.
    if (weAreBidders && myTrumps.length > 0) {
      const top = myTrumps.reduce((a, b) => (rankOf(b) > rankOf(a) ? b : a));
      if (isMaster(top, s, hand) && (level !== 'easy')) return top;
    }
    // Cash a master side card.
    const masters = nonJ.filter(c => suitOf(c) !== trump && isMaster(c, s, hand));
    if (masters.length) return masters[0];
    // Otherwise lead low from the longest side suit.
    const bySuit = new Map<Suit, Card[]>();
    for (const c of nonJ) {
      const su = suitOf(c)!;
      if (su === trump && nonJ.some(x => suitOf(x) !== trump)) continue;
      bySuit.set(su, [...(bySuit.get(su) ?? []), c]);
    }
    const longest = [...bySuit.values()].sort((a, b) => b.length - a.length)[0];
    return longest.reduce((a, b) => (rankOf(b) < rankOf(a) ? b : a));
  }

  const current = trickWinner(s.trick, trump);
  const partnerWinning = teamOf(current.seat) === myTeam;
  const isLast = s.trick.length === s.players - 1;
  const winners = legal.filter(c => trickWinner([...s.trick, { seat, card: c }], trump).seat === seat);

  if (partnerWinning) {
    const safe = current.card === JOKER || isMaster(current.card, s, hand) || isLast;
    if (safe) return lowest(legal, trump);
  }
  if (winners.length) {
    // Win as cheaply as possible; keep the Joker unless it is the only winner.
    const nonJ = winners.filter(c => c !== JOKER);
    const pool = nonJ.length ? nonJ : winners;
    if (!isLast && !partnerWinning) {
      // Not last to play: prefer a card that cannot be beaten.
      const strong = pool.filter(c => isMaster(c, s, hand) || suitOf(c) === trump);
      if (strong.length) return strong.reduce((a, b) => (rankOf(b) < rankOf(a) ? b : a));
    }
    if (partnerWinning) return lowest(legal, trump);
    return pool.reduce((a, b) => (rankOf(b) < rankOf(a) ? b : a));
  }
  return lowest(legal, trump);
}

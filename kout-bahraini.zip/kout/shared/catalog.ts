// Store catalog, sound slots and table themes. Shared by the app and the server
// so prices are validated server side.

export type ItemKind = 'accessory' | 'theme' | 'cardback' | 'soundpack';

export interface StoreItem {
  id: string;
  kind: ItemKind;
  name: string;      // Arabic display name
  price: number;     // in coins (بيزات)
  emoji: string;     // fallback icon until real artwork is dropped in public/items/<id>.png
  rarity?: 'common' | 'rare' | 'legendary';
}

export const CATALOG: StoreItem[] = [
  // Accessories shown on the player's seat
  { id: 'misbah_wood', kind: 'accessory', name: 'مسباح خشب', price: 150, emoji: '📿' },
  { id: 'misbah_kahraman', kind: 'accessory', name: 'مسباح كهرمان', price: 900, emoji: '📿', rarity: 'rare' },
  { id: 'misbah_yusr', kind: 'accessory', name: 'مسباح يُسر', price: 2500, emoji: '📿', rarity: 'legendary' },
  { id: 'phone', kind: 'accessory', name: 'تيلفون آخر موديل', price: 1200, emoji: '📱', rarity: 'rare' },
  { id: 'dallah', kind: 'accessory', name: 'دلة قهوة', price: 300, emoji: '☕' },
  { id: 'karak', kind: 'accessory', name: 'استكانة كرك', price: 100, emoji: '🍵' },
  { id: 'ghutra', kind: 'accessory', name: 'غترة وعقال', price: 400, emoji: '👳' },
  { id: 'bisht', kind: 'accessory', name: 'بشت', price: 2000, emoji: '🧥', rarity: 'legendary' },
  { id: 'watch', kind: 'accessory', name: 'ساعة فخمة', price: 1500, emoji: '⌚', rarity: 'rare' },
  { id: 'landcruiser', kind: 'accessory', name: 'مفتاح لاندكروزر', price: 5000, emoji: '🚙', rarity: 'legendary' },
  { id: 'pearl', kind: 'accessory', name: 'لؤلؤة بحرانية', price: 3000, emoji: '🦪', rarity: 'legendary' },
  { id: 'dhow', kind: 'accessory', name: 'محمل', price: 800, emoji: '⛵', rarity: 'rare' },
  // Table themes
  { id: 'theme_muharraq', kind: 'theme', name: 'طاولة المحرق', price: 1000, emoji: '🔴', rarity: 'rare' },
  { id: 'theme_riffa', kind: 'theme', name: 'طاولة الرفاع', price: 1000, emoji: '🔵', rarity: 'rare' },
  { id: 'theme_sadu', kind: 'theme', name: 'طاولة السدو', price: 600, emoji: '🟫' },
  { id: 'theme_pearl', kind: 'theme', name: 'طاولة الغوص', price: 600, emoji: '🌊' },
  // Card backs
  { id: 'back_palm', kind: 'cardback', name: 'ظهر ورق: نخلة', price: 250, emoji: '🌴' },
  { id: 'back_flag', kind: 'cardback', name: 'ظهر ورق: أحمر وأبيض', price: 250, emoji: '🇧🇭' },
  // Sound packs (unlock extra reaction sounds)
  { id: 'pack_memes', kind: 'soundpack', name: 'باقة الميمز البحرينية', price: 1500, emoji: '🔊', rarity: 'rare' },
];

export const ITEM_BY_ID = Object.fromEntries(CATALOG.map(i => [i.id, i]));

/** Coin packs sold through Google Play Billing. Product IDs must match Play Console. */
export const COIN_PACKS = [
  { productId: 'coins_500', coins: 500, label: '500 بيزة' },
  { productId: 'coins_1200', coins: 1200, label: '1,200 بيزة' },
  { productId: 'coins_3000', coins: 3000, label: '3,000 بيزة' },
  { productId: 'coins_8000', coins: 8000, label: '8,000 بيزة' },
];

export const STARTING_COINS = 500;
export const COINS_WIN = 60;
export const COINS_LOSS = 15;

// ---------- sound slots ----------
// Drop licensed clips into public/sounds/<id>.mp3. Missing files fall back to a built-in tone.

export interface SoundSlot {
  id: string;
  label: string;
  auto?: 'matchWin' | 'matchLose' | 'handMade' | 'handFailed' | 'khayes' | 'inzeliCall' | 'inzeliMade' | 'myTurn' | 'kout';
  reaction?: boolean;       // player can trigger it from the reactions menu
  pack?: string;            // store item that unlocks it (undefined = free)
}

export const SOUND_SLOTS: SoundSlot[] = [
  { id: 'kout', label: 'كوت!', auto: 'kout' },
  { id: 'match_win', label: 'فوز', auto: 'matchWin' },
  { id: 'match_lose', label: 'خسارة', auto: 'matchLose' },
  { id: 'hand_made', label: 'ربحنا الطلبة', auto: 'handMade' },
  { id: 'hand_failed', label: 'طاحت الطلبة', auto: 'handFailed' },
  { id: 'khayes', label: 'خيس الجوكر', auto: 'khayes' },
  { id: 'inzeli_call', label: 'انزلي', auto: 'inzeliCall' },
  { id: 'inzeli_made', label: 'انزلي ناجحة', auto: 'inzeliMade' },
  { id: 'turn', label: 'دورك', auto: 'myTurn' },
  // Reactions (free)
  { id: 'r_yalla', label: 'يلا العب!', reaction: true },
  { id: 'r_clap', label: 'تصفيق', reaction: true },
  { id: 'r_laugh', label: 'ضحك', reaction: true },
  { id: 'r_wow', label: 'ما شاء الله', reaction: true },
  // Voice reactions from the clips Yusuf supplied (public/sounds/voice_N.mp3), unlocked by the meme pack.
  { id: 'voice_1', label: 'عبدالنبي', reaction: true, pack: 'pack_memes' },
  { id: 'voice_2', label: 'شتبي انت؟', reaction: true, pack: 'pack_memes' },
  { id: 'voice_3', label: 'اييلس مكانك', reaction: true, pack: 'pack_memes' },
  { id: 'voice_4', label: 'كوتوونا', reaction: true, pack: 'pack_memes' },
  { id: 'voice_5', label: 'احترم الناس', reaction: true, pack: 'pack_memes' },
  { id: 'voice_6', label: 'الشرهه على الي يابك', reaction: true, pack: 'pack_memes' },
  { id: 'voice_7', label: 'كنت بوزاار تدور', reaction: true, pack: 'pack_memes' },
  { id: 'voice_8', label: 'راح منك ياحسين', reaction: true, pack: 'pack_memes' },
  { id: 'voice_9', label: 'ضربه منتب', reaction: true, pack: 'pack_memes' },
];

// ---------- themes ----------

export interface Theme {
  id: string;
  name: string;
  item?: string;          // store item required (undefined = free)
  felt: string;           // table colour
  felt2: string;          // pattern / edge colour
  accent: string;
  rim: string;
  crest?: string;         // optional image in public/themes/<id>/crest.png (requires club permission)
}

export const THEMES: Theme[] = [
  { id: 'classic', name: 'الكلاسيكية', felt: '#0f5132', felt2: '#0a3d26', accent: '#e8c46b', rim: '#5a3a1a' },
  { id: 'muharraq', name: 'المحرق', item: 'theme_muharraq', felt: '#a50d1f', felt2: '#7a0816', accent: '#ffffff', rim: '#f2f2f2', crest: 'themes/muharraq/crest.png' },
  { id: 'riffa', name: 'الرفاع', item: 'theme_riffa', felt: '#0b4fa3', felt2: '#073a7a', accent: '#ffffff', rim: '#f2f2f2', crest: 'themes/riffa/crest.png' },
  { id: 'sadu', name: 'السدو', item: 'theme_sadu', felt: '#6b1f1f', felt2: '#3d1414', accent: '#f0d9a8', rim: '#2b1a10' },
  { id: 'pearl', name: 'الغوص', item: 'theme_pearl', felt: '#0d5c6b', felt2: '#08404b', accent: '#f5efe1', rim: '#c9b28a' },
];

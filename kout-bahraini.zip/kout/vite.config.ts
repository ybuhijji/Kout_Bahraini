import { defineConfig } from 'vite';

export default defineConfig({
  base: './',
  build: { outDir: 'dist', target: 'es2020', chunkSizeWarningLimit: 1500 },
  server: { host: true, port: 5173 },
  test: { include: ['shared/**/*.test.ts', 'src/**/*.test.ts'] },
} as any);

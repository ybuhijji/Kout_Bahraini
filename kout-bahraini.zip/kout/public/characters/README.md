# Characters

Profile pictures sold in the store (tab "شخصيات"). Each character has two files:

- `<id>.webp`: 256px square face crop, used in round avatars (table, room, profile, majlis).
- `<id>_full.webp`: 512px full scene, used on the store card.

The ids, Arabic names and prices are in `shared/catalog.ts` (kind `character`). To add one: add a line there, then drop the two files here. Bots in offline and online games wear random characters, so players see them in play.

Before release: the Muharraq, Riffa and Al Ahli shirts show club badges, and the singer's poster names a real singer. Get permission from the clubs and the singer's family, or edit those details out of the images.

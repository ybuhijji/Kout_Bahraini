# Sound clips

Put licensed clips here as `.mp3`, named exactly by slot ID. Any slot without a file plays a short built-in tone, so the game works before clips are added.

Keep each clip short (under 3 seconds for reactions, under 5 for win/lose) and normalized to the same loudness.

## Card sounds

`card_slide.wav` (the swish as you throw a card) and `card_place.wav` (a card landing on the table) are made by `scripts/make-card-sounds.py`, modelled from noise so they are original and free to use. To use real recordings instead, replace these two files with WAV files of the same names.

## Played automatically

| File | When it plays |
|---|---|
| `kout.mp3` | Your team wins the game (the "كوت!" moment) |
| `match_win.mp3` | Plays right after `kout.mp3` |
| `match_lose.mp3` | Your team loses the game |
| `hand_made.mp3` | A hand goes your team's way |
| `hand_failed.mp3` | A hand goes against your team |
| `khayes.mp3` | Someone is forced to lead the Joker (خيس الجوكر) |
| `inzeli_call.mp3` | Someone calls انزلي |
| `inzeli_made.mp3` | An انزلي succeeds |
| `turn.mp3` | It is your turn |

## Reactions (players trigger these from the 🔊 button)

Free:

| File | Label in the app |
|---|---|
| `r_yalla.mp3` | يلا العب! |
| `r_clap.mp3` | تصفيق |
| `r_laugh.mp3` | ضحك |
| `r_wow.mp3` | ما شاء الله |

Unlocked by the "باقة الميمز البحرينية" store item:

| File | Label in the app |
|---|---|
| `m_yaaah.mp3` | ياااااه |
| `m_scream.mp3` | الصرخة |
| `m_taekwondo.mp3` | حركة التكواندو |
| `m_tagdar.mp3` | تقدر.. واهوه فيها |
| `m_abdulnabi.mp3` | عبدالنبي |
| `m_harab.mp3` | هرب منك يا حسين |

To add more meme slots, add a line to `SOUND_SLOTS` in `shared/catalog.ts` and drop the matching file here.

## Permission

These clips use real people's voices. Before release, get written permission from each person (or whoever owns the clip) for use in a paid app. Keep the permission emails/letters. Google Play removes apps on a rights complaint, and repeated removals can close the developer account.

# Club table crests

The Muharraq and Riffa tables already use club colours. To show the official crest faintly in the middle of the table, add:

- `muharraq/crest.png`
- `riffa/crest.png`

Use a transparent PNG about 400×400 px. The app shows it at low opacity behind the cards.

Club names and crests are trademarks. Get written approval from each club before release (the clubs may also want a share of what the table sells for, which is common). Until then, leave the crest files out: the tables still work with colours only.

To add another club, add a theme to `THEMES` and a matching store item to `CATALOG` in `shared/catalog.ts`.

## Store item artwork

Store items show an emoji until you add artwork at `public/items/<item id>.png` (for example `public/items/misbah_kahraman.png`). Square PNG, about 256×256, transparent background.

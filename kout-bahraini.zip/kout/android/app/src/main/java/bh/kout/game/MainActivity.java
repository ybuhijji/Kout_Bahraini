package bh.kout.game;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}

// End-to-end test of the online server code against in-memory Firestore.
// Run: npm run build && node test/online.test.js
globalThis.__fakeGoogle = {
  auth: { getClient: async () => ({}) },
  androidpublisher: () => ({ purchases: { products: { get: async ({ token }) => ({ data: token.startsWith('bad') ? { purchaseState: 1 } : { purchaseState: 0, orderId: 'GPA.' + token } }) } } }),
};
const { store, Timestamp, deletedUsers } = require('./fakes');
const assert = require('assert/strict');
const fns = require('../lib/index.js');
require('../lib/util').sleep = async () => {};
const { chooseAction } = require('../lib/shared/bot');
const { JOKER } = require('../lib/shared/engine');

const req = (uid, data = {}, provider = 'google.com', verified = false) =>
  ({ auth: { uid, token: { firebase: { sign_in_provider: provider }, email_verified: verified, name: 'User ' + uid } }, data });
const call = (fn, uid, data, ...rest) => fns[fn](req(uid, data, ...rest));
const doc = p => store.get(p);
const rejects = async (p, re) => { try { await p; } catch (e) { assert.match(e.details?.ar ?? e.message, re); return; } assert.fail('expected rejection ' + re); };
let passed = 0;
const ok = msg => { passed++; console.log('  ✓', msg); };

function actor(v) { return v.phase === 'bidding' ? v.bidTurn : v.phase === 'trump' ? v.bidder : v.phase === 'playing' ? v.turn : null; }

async function playOut(roomId, uids, { checkHidden = true } = {}) {
  let moves = 0;
  for (let i = 0; i < 5000; i++) {
    if (doc(`rooms/${roomId}`).status === 'done') return moves;
    let acted = false;
    for (const uid of uids) {
      const vd = doc(`games/${roomId}/views/${uid}`);
      const v = vd.view;
      if (checkHidden && v.phase !== 'matchOver') {
        v.hands.forEach((h, s) => { if (s !== vd.mySeat) assert.equal(h.length, 0, 'other hands must be hidden'); });
      }
      if (actor(v) === vd.mySeat) {
        await call('gameAction', uid, { roomId, action: chooseAction(v, vd.mySeat, 'normal') });
        moves++; acted = true; break;
      }
    }
    if (!acted) throw new Error('nobody can act; phase ' + doc(`games/${roomId}/secret/state`).state.phase);
  }
  throw new Error('match did not finish');
}

(async () => {
  console.log('profiles & auth');
  await call('ensureProfile', 'A', { name: 'يوسف' });
  await call('ensureProfile', 'B', { name: 'جاسم' });
  await call('ensureProfile', 'D', { name: 'علي' });
  assert.equal(doc('users/A').coins, 500); ok('new profile gets 500 coins');
  await rejects(call('ensureProfile', 'C', {}, 'password', false), /تأكد إيميلك/); ok('unverified email account is blocked');
  await call('ensureProfile', 'C', {}, 'password', true); ok('verified email account allowed');
  await call('updateProfile', 'A', { avatar: '🦅' });
  await rejects(call('updateProfile', 'A', { avatar: '<script>' }), /صورة/); ok('profile update validates avatar');

  console.log('private room with friends');
  const { roomId, code } = await call('createRoom', 'A', { variant: 4 });
  await call('joinRoom', 'B', { code: code.toLowerCase() });
  const room = doc(`rooms/${roomId}`);
  assert.deepEqual(room.uids, ['A', 'B']);
  assert.notEqual(room.seats.findIndex(s => s?.uid === 'A') % 2, room.seats.findIndex(s => s?.uid === 'B') % 2); ok('join by code, friends seated on alternating teams');
  await rejects(call('startRoom', 'B', { roomId }), /صاحب الغرفة/); ok('only host can start');
  await call('startRoom', 'A', { roomId });
  const sec = doc(`games/${roomId}/secret/state`);
  assert.equal(sec.seats.filter(s => s.bot).length, 2); ok('empty seats filled with bots');
  assert.equal(doc(`rooms/${roomId}`).status, 'playing');
  const vA = doc(`games/${roomId}/views/A`);
  assert.equal(vA.view.hands[vA.mySeat].length, 8); ok('player sees own 8 cards only');

  // illegal move
  const v0 = doc(`games/${roomId}/views/A`);
  if (actor(v0.view) !== v0.mySeat) await rejects(call('gameAction', 'A', { roomId, action: { type: 'pass', seat: v0.mySeat } }), /مو دورك|مسموحة/);
  else await rejects(call('gameAction', 'A', { roomId, action: { type: 'pass', seat: (v0.mySeat + 1) % 4 } }), /مو دورك/);
  ok('out-of-turn action rejected');
  await rejects(call('gameAction', 'D', { roomId, action: { type: 'pass', seat: 0 } }), /مو لاعب/); ok('outsider cannot act');

  const moves = await playOut(roomId, ['A', 'B']);
  const fin = doc(`games/${roomId}/secret/state`);
  assert.equal(fin.finished, true); assert.equal(fin.rewarded, true);
  ok(`full online bu 4 match finished (${moves} human moves, ${fin.step} steps, winner team ${fin.state.winner}, ${fin.state.winReason})`);
  const seatA = fin.seats.findIndex(s => s.uid === 'A');
  const aWon = seatA % 2 === fin.state.winner;
  assert.equal(doc('users/A').coins, 500 + (aWon ? 60 : 15));
  assert.equal(doc('users/A').stats.played, 1); ok('coins and stats awarded once');
  await rejects(call('gameAction', 'A', { roomId, action: { type: 'pass', seat: seatA } }), /خلصت/); ok('no moves after match end');

  console.log('bu 6 match with 3 humans');
  const r6 = await call('createRoom', 'A', { variant: 6 });
  await call('joinRoom', 'B', { code: r6.code });
  await call('joinRoom', 'D', { roomId: r6.roomId });
  await call('startRoom', 'A', { roomId: r6.roomId });
  await playOut(r6.roomId, ['A', 'B', 'D']);
  assert.equal(doc(`rooms/${r6.roomId}`).status, 'done'); ok('full online bu 6 match finished');

  console.log('turn timeout and leaving');
  const rt = await call('createRoom', 'A', { variant: 4 });
  await call('joinRoom', 'B', { code: rt.code });
  await call('startRoom', 'A', { roomId: rt.roomId });
  for (let k = 0; k < 3; k++) {
    const s = doc(`games/${rt.roomId}/secret/state`);
    const who = actor(s.state);
    const uid = s.seats[who].uid;
    assert.ok(uid, 'a human is on turn');
    const before = s.step;
    await call('claimTimeout', 'A', { roomId: rt.roomId });
    assert.equal(doc(`games/${rt.roomId}/secret/state`).step, before, 'no auto-play before deadline');
    store.set(`games/${rt.roomId}/secret/state`, { ...doc(`games/${rt.roomId}/secret/state`), deadline: Timestamp.fromMillis(Date.now() - 1000) });
    await call('claimTimeout', 'A', { roomId: rt.roomId });
    assert.ok(doc(`games/${rt.roomId}/secret/state`).step > before);
  }
  ok('timed-out turns are auto-played (not before the deadline)');
  await call('leaveRoom', 'B', { roomId: rt.roomId });
  assert.equal(doc(`games/${rt.roomId}/secret/state`).left[doc(`games/${rt.roomId}/secret/state`).seats.findIndex(s => s.uid === 'B')], true);
  await playOut(rt.roomId, ['A']);
  ok('player who leaves is replaced by a bot and the match finishes');

  console.log('quick match');
  const q1 = await call('quickMatch', 'A', { variant: 4 });
  const q2 = await call('quickMatch', 'B', { variant: 4 });
  assert.equal(q1.roomId, q2.roomId); ok('two players matched into the same public room');
  await rejects(call('startRoom', 'B', { roomId: q1.roomId }), /صاحب الغرفة/); ok('non-host cannot start a public room early');
  store.set(`rooms/${q1.roomId}`, { ...doc(`rooms/${q1.roomId}`), createdAt: Timestamp.fromMillis(Date.now() - 45_000) });
  await call('startRoom', 'B', { roomId: q1.roomId }); ok('after 40s any player can start with bots');
  const q3 = await call('quickMatch', 'C', { variant: 6 }, 'password', true);
  assert.notEqual(q3.roomId, q1.roomId); ok('different variant gets its own room');

  console.log('store');
  store.set('users/D', { ...doc('users/D'), coins: 1000 });
  await call('buyItem', 'D', { itemId: 'misbah_wood' });
  assert.equal(doc('users/D').coins, 850); assert.ok(doc('users/D').owned.includes('misbah_wood')); ok('buy item deducts coins');
  await rejects(call('buyItem', 'D', { itemId: 'misbah_wood' }), /عندك/); ok('cannot buy twice');
  await rejects(call('buyItem', 'D', { itemId: 'landcruiser' }), /رصيدك/); ok('insufficient coins rejected');
  await rejects(call('equipItem', 'D', { itemId: 'bisht', slot: 'accessory' }), /ما تملك/); ok('cannot equip unowned item');
  await call('equipItem', 'D', { itemId: 'misbah_wood', slot: 'accessory' });
  assert.equal(doc('users/D').equipped.accessory, 'misbah_wood'); ok('equip owned item');
  await call('verifyPurchase', 'D', { productId: 'coins_1200', purchaseToken: 'tok-123456789' });
  await call('verifyPurchase', 'D', { productId: 'coins_1200', purchaseToken: 'tok-123456789' });
  assert.equal(doc('users/D').coins, 850 + 1200); ok('Play purchase credited exactly once');
  await rejects(call('verifyPurchase', 'D', { productId: 'coins_500', purchaseToken: 'bad-123456789' }), /مو مكتمل/); ok('pending/cancelled purchase not credited');
  await rejects(call('verifyPurchase', 'D', { productId: 'coins_free', purchaseToken: 'tok-999999999' }), /مو صحيحة/); ok('unknown product rejected');

  console.log('majlis');
  store.set('users/A', { ...doc('users/A'), coins: 2000 });
  const { majlisId } = await call('createMajlis', 'A', { name: 'مجلس الربع', tag: 'rba', emblem: '⚓', open: true });
  assert.equal(doc(`majalis/${majlisId}`).tag, 'RBA'); assert.equal(doc('users/A').coins, 1500); ok('create majlis costs 500');
  await rejects(call('createMajlis', 'B', { name: 'ثاني', tag: 'RBA' }), /مستخدم|بيزة/); ok('duplicate tag rejected');
  await call('joinMajlis', 'B', { majlisId });
  await call('joinMajlis', 'D', { majlisId });
  assert.equal(doc(`majalis/${majlisId}`).memberCount, 3); ok('members join');
  await rejects(call('kickMember', 'B', { uid: 'D' }), /صلاحية/); ok('plain member cannot kick');
  await call('promoteMember', 'A', { uid: 'B' });
  await call('kickMember', 'B', { uid: 'D' });
  assert.equal(doc('users/D').majlisId, null); assert.equal(doc(`majalis/${majlisId}`).memberCount, 2); ok('elder can kick a member');
  const mr = await call('createRoom', 'A', { variant: 4, majlisId });
  await rejects(call('joinRoom', 'D', { roomId: mr.roomId }), /لأعضاء المجلس/); ok('majlis table only for members');
  await call('joinRoom', 'B', { roomId: mr.roomId });
  await call('startRoom', 'A', { roomId: mr.roomId });
  await playOut(mr.roomId, ['A', 'B']);
  const m = doc(`majalis/${majlisId}`);
  ok(`majlis match done, majlis trophies now ${m.trophies}`);
  await call('leaveMajlis', 'A', {});
  assert.equal(doc(`majalis/${majlisId}`).ownerUid, 'B'); ok('owner leaving hands ownership to the elder');
  await call('leaveMajlis', 'B', {});
  assert.equal(doc(`majalis/${majlisId}`), undefined); assert.equal(doc('majlisTags/RBA'), undefined); ok('last member leaving deletes the majlis and frees the tag');

  console.log('reactions & account deletion');
  const rr = await call('createRoom', 'A', { variant: 4 });
  await call('startRoom', 'A', { roomId: rr.roomId });
  await call('sendReaction', 'A', { roomId: rr.roomId, slot: 'r_clap' });
  await rejects(call('sendReaction', 'A', { roomId: rr.roomId, slot: 'r_laugh' }), /شوي/); ok('reaction rate limit');
  store.set('users/A', { ...doc('users/A'), lastReactionAt: Timestamp.fromMillis(0) });
  await rejects(call('sendReaction', 'A', { roomId: rr.roomId, slot: 'm_yaaah' }), /المتجر/); ok('meme reactions locked without the pack');
  await call('deleteAccount', 'D', {});
  assert.equal(doc('users/D'), undefined); assert.ok(deletedUsers.includes('D')); ok('account deletion');

  console.log(`\nall ${passed} checks passed`);
})().catch(e => { console.error('FAILED:', e); process.exit(1); });

// In-memory stand-ins for firebase-admin and firebase-functions, enough to run the
// real Cloud Functions code in plain Node for testing (the official emulator is not required).
const Module = require('module');

// ---------- Firestore ----------
class Timestamp {
  constructor(ms) { this.ms = ms; }
  static now() { return new Timestamp(Date.now()); }
  static fromMillis(ms) { return new Timestamp(ms); }
  toMillis() { return this.ms; }
}
const SENT = Symbol('sentinel');
const FieldValue = {
  increment: n => ({ [SENT]: 'inc', n }),
  arrayUnion: (...v) => ({ [SENT]: 'union', v }),
  delete: () => ({ [SENT]: 'del' }),
  serverTimestamp: () => ({ [SENT]: 'ts' }),
};
const store = new Map(); // path -> data
let autoId = 0;
const clone = v => (v instanceof Timestamp ? v : Array.isArray(v) ? v.map(clone) : v && typeof v === 'object' ? Object.fromEntries(Object.entries(v).map(([k, x]) => [k, clone(x)])) : v);

function resolve(cur, v) {
  if (v && typeof v === 'object' && v[SENT]) {
    if (v[SENT] === 'inc') return (cur ?? 0) + v.n;
    if (v[SENT] === 'union') return [...new Set([...(cur ?? []), ...v.v])];
    if (v[SENT] === 'ts') return Timestamp.now();
    if (v[SENT] === 'del') return undefined;
  }
  if (v && typeof v === 'object' && !(v instanceof Timestamp) && !Array.isArray(v)) {
    const o = {};
    for (const [k, x] of Object.entries(v)) { const r = resolve(undefined, x); if (r !== undefined) o[k] = r; }
    return o;
  }
  return clone(v);
}
function applyUpdate(data, patch) {
  const d = clone(data);
  for (const [k, v] of Object.entries(patch)) {
    const parts = k.split('.');
    let o = d;
    for (const p of parts.slice(0, -1)) o = o[p] ??= {};
    const last = parts.at(-1);
    const r = resolve(o[last], v);
    if (r === undefined) delete o[last]; else o[last] = r;
  }
  return d;
}

// Mirror real Firestore: no arrays directly inside arrays, no undefined values.
function validate(v, path = '', inArray = false) {
  if (v === undefined) throw new Error(`Firestore rejects undefined at ${path || 'root'}`);
  if (Array.isArray(v)) {
    if (inArray) throw new Error(`Firestore rejects nested arrays at ${path}`);
    v.forEach((x, i) => validate(x, `${path}[${i}]`, true));
  } else if (v && typeof v === 'object' && !(v instanceof Timestamp) && !v[SENT]) {
    for (const [k, x] of Object.entries(v)) validate(x, path ? `${path}.${k}` : k, false);
  }
}

class DocSnap {
  constructor(ref, data) { this.ref = ref; this.id = ref.id; this._d = data; this.exists = data !== undefined; }
  data() { return this._d === undefined ? undefined : clone(this._d); }
}
class DocRef {
  constructor(path) { this.path = path; this.id = path.split('/').at(-1); }
  get parent() { return new ColRef(this.path.split('/').slice(0, -1).join('/')); }
  collection(c) { return new ColRef(`${this.path}/${c}`); }
  async get() { return new DocSnap(this, store.get(this.path)); }
  async set(d) { validate(d); store.set(this.path, resolve(undefined, d)); }
  async create(d) { validate(d); if (store.has(this.path)) throw new Error('exists ' + this.path); store.set(this.path, resolve(undefined, d)); }
  async update(p) { validate(p); if (!store.has(this.path)) throw new Error('no doc ' + this.path); store.set(this.path, applyUpdate(store.get(this.path), p)); }
  async delete() { store.delete(this.path); }
}
const val = (d, f) => f.split('.').reduce((o, k) => o?.[k], d);
const cmp = (a, b) => { a = a instanceof Timestamp ? a.ms : a; b = b instanceof Timestamp ? b.ms : b; return a < b ? -1 : a > b ? 1 : 0; };
class Query {
  constructor(match, filters = [], order = null, lim = Infinity) { Object.assign(this, { match, filters, order, lim }); }
  where(f, op, v) { return new Query(this.match, [...this.filters, [f, op, v]], this.order, this.lim); }
  orderBy(f, dir = 'asc') { return new Query(this.match, this.filters, [f, dir], this.lim); }
  limit(n) { return new Query(this.match, this.filters, this.order, n); }
  async get() {
    let docs = [...store.entries()].filter(([p]) => this.match(p)).map(([p, d]) => new DocSnap(new DocRef(p), d));
    docs = docs.filter(s => this.filters.every(([f, op, v]) => {
      const x = val(s._d, f);
      if (op === '==') return cmp(x, v) === 0;
      if (op === '<') return x !== undefined && x !== null && cmp(x, v) < 0;
      if (op === '>') return x !== undefined && x !== null && cmp(x, v) > 0;
      throw new Error('op ' + op);
    }));
    if (this.order) docs.sort((a, b) => cmp(val(a._d, this.order[0]), val(b._d, this.order[0])) * (this.order[1] === 'desc' ? -1 : 1));
    docs = docs.slice(0, this.lim);
    return { empty: docs.length === 0, docs, size: docs.length };
  }
}
class ColRef extends Query {
  constructor(path) {
    const depth = path.split('/').length + 1;
    super(p => p.startsWith(path + '/') && p.split('/').length === depth);
    this.path = path;
  }
  get parent() { const p = this.path.split('/'); return p.length > 1 ? new DocRef(p.slice(0, -1).join('/')) : null; }
  doc(id) { return new DocRef(`${this.path}/${id ?? 'auto' + (++autoId)}`); }
  async add(d) { const r = this.doc(); await r.set(d); return r; }
}
class Tx {
  constructor() { this.writes = []; this.wrote = false; }
  async get(ref) { if (this.wrote) throw new Error('read after write in transaction'); return ref.get(); }
  set(ref, d) { this.wrote = true; this.writes.push(() => ref.set(d)); }
  create(ref, d) { this.wrote = true; this.writes.push(() => ref.create(d)); }
  update(ref, d) { this.wrote = true; this.writes.push(() => ref.update(d)); }
  delete(ref) { this.wrote = true; this.writes.push(() => ref.delete()); }
}
let txLock = Promise.resolve();
const db = {
  doc: p => new DocRef(p),
  collection: p => new ColRef(p),
  collectionGroup: id => new Query(p => p.split('/').at(-2) === id),
  batch() { const t = new Tx(); return Object.assign(t, { commit: async () => { for (const w of t.writes) await w(); } }); },
  async runTransaction(fn) {
    // Serialize transactions (real Firestore retries on conflict; serial execution is equivalent).
    const prev = txLock; let release; txLock = new Promise(r => (release = r));
    await prev;
    try { const t = new Tx(); const r = await fn(t); for (const w of t.writes) await w(); return r; }
    finally { release(); }
  },
};

// ---------- functions ----------
class HttpsError extends Error { constructor(code, msg, details) { super(msg); this.code = code; this.details = details; } }
const onCall = (o, h) => (typeof o === 'function' ? o : h);
const onSchedule = (o, h) => h;

const deletedUsers = [];
const fakes = {
  'firebase-admin/firestore': { getFirestore: () => db, FieldValue, Timestamp },
  'firebase-admin/app': { initializeApp: () => {} },
  'firebase-admin/auth': { getAuth: () => ({ deleteUser: async uid => deletedUsers.push(uid) }) },
  'firebase-functions/v2': { setGlobalOptions: () => {} },
  'firebase-functions/v2/https': { onCall, HttpsError },
  'firebase-functions/v2/scheduler': { onSchedule },
  'firebase-functions/params': { defineString: (n, o) => ({ value: () => o.default }) },
  'googleapis': { google: globalThis.__fakeGoogle ?? {} },
};
const origLoad = Module._load;
Module._load = function (req, ...rest) { return fakes[req] ?? origLoad.call(this, req, ...rest); };

module.exports = { store, db, Timestamp, deletedUsers, fakes };

import { setGlobalOptions } from 'firebase-functions/v2';
import { initializeApp } from 'firebase-admin/app';

initializeApp();
// Must match FUNCTIONS_REGION in src/net/firebase-config.ts. me-central2 (Dammam) is closest to
// Bahrain if your Firebase project supports it; europe-west1 is a safe default.
setGlobalOptions({ region: 'europe-west1', maxInstances: 20 });

export { createRoom, joinRoom, quickMatch, switchSeat, startRoom, leaveRoom, gameAction, claimTimeout, sendReaction, sweepStalledGames } from './game';
export { ensureProfile, updateProfile, buyItem, equipItem, verifyPurchase, deleteAccount } from './account';
export { createMajlis, joinMajlis, leaveMajlis, kickMember, promoteMember } from './majlis';

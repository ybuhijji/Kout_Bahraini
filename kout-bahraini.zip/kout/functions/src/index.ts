import { setGlobalOptions } from 'firebase-functions/v2';
import { onCall } from 'firebase-functions/v2/https';
import { initializeApp } from 'firebase-admin/app';
import { Handler, fail } from './util';
import * as game from './game';
import * as account from './account';
import * as majlis from './majlis';

initializeApp();
// Must match FUNCTIONS_REGION in src/net/firebase-config.ts.
setGlobalOptions({ region: 'europe-west1', maxInstances: 10 });

const handlers: Record<string, Handler> = {
  createRoom: game.createRoom, joinRoom: game.joinRoom, quickMatch: game.quickMatch,
  switchSeat: game.switchSeat, startRoom: game.startRoom, leaveRoom: game.leaveRoom,
  gameAction: game.gameAction, rejoinRoom: game.rejoinRoom, rematch: game.rematch, setAway: game.setAway, tickGame: game.tickGame, sendReaction: game.sendReaction,
  ensureProfile: account.ensureProfile, updateProfile: account.updateProfile, buyItem: account.buyItem,
  equipItem: account.equipItem, verifyPurchase: account.verifyPurchase, deleteAccount: account.deleteAccount,
  createMajlis: majlis.createMajlis, joinMajlis: majlis.joinMajlis, leaveMajlis: majlis.leaveMajlis,
  kickMember: majlis.kickMember, promoteMember: majlis.promoteMember,
};

/**
 * One function for every app request, so a single warm server answers everything
 * (separate functions each had their own slow "cold start").
 * minInstances: 1 keeps one server always warm. It costs a few dollars a month;
 * set it to 0 to save that, at the price of a slow first request after idle periods.
 */
export const api = onCall(
  { minInstances: 1, memory: '512MiB', cpu: 1, concurrency: 80, timeoutSeconds: 60 },
  async req => {
    const op = String(req.data?.op ?? '');
    const h = handlers[op];
    if (!h) fail('invalid-argument', 'طلب مو معروف');
    return h({ ...req, data: req.data?.data ?? {} } as any);
  },
);

export { sweepStalledGames } from './game';

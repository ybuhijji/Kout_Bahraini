import { getFirestore, FieldValue } from 'firebase-admin/firestore';
import { STARTING_COINS } from './shared/catalog';
import { cleanName } from './util';

/** Creates the player's profile the first time it is needed. Safe to call repeatedly. */
export async function createProfileIfMissing(uid: string, name?: unknown, photo?: unknown) {
  const db = getFirestore();
  const ref = db.doc(`users/${uid}`);
  await db.runTransaction(async tx => {
    const s = await tx.get(ref);
    if (s.exists) return;
    tx.set(ref, {
      name: cleanName(name, 'لاعب'),
      avatar: '🧔',
      photo: typeof photo === 'string' ? photo.slice(0, 500) : null,
      coins: STARTING_COINS,
      owned: [],
      equipped: {},
      majlisId: null,
      majlisTag: null,
      activeRoom: null,
      stats: { played: 0, won: 0, kouts: 0 },
      createdAt: FieldValue.serverTimestamp(),
    });
  });
  return ref;
}

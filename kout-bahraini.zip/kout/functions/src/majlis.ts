// الميالس: clans. Max 30 members. Owner can promote members to elders; owner and elders can kick.
import { onCall } from 'firebase-functions/v2/https';
import { getFirestore, FieldValue } from 'firebase-admin/firestore';
import { cleanName, fail, requireUser } from './util';
import { createProfileIfMissing } from './profile';

const db = () => getFirestore();
const MAX_MEMBERS = 30;
const CREATE_COST = 500;
const EMBLEMS = ['🏛️', '⚓', '🦅', '🐪', '🌴', '🦪', '⛵', '🔥', '🦁', '🗡️', '👑', '☕'];

export const createMajlis = onCall(async req => {
  const uid = requireUser(req);
  await createProfileIfMissing(uid, req.auth?.token.name ?? req.auth?.token.email?.split('@')[0]);
  const name = String(req.data?.name ?? '').trim().slice(0, 24);
  const tag = String(req.data?.tag ?? '').trim().toUpperCase();
  if (name.length < 3) fail('invalid-argument', 'اسم المجلس لازم 3 حروف على الأقل');
  if (!/^[A-Z0-9]{2,5}$/.test(tag)) fail('invalid-argument', 'الرمز من 2 إلى 5 حروف أو أرقام إنجليزي');
  const emblem = EMBLEMS.includes(req.data?.emblem) ? req.data.emblem : EMBLEMS[0];
  const tagRef = db().doc(`majlisTags/${tag}`);
  const userRef = db().doc(`users/${uid}`);
  const ref = db().collection('majalis').doc();
  await db().runTransaction(async tx => {
    const [u, t] = await Promise.all([tx.get(userRef), tx.get(tagRef)]);
    const user = u.data()!;
    if (user.majlisId) fail('failed-precondition', 'أنت في مجلس، اطلع منه أول');
    if (t.exists) fail('failed-precondition', 'الرمز مستخدم');
    if (user.coins < CREATE_COST) fail('failed-precondition', `تحتاج ${CREATE_COST} بيزة`);
    tx.create(tagRef, { majlisId: ref.id });
    tx.create(ref, {
      name: cleanName(name, 'مجلس'), tag, emblem, open: req.data?.open !== false,
      description: String(req.data?.description ?? '').slice(0, 140),
      ownerUid: uid, memberCount: 1, trophies: 0, createdAt: FieldValue.serverTimestamp(),
    });
    tx.create(ref.collection('members').doc(uid), { name: user.name, avatar: user.avatar, role: 'owner', wins: 0, joinedAt: FieldValue.serverTimestamp() });
    tx.update(userRef, { majlisId: ref.id, majlisTag: tag, coins: FieldValue.increment(-CREATE_COST) });
  });
  return { majlisId: ref.id };
});

export const joinMajlis = onCall(async req => {
  const uid = requireUser(req);
  await createProfileIfMissing(uid, req.auth?.token.name ?? req.auth?.token.email?.split('@')[0]);
  const id = String(req.data?.majlisId);
  const ref = db().doc(`majalis/${id}`);
  const userRef = db().doc(`users/${uid}`);
  await db().runTransaction(async tx => {
    const [m, u] = await Promise.all([tx.get(ref), tx.get(userRef)]);
    if (!m.exists) fail('not-found', 'المجلس مو موجود');
    const mj = m.data()!; const user = u.data()!;
    if (user.majlisId) fail('failed-precondition', 'أنت في مجلس، اطلع منه أول');
    if (!mj.open) fail('permission-denied', 'المجلس مقفل');
    if (mj.memberCount >= MAX_MEMBERS) fail('resource-exhausted', 'المجلس مليان');
    tx.create(ref.collection('members').doc(uid), { name: user.name, avatar: user.avatar, role: 'member', wins: 0, joinedAt: FieldValue.serverTimestamp() });
    tx.update(ref, { memberCount: FieldValue.increment(1) });
    tx.update(userRef, { majlisId: id, majlisTag: mj.tag });
  });
  return { ok: true };
});

export async function leaveMajlisInternal(uid: string) {
  const userRef = db().doc(`users/${uid}`);
  const id = (await userRef.get()).data()?.majlisId;
  if (!id) return;
  const ref = db().doc(`majalis/${id}`);
  // Find a successor outside the transaction (queries are not allowed inside admin transactions with reads-after-writes).
  const others = await ref.collection('members').orderBy('joinedAt').limit(MAX_MEMBERS).get();
  await db().runTransaction(async tx => {
    const m = await tx.get(ref);
    if (!m.exists) { tx.update(userRef, { majlisId: null, majlisTag: null }); return; }
    const mj = m.data()!;
    tx.delete(ref.collection('members').doc(uid));
    tx.update(userRef, { majlisId: null, majlisTag: null });
    const rest = others.docs.filter(d => d.id !== uid);
    if (!rest.length) {
      tx.delete(ref);
      tx.delete(db().doc(`majlisTags/${mj.tag}`));
      return;
    }
    const upd: Record<string, unknown> = { memberCount: FieldValue.increment(-1) };
    if (mj.ownerUid === uid) {
      const heir = rest.find(d => d.data().role === 'elder') ?? rest[0];
      upd.ownerUid = heir.id;
      tx.update(heir.ref, { role: 'owner' });
    }
    tx.update(ref, upd);
  });
}

export const leaveMajlis = onCall(async req => {
  await leaveMajlisInternal(requireUser(req));
  return { ok: true };
});

async function roles(uid: string, target: string) {
  const id = (await db().doc(`users/${uid}`).get()).data()?.majlisId;
  if (!id) fail('failed-precondition', 'مو في مجلس');
  const [me, them] = await Promise.all([
    db().doc(`majalis/${id}/members/${uid}`).get(),
    db().doc(`majalis/${id}/members/${target}`).get(),
  ]);
  if (!them.exists) fail('not-found', 'العضو مو في المجلس');
  return { id, me: me.data()?.role as string, them: them.data()?.role as string };
}

export const kickMember = onCall(async req => {
  const uid = requireUser(req);
  await createProfileIfMissing(uid, req.auth?.token.name ?? req.auth?.token.email?.split('@')[0]);
  const target = String(req.data?.uid);
  const r = await roles(uid, target);
  const can = r.me === 'owner' ? r.them !== 'owner' : r.me === 'elder' && r.them === 'member';
  if (!can) fail('permission-denied', 'ما عندك صلاحية');
  const ref = db().doc(`majalis/${r.id}`);
  const batch = db().batch();
  batch.delete(ref.collection('members').doc(target));
  batch.update(ref, { memberCount: FieldValue.increment(-1) });
  batch.update(db().doc(`users/${target}`), { majlisId: null, majlisTag: null });
  await batch.commit();
  return { ok: true };
});

export const promoteMember = onCall(async req => {
  const uid = requireUser(req);
  await createProfileIfMissing(uid, req.auth?.token.name ?? req.auth?.token.email?.split('@')[0]);
  const target = String(req.data?.uid);
  const r = await roles(uid, target);
  if (r.me !== 'owner' || r.them !== 'member') fail('permission-denied', 'ما عندك صلاحية');
  await db().doc(`majalis/${r.id}/members/${target}`).update({ role: 'elder' });
  return { ok: true };
});

// Rooms, matchmaking and the authoritative online game loop.
import { onCall } from 'firebase-functions/v2/https';
import { onSchedule } from 'firebase-functions/v2/scheduler';
import { getFirestore, FieldValue, Timestamp, Transaction, DocumentReference } from 'firebase-admin/firestore';
import {
  Action, GameEvent, MatchState, RuleError, Variant, apply, mulberry32, newMatch, teamOf, viewFor,
} from './shared/engine';
import { chooseAction } from './shared/bot';
import { COINS_LOSS, COINS_WIN, SOUND_SLOTS } from './shared/catalog';
import { BOT_NAMES, fail, randomCode, requireUser, sleep } from './util';
import { createProfileIfMissing } from './profile';

const db = () => getFirestore();

export interface Seat {
  uid?: string;          // undefined for bots
  name: string;
  avatar: string;
  accessory?: string | null;
  majlis?: string | null;
  majlisId?: string | null;
  bot: boolean;
}

interface Room {
  code: string;
  variant: Variant;
  hostUid: string;
  status: 'waiting' | 'playing' | 'done';
  isPublic: boolean;
  majlisId: string | null;
  seats: (Seat | null)[];
  uids: string[];
  theme: string;
  createdAt: Timestamp;
}

interface Secret {
  state: MatchState;
  seed: number;
  step: number;
  seats: Seat[];
  afk: number[];          // consecutive timeouts per seat
  left: boolean[];        // player left: a bot plays for them
  deadline: Timestamp | null;
  finished: boolean;
  rewarded: boolean;
}

const TURN_MS = 25_000;
const BID_MS = 20_000;
const AFK_MS = 6_000;
const BOT_MS = 800;
const TRICK_PAUSE_MS = 1_300;
const HAND_PAUSE_MS = 4_500;
const PUBLIC_FILL_MS = 40_000;

const roomRef = (id: string) => db().doc(`rooms/${id}`);
const secretRef = (id: string) => db().doc(`games/${id}/secret/state`);
const viewRef = (id: string, uid: string) => db().doc(`games/${id}/views/${uid}`);

// ---------- helpers ----------

async function seatFor(uid: string, nameHint?: unknown): Promise<Seat> {
  const ref = await createProfileIfMissing(uid, nameHint);
  const u = await ref.get();
  const d = u.data()!;
  return {
    uid, name: d.name, avatar: d.avatar ?? '🧔', accessory: d.equipped?.accessory ?? null,
    majlis: d.majlisTag ?? null, majlisId: d.majlisId ?? null, bot: false,
  };
}

function actor(s: MatchState): number | null {
  if (s.phase === 'bidding') return s.bidTurn;
  if (s.phase === 'trump') return s.bidder;
  if (s.phase === 'playing') return s.turn;
  return null;
}

function botControlled(sec: Secret, seat: number) {
  return sec.seats[seat].bot || sec.left[seat];
}

function rngFor(sec: Secret) {
  return mulberry32((sec.seed ^ Math.imul(sec.step + 1, 2654435761)) >>> 0);
}

function publicSeats(seats: Seat[]) {
  return seats.map(s => ({ name: s.name, avatar: s.avatar, accessory: s.accessory ?? null, majlis: s.majlis ?? null, bot: s.bot, uid: s.uid ?? null }));
}

function writeViews(tx: Transaction, gameId: string, sec: Secret, events: GameEvent[]) {
  const seats = publicSeats(sec.seats);
  sec.seats.forEach((st, i) => {
    if (!st.uid) return;
    tx.set(viewRef(gameId, st.uid), {
      seq: sec.step,
      view: viewFor(sec.state, i),
      events,
      seats,
      mySeat: i,
      deadline: sec.deadline,
    });
  });
}

function setDeadline(sec: Secret) {
  const a = actor(sec.state);
  if (a === null || botControlled(sec, a)) { sec.deadline = null; return; }
  // A player who already timed out twice gets a short timer, so the table is not held up
  // but they can still jump back in by playing.
  const ms = sec.afk[a] >= 2 ? AFK_MS : sec.state.phase === 'playing' ? TURN_MS : BID_MS;
  sec.deadline = Timestamp.fromMillis(Date.now() + ms);
}

/**
 * One atomic step: re-reads the game, checks nobody else advanced it (step guard),
 * applies the action and writes every player's view.
 */
async function step(gameId: string, expectStep: number | null, decide: (sec: Secret) => Action | null): Promise<{ sec: Secret; events: GameEvent[] } | null> {
  return db().runTransaction(async tx => {
    const snap = await tx.get(secretRef(gameId));
    if (!snap.exists) return null;
    const sec = snap.data() as Secret;
    if (sec.finished) return null;
    if (expectStep !== null && sec.step !== expectStep) return null;
    const a = decide(sec);
    if (!a) return null;
    let events: GameEvent[];
    try {
      events = apply(sec.state, a, rngFor(sec));
    } catch (e) {
      if (e instanceof RuleError) fail('invalid-argument', 'حركة مو مسموحة');
      throw e;
    }
    sec.step++;
    setDeadline(sec);
    if (sec.state.phase === 'matchOver') sec.finished = true;
    tx.set(secretRef(gameId), sec);
    writeViews(tx, gameId, sec, events);
    if (sec.finished) tx.update(roomRef(gameId), { status: 'done', endedAt: FieldValue.serverTimestamp() });
    return { sec, events };
  });
}

/** Plays bot / AFK turns and moves to the next hand until a human has to act. */
async function advance(gameId: string) {
  for (let i = 0; i < 200; i++) {
    const snap = await secretRef(gameId).get();
    if (!snap.exists) return;
    const sec = snap.data() as Secret;
    if (sec.finished) { await reward(gameId); return; }
    if (sec.seats.every((st, i) => !st.uid || sec.left[i])) { await abandon(gameId); return; }
    const s = sec.state;
    if (s.phase === 'handOver') {
      await sleep(HAND_PAUSE_MS);
      await step(gameId, sec.step, () => ({ type: 'nextHand' }));
      continue;
    }
    const a = actor(s);
    if (a === null || !botControlled(sec, a)) return;
    await sleep(s.phase === 'playing' && s.trick.length === 0 && s.lastTrick ? TRICK_PAUSE_MS : BOT_MS);
    const r = await step(gameId, sec.step, cur => chooseAction(cur.state, a, 'normal'));
    if (!r) return; // someone else advanced the game
  }
  // Safety: hand over to the sweeper instead of running forever in one invocation.
  await secretRef(gameId).update({ deadline: Timestamp.now() });
}

/** Every human left: close the game without rewards. */
async function abandon(gameId: string) {
  await db().runTransaction(async tx => {
    const snap = await tx.get(secretRef(gameId));
    if (!snap.exists || snap.data()!.finished) return;
    tx.update(snap.ref, { finished: true, rewarded: true, deadline: null, abandoned: true });
    tx.update(roomRef(gameId), { status: 'done', endedAt: FieldValue.serverTimestamp() });
  });
}

async function reward(gameId: string) {
  await db().runTransaction(async tx => {
    const snap = await tx.get(secretRef(gameId));
    const sec = snap.data() as Secret;
    if (!sec || sec.rewarded || !sec.finished) return;
    const winner = sec.state.winner!;
    const majlisWins = new Map<string, number>();
    const memberRefs: DocumentReference[] = [];
    sec.seats.forEach((st, i) => {
      if (st.uid && teamOf(i) === winner && st.majlisId) {
        majlisWins.set(st.majlisId, (majlisWins.get(st.majlisId) ?? 0) + 1);
        memberRefs.push(db().doc(`majalis/${st.majlisId}/members/${st.uid}`));
      }
    });
    // Firestore transactions need every read before the first write.
    const memberSnaps = await Promise.all(memberRefs.map(r => tx.get(r)));
    const majlisSnaps = await Promise.all([...majlisWins.keys()].map(id => tx.get(db().doc(`majalis/${id}`))));
    sec.seats.forEach((st, i) => {
      if (!st.uid) return;
      const won = teamOf(i) === winner;
      const quit = sec.left[i];
      tx.update(db().doc(`users/${st.uid}`), {
        coins: FieldValue.increment(won && !quit ? COINS_WIN : quit ? 0 : COINS_LOSS),
        'stats.played': FieldValue.increment(1),
        'stats.won': FieldValue.increment(won ? 1 : 0),
        'stats.kouts': FieldValue.increment(won && sec.state.winReason === 'inzeli' ? 1 : 0),
      });
    });
    majlisSnaps.forEach(ms => { if (ms.exists) tx.update(ms.ref, { trophies: FieldValue.increment(3 * majlisWins.get(ms.id)!) }); });
    memberSnaps.forEach(ms => { if (ms.exists) tx.update(ms.ref, { wins: FieldValue.increment(1) }); });
    tx.update(secretRef(gameId), { rewarded: true });
  });
}

async function startGame(tx: Transaction, roomId: string, room: Room) {
  const used = new Set(room.seats.filter(Boolean).map(s => s!.name));
  const names = BOT_NAMES.filter(n => !used.has(n)).sort(() => Math.random() - 0.5);
  const seats: Seat[] = room.seats.map((s, i) => s ?? { name: names[i] ?? `بوت ${i + 1}`, avatar: '🤖', bot: true, accessory: null });
  const seed = Math.floor(Math.random() * 2 ** 31);
  const sec: Secret = {
    state: newMatch(room.variant, mulberry32(seed), Math.floor(Math.random() * room.variant)),
    seed, step: 0, seats,
    afk: seats.map(() => 0), left: seats.map(() => false),
    deadline: null, finished: false, rewarded: false,
  };
  setDeadline(sec);
  tx.set(secretRef(roomId), sec);
  writeViews(tx, roomId, sec, [{ type: 'dealt' }]);
  tx.update(roomRef(roomId), { status: 'playing', seats, startedAt: FieldValue.serverTimestamp() });
}

// ---------- callable functions ----------

const opts = { timeoutSeconds: 300, memory: '256MiB' as const };

export const createRoom = onCall(opts, async req => {
  const uid = requireUser(req);
  const variant = req.data?.variant === 6 ? 6 : 4;
  const majlisId: string | null = req.data?.majlisId ?? null;
  const me = await seatFor(uid, req.auth?.token.name ?? req.auth?.token.email?.split('@')[0]);
  if (majlisId && me.majlisId !== majlisId) fail('permission-denied', 'مو عضو في هالمجلس');
  let code = randomCode();
  for (let i = 0; i < 5; i++) {
    const clash = await db().collection('rooms').where('code', '==', code).where('status', '==', 'waiting').limit(1).get();
    if (clash.empty) break;
    code = randomCode();
  }
  const ref = db().collection('rooms').doc();
  const seats: (Seat | null)[] = Array(variant).fill(null);
  seats[0] = me;
  const room: Room = { code, variant, hostUid: uid, status: 'waiting', isPublic: false, majlisId, seats, uids: [uid], theme: 'classic', createdAt: Timestamp.now() };
  await ref.set(room);
  return { roomId: ref.id, code };
});

function takeSeat(room: Room, me: Seat): number {
  // Alternate teams while filling so friends spread across both sides as they join.
  const free = room.seats.map((s, i) => (s ? -1 : i)).filter(i => i >= 0);
  if (!free.length) fail('resource-exhausted', 'الطاولة مليانة');
  const count = [0, 1].map(t => room.seats.filter((s, i) => s && teamOf(i) === t).length);
  const wantTeam = count[0] <= count[1] ? 0 : 1;
  const seat = free.find(i => teamOf(i) === wantTeam) ?? free[0];
  room.seats[seat] = me;
  room.uids.push(me.uid!);
  return seat;
}

export const joinRoom = onCall(opts, async req => {
  const uid = requireUser(req);
  const me = await seatFor(uid, req.auth?.token.name ?? req.auth?.token.email?.split('@')[0]);
  let roomId: string | undefined = req.data?.roomId;
  if (!roomId) {
    const code = String(req.data?.code ?? '').toUpperCase();
    const q = await db().collection('rooms').where('code', '==', code).where('status', '==', 'waiting').limit(1).get();
    if (q.empty) fail('not-found', 'ما لقينا غرفة بهالكود');
    roomId = q.docs[0].id;
  }
  await db().runTransaction(async tx => {
    const snap = await tx.get(roomRef(roomId!));
    if (!snap.exists) fail('not-found', 'الغرفة مو موجودة');
    const room = snap.data() as Room;
    if (room.uids.includes(uid)) return;
    if (room.status !== 'waiting') fail('failed-precondition', 'اللعبة بدأت');
    if (room.majlisId && me.majlisId !== room.majlisId) fail('permission-denied', 'هالطاولة لأعضاء المجلس بس');
    takeSeat(room, me);
    tx.update(snap.ref, { seats: room.seats, uids: room.uids });
    if (room.isPublic && room.seats.every(Boolean)) await startGame(tx, snap.id, room);
  });
  return { roomId };
});

export const quickMatch = onCall(opts, async req => {
  const uid = requireUser(req);
  const variant = req.data?.variant === 6 ? 6 : 4;
  const me = await seatFor(uid, req.auth?.token.name ?? req.auth?.token.email?.split('@')[0]);
  const fresh = Timestamp.fromMillis(Date.now() - 3 * 60_000);
  const q = await db().collection('rooms')
    .where('isPublic', '==', true).where('status', '==', 'waiting').where('variant', '==', variant)
    .where('createdAt', '>', fresh).orderBy('createdAt').limit(10).get();
  for (const d of q.docs) {
    const joined = await db().runTransaction(async tx => {
      const snap = await tx.get(d.ref);
      const room = snap.data() as Room;
      if (room.status !== 'waiting' || room.seats.every(Boolean)) return false;
      if (room.uids.includes(uid)) return true;
      takeSeat(room, me);
      tx.update(d.ref, { seats: room.seats, uids: room.uids });
      if (room.seats.every(Boolean)) await startGame(tx, d.id, room);
      return true;
    });
    if (joined) return { roomId: d.id };
  }
  const ref = db().collection('rooms').doc();
  const seats: (Seat | null)[] = Array(variant).fill(null);
  seats[0] = me;
  await ref.set({ code: randomCode(), variant, hostUid: uid, status: 'waiting', isPublic: true, majlisId: null, seats, uids: [uid], theme: 'classic', createdAt: Timestamp.now() } as Room);
  return { roomId: ref.id };
});

export const switchSeat = onCall(opts, async req => {
  const uid = requireUser(req);
  const target = Number(req.data?.seat);
  await db().runTransaction(async tx => {
    const snap = await tx.get(roomRef(String(req.data?.roomId)));
    const room = snap.data() as Room;
    if (!room || room.status !== 'waiting') fail('failed-precondition', 'ما تقدر تغير الكرسي الحين');
    const cur = room.seats.findIndex(s => s?.uid === uid);
    if (cur < 0 || !(target >= 0 && target < room.variant) || room.seats[target]) fail('invalid-argument', 'الكرسي مو فاضي');
    room.seats[target] = room.seats[cur]; room.seats[cur] = null;
    tx.update(snap.ref, { seats: room.seats });
  });
  return { ok: true };
});

export const startRoom = onCall(opts, async req => {
  const uid = requireUser(req);
  const roomId = String(req.data?.roomId);
  await db().runTransaction(async tx => {
    const snap = await tx.get(roomRef(roomId));
    const room = snap.data() as Room;
    if (!room) fail('not-found', 'الغرفة مو موجودة');
    if (room.status !== 'waiting') return;
    const age = Date.now() - room.createdAt.toMillis();
    const allowed = room.hostUid === uid || (room.isPublic && room.uids.includes(uid) && age >= PUBLIC_FILL_MS);
    if (!allowed) fail('permission-denied', 'بس صاحب الغرفة يقدر يبدأ');
    await startGame(tx, roomId, room);
  });
  await advance(roomId);
  return { ok: true };
});

export const leaveRoom = onCall(opts, async req => {
  const uid = requireUser(req);
  const roomId = String(req.data?.roomId);
  let needAdvance = false;
  await db().runTransaction(async tx => {
    const snap = await tx.get(roomRef(roomId));
    if (!snap.exists) return;
    const room = snap.data() as Room;
    if (room.status === 'waiting') {
      const i = room.seats.findIndex(s => s?.uid === uid);
      if (i < 0) return;
      room.seats[i] = null;
      room.uids = room.uids.filter(u => u !== uid);
      if (!room.uids.length) { tx.delete(snap.ref); return; }
      tx.update(snap.ref, { seats: room.seats, uids: room.uids, hostUid: room.hostUid === uid ? room.uids[0] : room.hostUid });
    } else if (room.status === 'playing') {
      const ss = await tx.get(secretRef(roomId));
      const sec = ss.data() as Secret;
      const i = sec.seats.findIndex(s => s.uid === uid);
      if (i < 0 || sec.finished) return;
      sec.left[i] = true;
      setDeadline(sec);
      tx.update(ss.ref, { left: sec.left, deadline: sec.deadline });
      needAdvance = true;
    }
  });
  if (needAdvance) await advance(roomId);
  return { ok: true };
});

export const gameAction = onCall(opts, async req => {
  const uid = requireUser(req);
  const roomId = String(req.data?.roomId);
  const action = req.data?.action as Action;
  const r = await step(roomId, null, sec => {
    const seat = sec.seats.findIndex(s => s.uid === uid);
    if (seat < 0) fail('permission-denied', 'مو لاعب في هاللعبة');
    if (action?.type === 'nextHand') fail('invalid-argument', 'حركة مو مسموحة');
    if ((action as any)?.seat !== seat) fail('invalid-argument', 'مو دورك');
    sec.afk[seat] = 0;
    sec.left[seat] = false;
    return action;
  });
  if (!r) fail('failed-precondition', 'اللعبة خلصت');
  await advance(roomId);
  return { ok: true };
});

/** Any player can ask the server to auto-play a turn whose timer ran out. */
export const claimTimeout = onCall(opts, async req => {
  const uid = requireUser(req);
  const roomId = String(req.data?.roomId);
  await playTimedOut(roomId, uid);
  return { ok: true };
});

async function playTimedOut(roomId: string, requester: string | null) {
  const r = await step(roomId, null, sec => {
    if (requester && !sec.seats.some(s => s.uid === requester)) return null;
    if (!sec.deadline || sec.deadline.toMillis() > Date.now()) return null;
    const a = actor(sec.state);
    if (a === null) return null;
    sec.afk[a]++;
    return chooseAction(sec.state, a, 'easy');
  });
  if (r) await advance(roomId);
}

export const sendReaction = onCall(opts, async req => {
  const uid = requireUser(req);
  const roomId = String(req.data?.roomId);
  const slot = SOUND_SLOTS.find(s => s.id === req.data?.slot && s.reaction);
  if (!slot) fail('invalid-argument', 'صوت مو معروف');
  const [sec, user] = await Promise.all([secretRef(roomId).get(), db().doc(`users/${uid}`).get()]);
  const seat = (sec.data() as Secret | undefined)?.seats.findIndex(s => s.uid === uid) ?? -1;
  if (seat < 0) fail('permission-denied', 'مو لاعب في هاللعبة');
  const u = user.data()!;
  if (slot.pack && !(u.owned ?? []).includes(slot.pack)) fail('permission-denied', 'افتحها من المتجر');
  const last = (u.lastReactionAt as Timestamp | undefined)?.toMillis() ?? 0;
  if (Date.now() - last < 3000) fail('resource-exhausted', 'شوي شوي');
  await Promise.all([
    db().collection(`games/${roomId}/reactions`).add({ seat, slot: slot.id, at: FieldValue.serverTimestamp() }),
    user.ref.update({ lastReactionAt: FieldValue.serverTimestamp() }),
  ]);
  return { ok: true };
});

/** Backup sweeper: keeps games moving when nobody's app is open to claim a timeout. */
export const sweepStalledGames = onSchedule({ schedule: 'every 2 minutes', timeoutSeconds: 300 }, async () => {
  const cutoff = Timestamp.fromMillis(Date.now() - 20_000);
  const q = await db().collectionGroup('secret').where('finished', '==', false).where('deadline', '<', cutoff).limit(25).get();
  await Promise.all(q.docs.map(d => playTimedOut(d.ref.parent.parent!.id, null)));
  // Close public rooms nobody joined
  const old = Timestamp.fromMillis(Date.now() - 30 * 60_000);
  const stale = await db().collection('rooms').where('status', '==', 'waiting').where('createdAt', '<', old).limit(100).get();
  await Promise.all(stale.docs.map(d => d.ref.delete()));
});

// Rooms, matchmaking and the authoritative online game loop.
//
// How turns move forward:
//  - A player's move is applied in one short transaction and the call returns at once.
//  - Every state has a deadline. For a bot (or a player who left) it is ~0.7 s away; for the
//    pause after a hand it is ~3 s; for a human it is their turn timer (10 s to bid, 20 s to play).
//  - When a deadline passes, any phone at the table calls `tick`, and the server performs exactly
//    one step (bot move, next hand, or the timed-out player's move). A step counter makes sure
//    two phones ticking at once cannot both apply a move.
//  - A scheduled sweeper ticks games nobody is watching, so a game can never get stuck.
import { onSchedule } from 'firebase-functions/v2/scheduler';
import { getFirestore, FieldValue, Timestamp, Transaction, DocumentReference } from 'firebase-admin/firestore';
import {
  Action, GameEvent, MatchState, RuleError, Variant, apply, drawShowMs, mulberry32, newMatch, packState, unpackState,
  teamOf, viewFor, StoredState,
} from './shared/engine';
import { bestTrump, chooseAction } from './shared/bot';
import { COINS_LOSS, COINS_WIN, SOUND_SLOTS, CHARACTERS } from './shared/catalog';
import { BOT_NAMES, Handler, fail, randomCode, requireUser } from './util';
import { createProfileIfMissing } from './profile';

const db = () => getFirestore();

export interface Seat {
  uid: string | null;    // null for bots
  name: string;
  avatar: string;
  accessory: string | null;
  majlis: string | null;
  majlisId: string | null;
  bot: boolean;
}

interface Room {
  code: string;
  variant: Variant;
  hostUid: string;
  status: 'waiting' | 'playing' | 'done';
  isPublic: boolean;
  majlisId: string | null;
  seats: (Seat | null)[];
  uids: string[];
  theme: string;
  createdAt: Timestamp;
  rematchRoom?: string | null;   // set once someone asks to play again: everyone joins this room
}

type DeadlineKind = 'human' | 'bot' | 'hand';

interface Secret {
  state: MatchState;
  seed: number;
  step: number;
  seats: Seat[];
  afk: number[];          // consecutive timeouts per seat
  left: boolean[];        // seat is played by a bot (player away or quit)
  quit?: boolean[];       // player left with the exit button (no rewards, no rejoin prompt)
  deadline: Timestamp | null;
  deadlineKind: DeadlineKind | null;
  finished: boolean;
  rewarded: boolean;
}

type StoredSecret = Omit<Secret, 'state'> & { state: StoredState<MatchState> };

export const BID_MS = 10_000;
export const TURN_MS = 20_000;
const AWAY_AFTER_TIMEOUTS = 2;   // missed turns in a row before a bot takes the seat
const BOT_MS = 700;
const TRICK_PAUSE_MS = 1_000;
const HAND_PAUSE_MS = 3_000;
const PUBLIC_FILL_MS = 40_000;
const EARLY_MS = 250;   // tolerate small clock differences between phone and server

const roomRef = (id: string) => db().doc(`rooms/${id}`);
const secretRef = (id: string) => db().doc(`games/${id}/secret/state`);
const viewRef = (id: string, uid: string) => db().doc(`games/${id}/views/${uid}`);

// ---------- helpers ----------

const nameHint = (req: any) => req.auth?.token.name ?? req.auth?.token.email?.split('@')[0];

async function seatFor(uid: string, hint?: unknown): Promise<Seat> {
  const ref = await createProfileIfMissing(uid, hint);
  const d = (await ref.get()).data()!;
  return {
    uid, name: d.name, avatar: d.avatar ?? '🧔', accessory: d.equipped?.accessory ?? null,
    majlis: d.majlisTag ?? null, majlisId: d.majlisId ?? null, bot: false,
  };
}

function actor(s: MatchState): number | null {
  if (s.phase === 'bidding') return s.bidTurn;
  if (s.phase === 'trump') return s.bidder;
  if (s.phase === 'playing') return s.turn;
  return null;
}

function botControlled(sec: Secret, seat: number) {
  return sec.seats[seat].bot || sec.left[seat];
}

function rngFor(sec: Secret) {
  return mulberry32((sec.seed ^ Math.imul(sec.step + 1, 2654435761)) >>> 0);
}

function load(data: StoredSecret): Secret {
  return { ...data, quit: data.quit ?? data.seats.map(() => false), state: unpackState(data.state, data.seats.length) };
}

function store(sec: Secret): StoredSecret {
  return { ...sec, state: packState(sec.state) };
}

function publicSeats(seats: Seat[]) {
  return seats.map(s => ({ name: s.name, avatar: s.avatar, accessory: s.accessory, majlis: s.majlis, bot: s.bot, uid: s.uid }));
}

function writeViews(tx: Transaction, gameId: string, sec: Secret, events: GameEvent[]) {
  const seats = publicSeats(sec.seats);
  sec.seats.forEach((st, i) => {
    if (!st.uid) return;
    tx.set(viewRef(gameId, st.uid), {
      seq: sec.step,
      view: packState(viewFor(sec.state, i)),
      events,
      seats,
      mySeat: i,
      left: sec.left,
      deadline: sec.deadline,
      deadlineKind: sec.deadlineKind,
    });
  });
}

function setDeadline(sec: Secret, events: GameEvent[] = [], extraMs = 0) {
  const s = sec.state;
  const at = (ms: number, kind: DeadlineKind) => {
    sec.deadline = Timestamp.fromMillis(Date.now() + ms);
    sec.deadlineKind = kind;
  };
  if (s.phase === 'matchOver') { sec.deadline = null; sec.deadlineKind = null; return; }
  if (s.phase === 'handOver') return at(HAND_PAUSE_MS, 'hand');
  const a = actor(s)!;
  const trickJustEnded = events.some(e => e.type === 'trickWon');
  if (botControlled(sec, a)) return at(BOT_MS + extraMs + (trickJustEnded ? TRICK_PAUSE_MS : 0), 'bot');
  const base = s.phase === 'playing' ? TURN_MS : BID_MS;
  at(base + extraMs + (trickJustEnded ? TRICK_PAUSE_MS : 0), 'human');
}

/** What happens when a human's timer runs out. */
function timeoutAction(s: MatchState, seat: number): Action {
  if (s.phase === 'bidding') return { type: 'pass', seat };
  if (s.phase === 'trump') return { type: 'trump', seat, suit: bestTrump(s.hands[seat]).suit };
  return chooseAction(s, seat, 'normal');
}

/**
 * One atomic step: re-reads the game, lets `decide` pick an action (or nothing),
 * applies it with the rules engine, and writes every player's view.
 */
async function step(gameId: string, decide: (sec: Secret) => Action | null): Promise<Secret | null> {
  const result = await db().runTransaction(async tx => {
    const snap = await tx.get(secretRef(gameId));
    if (!snap.exists) return null;
    const sec = load(snap.data() as StoredSecret);
    if (sec.finished) return null;
    const a = decide(sec);
    if (!a) return null;
    let events: GameEvent[];
    try {
      events = apply(sec.state, a, rngFor(sec));
    } catch (e) {
      if (e instanceof RuleError) fail('invalid-argument', 'حركة مو مسموحة');
      throw e;
    }
    sec.step++;
    setDeadline(sec, events);
    if (sec.state.phase === 'matchOver') sec.finished = true;
    tx.set(secretRef(gameId), store(sec));
    writeViews(tx, gameId, sec, events);
    if (sec.finished) tx.update(roomRef(gameId), { status: 'done', endedAt: FieldValue.serverTimestamp() });
    return sec;
  });
  if (result?.finished) await reward(gameId);
  return result;
}

/** Performs the one step that is due, if its deadline has passed. */
async function tick(gameId: string, requester: string | null) {
  const snap = await secretRef(gameId).get();
  if (!snap.exists) return;
  const pre = snap.data() as StoredSecret;
  if (pre.finished) { await reward(gameId); return; }
  // Only when every human has quit with the exit button. Players who are merely away
  // (app closed, connection lost) keep their game: bots play on and they can rejoin.
  if (pre.seats.every((st, i) => !st.uid || pre.quit?.[i])) { await abandon(gameId); return; }
  await step(gameId, sec => {
    if (requester && !sec.seats.some(s => s.uid === requester)) return null;
    if (!sec.deadline || sec.deadline.toMillis() > Date.now() + EARLY_MS) return null;
    const s = sec.state;
    if (s.phase === 'handOver') return { type: 'nextHand' };
    const a = actor(s);
    if (a === null) return null;
    if (botControlled(sec, a)) return chooseAction(s, a, 'normal');
    sec.afk[a]++;
    // Missed several turns in a row: treat as disconnected, a bot plays until they rejoin.
    if (sec.afk[a] >= AWAY_AFTER_TIMEOUTS) sec.left[a] = true;
    return timeoutAction(s, a);
  });
}

/** Every human left: close the game without rewards. */
async function abandon(gameId: string) {
  await db().runTransaction(async tx => {
    const snap = await tx.get(secretRef(gameId));
    if (!snap.exists || snap.data()!.finished) return;
    for (const st of (snap.data() as StoredSecret).seats) if (st.uid) tx.update(db().doc(`users/${st.uid}`), { activeRoom: null });
    tx.update(snap.ref, { finished: true, rewarded: true, deadline: null, deadlineKind: null, abandoned: true });
    tx.update(roomRef(gameId), { status: 'done', endedAt: FieldValue.serverTimestamp() });
  });
}

async function reward(gameId: string) {
  await db().runTransaction(async tx => {
    const snap = await tx.get(secretRef(gameId));
    if (!snap.exists) return;
    const sec = load(snap.data() as StoredSecret);
    if (sec.rewarded || !sec.finished) return;
    const winner = sec.state.winner!;
    const majlisWins = new Map<string, number>();
    const memberRefs: DocumentReference[] = [];
    sec.seats.forEach((st, i) => {
      if (st.uid && teamOf(i) === winner && st.majlisId) {
        majlisWins.set(st.majlisId, (majlisWins.get(st.majlisId) ?? 0) + 1);
        memberRefs.push(db().doc(`majalis/${st.majlisId}/members/${st.uid}`));
      }
    });
    // Firestore transactions need every read before the first write.
    const memberSnaps = await Promise.all(memberRefs.map(r => tx.get(r)));
    const majlisSnaps = await Promise.all([...majlisWins.keys()].map(id => tx.get(db().doc(`majalis/${id}`))));
    sec.seats.forEach((st, i) => {
      if (!st.uid) return;
      const won = teamOf(i) === winner;
      const quit = sec.quit![i];
      tx.update(db().doc(`users/${st.uid}`), {
        coins: FieldValue.increment(won && !quit ? COINS_WIN : quit ? 0 : COINS_LOSS),
        'stats.played': FieldValue.increment(1),
        'stats.won': FieldValue.increment(won ? 1 : 0),
        'stats.kouts': FieldValue.increment(won && sec.state.winReason === 'inzeli' ? 1 : 0),
        activeRoom: null,
      });
    });
    majlisSnaps.forEach(ms => { if (ms.exists) tx.update(ms.ref, { trophies: FieldValue.increment(3 * majlisWins.get(ms.id)!) }); });
    memberSnaps.forEach(ms => { if (ms.exists) tx.update(ms.ref, { wins: FieldValue.increment(1) }); });
    tx.update(secretRef(gameId), { rewarded: true });
  });
}

function startGame(tx: Transaction, roomId: string, room: Room) {
  const used = new Set(room.seats.filter(Boolean).map(s => s!.name));
  const names = BOT_NAMES.filter(n => !used.has(n)).sort(() => Math.random() - 0.5);
  const looks = CHARACTERS.map(c => c.id).sort(() => Math.random() - 0.5);
  const seats: Seat[] = room.seats.map((s, i) => s ?? {
    uid: null, name: names[i] ?? `بوت ${i + 1}`, avatar: looks[i % looks.length], accessory: null, majlis: null, majlisId: null, bot: true,
  });
  const seed = Math.floor(Math.random() * 2 ** 31);
  const sec: Secret = {
    state: newMatch(room.variant, mulberry32(seed)),   // opening draw picks the dealer
    seed, step: 0, seats,
    afk: seats.map(() => 0), left: seats.map(() => false), quit: seats.map(() => false),
    deadline: null, deadlineKind: null, finished: false, rewarded: false,
  };
  setDeadline(sec, [], drawShowMs(sec.state.dealerDraw));   // time to show the opening draw first
  tx.set(secretRef(roomId), store(sec));
  writeViews(tx, roomId, sec, [{ type: 'dealt' }]);
  tx.update(roomRef(roomId), { status: 'playing', seats, startedAt: FieldValue.serverTimestamp() });
  // Remember the live game on each player's profile, so reopening the app can offer to rejoin.
  for (const st of seats) if (st.uid) tx.update(db().doc(`users/${st.uid}`), { activeRoom: roomId });
}

function takeSeat(room: Room, me: Seat): number {
  // Alternate teams while filling so friends spread across both sides as they join.
  const free = room.seats.map((s, i) => (s ? -1 : i)).filter(i => i >= 0);
  if (!free.length) fail('resource-exhausted', 'الطاولة مليانة');
  const count = [0, 1].map(t => room.seats.filter((s, i) => s && teamOf(i) === t).length);
  const wantTeam = count[0] <= count[1] ? 0 : 1;
  const seat = free.find(i => teamOf(i) === wantTeam) ?? free[0];
  room.seats[seat] = me;
  room.uids.push(me.uid!);
  return seat;
}

function newRoom(me: Seat, variant: Variant, isPublic: boolean, majlisId: string | null, code: string): Room {
  const seats: (Seat | null)[] = Array(variant).fill(null);
  seats[0] = me;
  return { code, variant, hostUid: me.uid!, status: 'waiting', isPublic, majlisId, seats, uids: [me.uid!], theme: 'classic', createdAt: Timestamp.now() };
}

async function uniqueCode(): Promise<string> {
  let code = randomCode();
  for (let i = 0; i < 5; i++) {
    const clash = await db().collection('rooms').where('code', '==', code).where('status', '==', 'waiting').limit(1).get();
    if (clash.empty) break;
    code = randomCode();
  }
  return code;
}

// ---------- handlers (routed through the single `api` function) ----------

export const createRoom: Handler = async req => {
  const uid = requireUser(req);
  const variant: Variant = req.data?.variant === 6 ? 6 : 4;
  const majlisId: string | null = req.data?.majlisId ?? null;
  const me = await seatFor(uid, nameHint(req));
  if (majlisId && me.majlisId !== majlisId) fail('permission-denied', 'مو عضو في هالمجلس');
  const code = await uniqueCode();
  const ref = db().collection('rooms').doc();
  await ref.set(newRoom(me, variant, false, majlisId, code));
  return { roomId: ref.id, code };
};

export const joinRoom: Handler = async req => {
  const uid = requireUser(req);
  const me = await seatFor(uid, nameHint(req));
  let roomId: string | undefined = req.data?.roomId;
  if (!roomId) {
    const code = String(req.data?.code ?? '').toUpperCase();
    const q = await db().collection('rooms').where('code', '==', code).where('status', '==', 'waiting').limit(1).get();
    if (q.empty) fail('not-found', 'ما لقينا غرفة بهالكود');
    roomId = q.docs[0].id;
  }
  await db().runTransaction(async tx => {
    const snap = await tx.get(roomRef(roomId!));
    if (!snap.exists) fail('not-found', 'الغرفة مو موجودة');
    const room = snap.data() as Room;
    if (room.uids.includes(uid)) return;
    if (room.status !== 'waiting') fail('failed-precondition', 'اللعبة بدأت');
    if (room.majlisId && me.majlisId !== room.majlisId) fail('permission-denied', 'هالطاولة لأعضاء المجلس بس');
    takeSeat(room, me);
    tx.update(snap.ref, { seats: room.seats, uids: room.uids });
    if (room.isPublic && room.seats.every(Boolean)) startGame(tx, snap.id, room);
  });
  return { roomId };
};

export const quickMatch: Handler = async req => {
  const uid = requireUser(req);
  const variant: Variant = req.data?.variant === 6 ? 6 : 4;
  const me = await seatFor(uid, nameHint(req));
  const fresh = Timestamp.fromMillis(Date.now() - 3 * 60_000);
  const q = await db().collection('rooms')
    .where('isPublic', '==', true).where('status', '==', 'waiting').where('variant', '==', variant)
    .where('createdAt', '>', fresh).orderBy('createdAt').limit(10).get();
  for (const d of q.docs) {
    const joined = await db().runTransaction(async tx => {
      const snap = await tx.get(d.ref);
      if (!snap.exists) return false;
      const room = snap.data() as Room;
      if (room.uids.includes(uid)) return room.status === 'waiting';
      if (room.status !== 'waiting' || room.seats.every(Boolean)) return false;
      takeSeat(room, me);
      tx.update(d.ref, { seats: room.seats, uids: room.uids });
      if (room.seats.every(Boolean)) startGame(tx, d.id, room);
      return true;
    });
    if (joined) return { roomId: d.id };
  }
  const ref = db().collection('rooms').doc();
  await ref.set(newRoom(me, variant, true, null, randomCode()));
  return { roomId: ref.id };
};

/**
 * "Play again" after a finished online game. The first player to ask creates a new private room
 * with the same settings; everyone after joins that same room. Each player keeps their old seat
 * where possible, so the teams stay together.
 */
export const rematch: Handler = async req => {
  const uid = requireUser(req);
  const oldId = String(req.data?.roomId);
  const me = await seatFor(uid, nameHint(req));
  const code = await uniqueCode();
  const newRef = db().collection('rooms').doc();
  const roomId = await db().runTransaction(async tx => {
    const oldSnap = await tx.get(roomRef(oldId));
    if (!oldSnap.exists) fail('not-found', 'الغرفة مو موجودة');
    const old = oldSnap.data() as Room;
    const mySeat = old.seats.findIndex(s => s?.uid === uid);
    if (mySeat < 0) fail('permission-denied', 'مو لاعب في هاللعبة');
    if (old.status !== 'done') fail('failed-precondition', 'اللعبة لسه ما خلصت');
    const place = (room: Room) => {
      if (!room.seats[mySeat]) { room.seats[mySeat] = me; room.uids.push(uid); }
      else takeSeat(room, me);
    };
    if (old.rematchRoom) {
      const ref = roomRef(old.rematchRoom);
      const snap = await tx.get(ref);
      if (snap.exists) {
        const room = snap.data() as Room;
        if (room.uids.includes(uid)) return snap.id;
        if (room.status !== 'waiting') fail('failed-precondition', 'اللعبة الثانية بدت');
        place(room);
        tx.update(ref, { seats: room.seats, uids: room.uids });
        return snap.id;
      }
    }
    const room = newRoom(me, old.variant, false, old.majlisId ?? null, code);
    room.seats = Array(old.variant).fill(null);
    room.uids = [];
    place(room);
    room.theme = old.theme ?? 'classic';
    tx.set(newRef, room);
    tx.update(oldSnap.ref, { rematchRoom: newRef.id });
    return newRef.id;
  });
  return { roomId };
};

export const switchSeat: Handler = async req => {
  const uid = requireUser(req);
  const target = Number(req.data?.seat);
  await db().runTransaction(async tx => {
    const snap = await tx.get(roomRef(String(req.data?.roomId)));
    const room = snap.data() as Room | undefined;
    if (!room || room.status !== 'waiting') fail('failed-precondition', 'ما تقدر تغير الكرسي الحين');
    const cur = room.seats.findIndex(s => s?.uid === uid);
    if (cur < 0 || !(target >= 0 && target < room.variant) || room.seats[target]) fail('invalid-argument', 'الكرسي مو فاضي');
    room.seats[target] = room.seats[cur]; room.seats[cur] = null;
    tx.update(snap.ref, { seats: room.seats });
  });
  return { ok: true };
};

export const startRoom: Handler = async req => {
  const uid = requireUser(req);
  const roomId = String(req.data?.roomId);
  await db().runTransaction(async tx => {
    const snap = await tx.get(roomRef(roomId));
    const room = snap.data() as Room | undefined;
    if (!room) fail('not-found', 'الغرفة مو موجودة');
    if (room.status !== 'waiting') return;
    const age = Date.now() - room.createdAt.toMillis();
    const allowed = room.hostUid === uid || (room.isPublic && room.uids.includes(uid) && age >= PUBLIC_FILL_MS - 2000);
    if (!allowed) fail('permission-denied', 'بس صاحب الغرفة يقدر يبدأ');
    startGame(tx, roomId, room);
  });
  return { ok: true };
};

export const leaveRoom: Handler = async req => {
  const uid = requireUser(req);
  const roomId = String(req.data?.roomId);
  await db().runTransaction(async tx => {
    const snap = await tx.get(roomRef(roomId));
    if (!snap.exists) return;
    const room = snap.data() as Room;
    if (room.status === 'waiting') {
      const i = room.seats.findIndex(s => s?.uid === uid);
      if (i < 0) return;
      room.seats[i] = null;
      room.uids = room.uids.filter(u => u !== uid);
      if (!room.uids.length) { tx.delete(snap.ref); return; }
      tx.update(snap.ref, { seats: room.seats, uids: room.uids, hostUid: room.hostUid === uid ? room.uids[0] : room.hostUid });
    } else if (room.status === 'playing') {
      const ss = await tx.get(secretRef(roomId));
      if (!ss.exists) return;
      const sec = load(ss.data() as StoredSecret);
      const i = sec.seats.findIndex(s => s.uid === uid);
      if (i < 0 || sec.finished) return;
      sec.left[i] = true;
      sec.quit![i] = true;
      if (actor(sec.state) === i) setDeadline(sec);
      tx.set(ss.ref, store(sec));
      writeViews(tx, roomId, sec, []);
      tx.update(db().doc(`users/${uid}`), { activeRoom: null });
    }
  });
  return { ok: true };
};

/** The app went to the background or is closing: a bot plays this seat until the player is back. */
export const setAway: Handler = async req => {
  const uid = requireUser(req);
  const roomId = String(req.data?.roomId);
  await db().runTransaction(async tx => {
    const ss = await tx.get(secretRef(roomId));
    if (!ss.exists) return;
    const sec = load(ss.data() as StoredSecret);
    const i = sec.seats.findIndex(s => s.uid === uid);
    if (i < 0 || sec.finished || sec.left[i]) return;
    sec.left[i] = true;
    if (actor(sec.state) === i) setDeadline(sec);
    tx.set(ss.ref, store(sec));
    writeViews(tx, roomId, sec, []);
  });
  return { ok: true };
};

/** Back at the table after closing the app: take the seat over from the bot again. */
export const rejoinRoom: Handler = async req => {
  const uid = requireUser(req);
  const roomId = String(req.data?.roomId);
  const ok = await db().runTransaction(async tx => {
    const ss = await tx.get(secretRef(roomId));
    if (!ss.exists) return false;
    const sec = load(ss.data() as StoredSecret);
    const i = sec.seats.findIndex(s => s.uid === uid);
    if (i < 0 || sec.finished) return false;
    sec.left[i] = false;
    sec.quit![i] = false;
    sec.afk[i] = 0;
    if (actor(sec.state) === i) setDeadline(sec);
    tx.set(ss.ref, store(sec));
    writeViews(tx, roomId, sec, []);
    tx.update(db().doc(`users/${uid}`), { activeRoom: roomId });
    return true;
  });
  if (!ok) {
    await db().doc(`users/${uid}`).update({ activeRoom: null });
    fail('failed-precondition', 'اللعبة خلصت');
  }
  return { ok: true };
};

export const gameAction: Handler = async req => {
  const uid = requireUser(req);
  const roomId = String(req.data?.roomId);
  const action = req.data?.action as Action;
  const r = await step(roomId, sec => {
    const seat = sec.seats.findIndex(s => s.uid === uid);
    if (seat < 0) fail('permission-denied', 'مو لاعب في هاللعبة');
    if (!action || action.type === 'nextHand') fail('invalid-argument', 'حركة مو مسموحة');
    if (action.seat !== seat || actor(sec.state) !== seat) fail('invalid-argument', 'مو دورك');
    sec.afk[seat] = 0;
    sec.left[seat] = false;
    sec.quit![seat] = false;
    return action;
  });
  if (!r) fail('failed-precondition', 'اللعبة خلصت');
  return { ok: true, seq: r.step };
};

/** Any player at the table asks the server to perform the step that is now due. */
export const tickGame: Handler = async req => {
  const uid = requireUser(req);
  await tick(String(req.data?.roomId), uid);
  return { ok: true };
};

export const sendReaction: Handler = async req => {
  const uid = requireUser(req);
  const roomId = String(req.data?.roomId);
  const slot = SOUND_SLOTS.find(s => s.id === req.data?.slot && s.reaction);
  if (!slot) fail('invalid-argument', 'صوت مو معروف');
  const [sec, user] = await Promise.all([secretRef(roomId).get(), db().doc(`users/${uid}`).get()]);
  const seat = (sec.data() as StoredSecret | undefined)?.seats.findIndex(s => s.uid === uid) ?? -1;
  if (seat < 0) fail('permission-denied', 'مو لاعب في هاللعبة');
  const u = user.data()!;
  if (slot.pack && !(u.owned ?? []).includes(slot.pack)) fail('permission-denied', 'افتحها من المتجر');
  const last = (u.lastReactionAt as Timestamp | undefined)?.toMillis() ?? 0;
  if (Date.now() - last < 3000) fail('resource-exhausted', 'شوي شوي');
  await Promise.all([
    db().collection(`games/${roomId}/reactions`).add({ seat, slot: slot.id, at: FieldValue.serverTimestamp() }),
    user.ref.update({ lastReactionAt: FieldValue.serverTimestamp() }),
  ]);
  return { ok: true };
};

/** Backup sweeper: keeps games moving when nobody's app is open to tick them. */
export async function sweep() {
  const cutoff = Timestamp.fromMillis(Date.now() - 10_000);
  const q = await db().collectionGroup('secret').where('finished', '==', false).where('deadline', '<', cutoff).limit(50).get();
  for (const d of q.docs) {
    const gameId = d.ref.parent.parent!.id;
    // Several steps per game, so bot-only stretches finish even with every phone closed.
    for (let i = 0; i < 20; i++) {
      const before = (await secretRef(gameId).get()).data() as StoredSecret | undefined;
      if (!before || before.finished || !before.deadline || before.deadline.toMillis() > Date.now() + EARLY_MS) break;
      await tick(gameId, null);
    }
  }
  const old = Timestamp.fromMillis(Date.now() - 30 * 60_000);
  const stale = await db().collection('rooms').where('status', '==', 'waiting').where('createdAt', '<', old).limit(100).get();
  await Promise.all(stale.docs.map(d => d.ref.delete()));
}

export const sweepStalledGames = onSchedule({ schedule: 'every 1 minutes', timeoutSeconds: 120 }, sweep);

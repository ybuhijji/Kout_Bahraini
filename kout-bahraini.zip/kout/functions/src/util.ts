import { HttpsError, CallableRequest } from 'firebase-functions/v2/https';

/** A request handler routed through the single `api` callable. */
export type Handler = (req: CallableRequest<any>) => Promise<unknown>;

/** Error with an Arabic message the app shows as-is. */
export function fail(code: 'invalid-argument' | 'failed-precondition' | 'permission-denied' | 'not-found' | 'resource-exhausted' | 'unauthenticated', ar: string): never {
  throw new HttpsError(code, ar, { ar });
}

/** Signed in, and email verified when the account is email + password. */
export function requireUser(req: CallableRequest): string {
  const a = req.auth;
  if (!a) fail('unauthenticated', 'لازم تسجل دخول');
  const provider = (a.token.firebase as any)?.sign_in_provider;
  if (provider === 'password' && !a.token.email_verified) fail('permission-denied', 'لازم تأكد إيميلك أول');
  return a.uid;
}

export const sleep = (ms: number) => new Promise(r => setTimeout(r, ms));

const BAD_WORDS = ['كلب', 'حمار', 'زق', 'fuck', 'shit'];
export function cleanName(s: unknown, fallback = 'لاعب'): string {
  let n = String(s ?? '').replace(/[\u0000-\u001f<>]/g, '').trim().slice(0, 16);
  if (n.length < 2) n = fallback;
  if (BAD_WORDS.some(w => n.toLowerCase().includes(w))) n = fallback;
  return n;
}

export function randomCode(len = 5) {
  const A = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let s = '';
  for (let i = 0; i < len; i++) s += A[Math.floor(Math.random() * A.length)];
  return s;
}

export const BOT_NAMES = ['بو جاسم', 'بو خليل', 'بو علي', 'بو عيسى', 'بو راشد', 'بو حسن', 'بو محمد', 'بو يوسف', 'بو سلمان', 'بو فيصل'];

// Profiles, store purchases with coins, Google Play coin purchase verification, account deletion.
import { onCall } from 'firebase-functions/v2/https';
import { defineString } from 'firebase-functions/params';
import { getFirestore, FieldValue } from 'firebase-admin/firestore';
import { getAuth } from 'firebase-admin/auth';
import { google } from 'googleapis';
import { CATALOG, COIN_PACKS, ITEM_BY_ID, STARTING_COINS } from './shared/catalog';
import { AVATARS, cleanName, fail, requireUser } from './util';
import { leaveMajlisInternal } from './majlis';

const db = () => getFirestore();
const PACKAGE_NAME = defineString('ANDROID_PACKAGE_NAME', { default: 'bh.kout.game' });

export const ensureProfile = onCall(async req => {
  const uid = requireUser(req);
  const ref = db().doc(`users/${uid}`);
  await db().runTransaction(async tx => {
    const s = await tx.get(ref);
    if (s.exists) return;
    tx.set(ref, {
      name: cleanName(req.data?.name ?? req.auth?.token.name, 'لاعب'),
      avatar: '🧔',
      photo: typeof req.data?.photo === 'string' ? req.data.photo.slice(0, 500) : null,
      coins: STARTING_COINS,
      owned: [],
      equipped: {},
      majlisId: null,
      majlisTag: null,
      stats: { played: 0, won: 0, kouts: 0 },
      createdAt: FieldValue.serverTimestamp(),
    });
  });
  return { ok: true };
});

export const updateProfile = onCall(async req => {
  const uid = requireUser(req);
  const patch: Record<string, unknown> = {};
  if (req.data?.name !== undefined) {
    const n = cleanName(req.data.name, '');
    if (!n) fail('invalid-argument', 'الاسم لازم يكون من 2 إلى 16 حرف');
    patch.name = n;
  }
  if (req.data?.avatar !== undefined) {
    if (!AVATARS.includes(req.data.avatar)) fail('invalid-argument', 'صورة مو متوفرة');
    patch.avatar = req.data.avatar;
  }
  if (Object.keys(patch).length) await db().doc(`users/${uid}`).update(patch);
  if (patch.name) {
    const u = (await db().doc(`users/${uid}`).get()).data()!;
    if (u.majlisId) await db().doc(`majalis/${u.majlisId}/members/${uid}`).update({ name: patch.name, ...(patch.avatar ? { avatar: patch.avatar } : {}) }).catch(() => {});
  }
  return { ok: true };
});

export const buyItem = onCall(async req => {
  const uid = requireUser(req);
  const item = ITEM_BY_ID[String(req.data?.itemId)];
  if (!item) fail('invalid-argument', 'الغرض مو موجود');
  const ref = db().doc(`users/${uid}`);
  const coins = await db().runTransaction(async tx => {
    const u = (await tx.get(ref)).data()!;
    if ((u.owned ?? []).includes(item.id)) fail('failed-precondition', 'عندك هالغرض');
    if (u.coins < item.price) fail('failed-precondition', 'رصيدك ما يكفي');
    tx.update(ref, { coins: FieldValue.increment(-item.price), owned: FieldValue.arrayUnion(item.id) });
    tx.create(db().collection('ledger').doc(), { uid, type: 'item', itemId: item.id, coins: -item.price, at: FieldValue.serverTimestamp() });
    return u.coins - item.price;
  });
  return { coins };
});

export const equipItem = onCall(async req => {
  const uid = requireUser(req);
  const slot = String(req.data?.slot);
  if (!['accessory', 'theme', 'cardback'].includes(slot)) fail('invalid-argument', 'خانة مو معروفة');
  const id: string | null = req.data?.itemId ?? null;
  const ref = db().doc(`users/${uid}`);
  const u = (await ref.get()).data()!;
  if (id) {
    const item = ITEM_BY_ID[id];
    if (!item || item.kind !== slot || !(u.owned ?? []).includes(id)) fail('permission-denied', 'ما تملك هالغرض');
  }
  await ref.update({ [`equipped.${slot}`]: id ?? FieldValue.delete() });
  return { ok: true };
});

/**
 * Verifies a Google Play purchase token with the Play Developer API and credits coins once.
 * The Functions service account needs "View financial data" + "Manage orders" in Play Console.
 */
export const verifyPurchase = onCall(async req => {
  const uid = requireUser(req);
  const productId = String(req.data?.productId ?? '');
  const token = String(req.data?.purchaseToken ?? '');
  const pack = COIN_PACKS.find(p => p.productId === productId);
  if (!pack || token.length < 10) fail('invalid-argument', 'عملية شراء مو صحيحة');

  const authClient = await google.auth.getClient({ scopes: ['https://www.googleapis.com/auth/androidpublisher'] });
  const publisher = google.androidpublisher({ version: 'v3', auth: authClient as any });
  let p;
  try {
    p = (await publisher.purchases.products.get({ packageName: PACKAGE_NAME.value(), productId, token })).data;
  } catch {
    fail('failed-precondition', 'ما قدرنا نتأكد من الشراء، حاول بعدين');
  }
  if (p.purchaseState !== 0) fail('failed-precondition', 'الشراء مو مكتمل');
  if (p.obfuscatedExternalAccountId && p.obfuscatedExternalAccountId !== uid) fail('permission-denied', 'الشراء لحساب ثاني');

  const purchaseRef = db().doc(`purchases/${token.replace(/\//g, '_').slice(0, 1400)}`);
  const userRef = db().doc(`users/${uid}`);
  await db().runTransaction(async tx => {
    const done = await tx.get(purchaseRef);
    if (done.exists) return; // already credited (Play redelivers until consumed)
    tx.create(purchaseRef, { uid, productId, orderId: p.orderId ?? null, coins: pack.coins, at: FieldValue.serverTimestamp() });
    tx.update(userRef, { coins: FieldValue.increment(pack.coins) });
    tx.create(db().collection('ledger').doc(), { uid, type: 'purchase', productId, coins: pack.coins, at: FieldValue.serverTimestamp() });
  });
  return { coins: pack.coins };
});

/** Play Store policy requires in-app account deletion. */
export const deleteAccount = onCall(async req => {
  const uid = requireUser(req);
  await leaveMajlisInternal(uid).catch(() => {});
  await db().doc(`users/${uid}`).delete();
  await getAuth().deleteUser(uid);
  return { ok: true };
});

export const catalogSize = CATALOG.length;

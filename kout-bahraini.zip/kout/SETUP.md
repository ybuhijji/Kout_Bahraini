# كوت بحريني: from code to Google Play

The game is complete in code. These steps connect it to accounts that have to be in your name. Plan on one to two days for the accounts, plus Google's review and testing period.

## 0. Tools (on your computer)

1. Install **Node.js 22** from nodejs.org.
2. Install **Android Studio** (it includes Java and the Android SDK).
3. In this folder run:
   ```
   npm install
   npm --prefix functions install
   ```
4. Try the offline game in a browser: `npm run dev`, then open the link it prints.

## 1. Firebase (logins, online play, Majlis, store)

1. Go to console.firebase.google.com and create a project (for example `kout-bh`).
2. Switch the project to the **Blaze (pay as you go)** plan. Cloud Functions require it. At small scale the cost is close to zero; set a budget alert in Google Cloud Billing anyway.
3. **Firestore Database** → Create database → production mode. Pick a region close to Bahrain (`me-central2` Dammam if offered, otherwise `europe-west1`). If you pick `me-central2`, also change the region in `functions/src/index.ts` and `src/net/firebase-config.ts` to match.
4. **Authentication** → Sign-in method → enable:
   - Email/Password
   - Google
   - Facebook (needs step 2 below)
   - Twitter (this is X; needs step 3 below)
5. Authentication → Templates → set the language to Arabic for the verification and password reset emails.
6. Project settings → **Add app → Web**. Copy the config values into `src/net/firebase-config.ts`.
7. Project settings → **Add app → Android**, package name `bh.kout.game` (or your own, but then change it in `capacitor.config.ts` and `functions/src/account.ts` too, before the first upload; it can never change after).
   - Add the SHA-1 and SHA-256 fingerprints. Debug: run `cd android && ./gradlew signingReport`. Release: Play Console → Setup → App signing (after step 5).
   - Download `google-services.json` into `android/app/`.

## 2. Facebook login

1. developers.facebook.com → My Apps → Create app → "Authenticate and request data from users with Facebook Login".
2. Add the Android platform: package `bh.kout.game`, class `bh.kout.game.MainActivity`, and your key hashes (Facebook's docs show how to convert the SHA-1).
3. Copy the **App ID** and **Client token** (Settings → Advanced) into `android/app/src/main/res/values/strings.xml`.
4. Paste the App ID and App secret into Firebase → Authentication → Facebook, and copy Firebase's OAuth redirect URI back into Facebook Login settings.
5. Switch the Facebook app to Live mode before release.

## 3. X (Twitter) login

1. developer.x.com → create a Project and App (the free tier is enough for login).
2. User authentication settings → enable OAuth 1.0a, type "Native App", callback URL = the redirect URI shown in Firebase → Authentication → Twitter.
3. Paste the API key and secret into Firebase → Authentication → Twitter.

## 4. Deploy the server

```
npx firebase login
npx firebase use --add          (pick your project)
npm run test:server             (runs the 40 server checks)
npm run deploy:server
```

When asked for `ANDROID_PACKAGE_NAME`, enter `bh.kout.game`. The first deploy also creates the database indexes; they take a few minutes to build.

## 5. Google Play Console

1. play.google.com/console → pay the one-time $25 fee and verify your identity.
   - **Personal** developer accounts must run a **closed test with at least 12 testers for 14 days** before they can publish to everyone. Majlis friends are perfect for this.
   - **Organisation** accounts (needs a D-U-N-S number) skip that rule.
2. Create app → Game → Free (with in-app purchases).
3. **Monetize → Products → In-app products**: create four products with these exact IDs, then set prices (Play converts to BHD):
   | Product ID | Coins |
   |---|---|
   | `coins_500` | 500 |
   | `coins_1200` | 1,200 |
   | `coins_3000` | 3,000 |
   | `coins_8000` | 8,000 |
4. Let the server verify purchases:
   - Google Cloud console (same project as Firebase) → enable **Google Play Android Developer API**.
   - Play Console → Users and permissions → Invite the service account `PROJECT_ID@appspot.gserviceaccount.com` (or the "Default compute service account" shown under Cloud Functions) with **View financial data** and **Manage orders and subscriptions**.
5. Store listing: use `store-assets/play-icon-512.png`, `store-assets/feature-graphic-1024x500.png`, and phone screenshots (`store-assets/screenshots/`).
6. Policy forms:
   - **Privacy policy URL**: host `PRIVACY.md` (Firebase Hosting works: `npm run build && npx firebase deploy --only hosting`, then link to a page with the policy text).
   - **Data safety**: collects email, name, user IDs, purchase history, in-app messages (Majlis chat). Data encrypted in transit. Users can delete their account in the app (Profile → حذف الحساب).
   - **Content rating** questionnaire: card game, no real-money gambling. Coins cannot be won or lost by betting, they are rewards and cosmetics only. Keep it that way, or the app falls under gambling rules that Bahrain law does not allow.
   - **Ads**: none.
   - **Target audience**: 18+ is the simplest choice for a game with chat and purchases.

## 6. Build the app

```
npm run android
```

This builds the game and opens Android Studio. Then:

- **For Play Store**: Build → Generate Signed App Bundle → **Android App Bundle (.aab)**. Create the upload key when asked. **Back up the key file and passwords somewhere safe**; losing them makes updates painful.
- **For a quick test on your own phone**: Build → Build APK, or press Run with the phone plugged in (USB debugging on).

Upload the `.aab` to Play Console → Testing → Closed testing first, add your testers' emails, then promote to Production once the 14 days are done.

For every update: raise `versionCode` in `android/app/build.gradle`, run `npm run sync`, build a new `.aab`.

## 7. Before release: content you need to supply

- **Meme voice clips** → `public/sounds/` (see the README there for file names). Get written permission from each person.
- **Club crests** → `public/themes/` (see the README there). Get written approval from Muharraq and Riffa clubs.
- Optional item artwork → `public/items/`.

Then `npm run sync` and rebuild.
